/* CLEAR service worker: toolbar state per tab, context menu, shortcuts, message relays. */
importScripts('shared/settings.js');

const ICON = {
  on: { 16: 'icons/icon16.png', 32: 'icons/icon32.png' },
  grey: { 16: 'icons/icon16g.png', 32: 'icons/icon32g.png' }
};
const LOOK = {
  on: { text: '', color: '#5f8575', title: 'CLEAR is active on this page' },
  paused: { text: 'II', color: '#b08a3c', title: 'CLEAR is paused on this site. Select text and right-click to explain it.' },
  off: { text: 'off', color: '#8a959b', title: 'CLEAR is turned off' }
};
const quiet = () => void chrome.runtime.lastError;

/* Default look = "CLEAR cannot run here". A page where CLEAR runs reports in and gets its own look.
   Tab-specific looks are cleared by Chrome on navigation, so a tab that never reports stays grey with a cross. */
function setDefaults() {
  chrome.action.setBadgeBackgroundColor({ color: '#8a959b' });
  chrome.action.setBadgeText({ text: '×' });
  chrome.action.setTitle({ title: 'CLEAR cannot run on this page. Select text and right-click to explain it. (New install? Reload the tab.)' });
}
setDefaults();

function paint(tabId, state) {
  const look = LOOK[state] || LOOK.on;
  chrome.action.setIcon({ tabId, path: state === 'on' ? ICON.on : ICON.grey }, quiet);
  chrome.action.setBadgeText({ tabId, text: look.text }, quiet);
  chrome.action.setBadgeBackgroundColor({ tabId, color: look.color }, quiet);
  chrome.action.setTitle({ tabId, title: look.title }, quiet);
}

chrome.runtime.onInstalled.addListener((details) => {
  // Chrome shows one entry per extension in the right-click menu. With two actions it becomes a small submenu.
  chrome.contextMenus.removeAll(() => {
    chrome.contextMenus.create({ id: 'clear-root', title: 'CLEAR', contexts: ['selection'] });
    chrome.contextMenus.create({ id: 'clear-explain', parentId: 'clear-root', title: 'Explain this', contexts: ['selection'] });
    chrome.contextMenus.create({ id: 'clear-simplify', parentId: 'clear-root', title: 'Simplify this', contexts: ['selection'] });
  });
  modelCheck();
  if (details.reason === 'install') chrome.runtime.openOptionsPage();
});

/* Stand-alone explanation window, for pages where the in-page panel cannot be shown. */
function openWindow(text, simplify) {
  chrome.windows.create({
    url: chrome.runtime.getURL('site/explain.html') + (simplify ? '?simplify=1' : '') + '#' + encodeURIComponent(String(text || '').slice(0, 4000)),
    type: 'popup', width: 460, height: 700
  }, quiet);
}
function explainInTab(tabId, msg, opts, fallbackText, simplify) {
  chrome.tabs.sendMessage(tabId, msg, opts, (r) => {
    if (chrome.runtime.lastError || !r || !r.ok) openWindow(fallbackText, simplify);
  });
}

chrome.contextMenus.onClicked.addListener((info, tab) => {
  if (info.menuItemId !== 'clear-explain' && info.menuItemId !== 'clear-simplify') return;
  const text = info.selectionText || '';
  const simplify = info.menuItemId === 'clear-simplify';
  if (!tab || tab.id == null || tab.id < 0) return openWindow(text, simplify);
  explainInTab(tab.id, { type: 'explain', text, simplify }, { frameId: info.frameId || 0 }, text, simplify);
});

chrome.commands.onCommand.addListener(async (cmd, tab) => {
  if (cmd === 'toggle-clear') {
    const s = await CLEAR.load();
    s.enabled = !s.enabled;
    await CLEAR.save(s);
  } else if (cmd === 'explain-selection') {
    if (!tab || tab.id == null) return openWindow('');
    explainInTab(tab.id, { type: 'explain-selection' }, {}, '');
  }
});

/* ---- On-device AI models. They run in a hidden extension page (ai/offscreen.html). ---- */
const MODEL_KEY = { irony: 'clearModel', simplify: 'clearModelSimplify' };
const getModel = async (name) => { const k = MODEL_KEY[name || 'irony']; return (await chrome.storage.local.get(k))[k] || { state: 'none' }; };
const setModel = (name, m) => chrome.storage.local.set({ [MODEL_KEY[name || 'irony']]: m });
const modelHost = async () => (await chrome.storage.local.get('clearModelHost')).clearModelHost || undefined; // for testing only
let offscreenReady = null, llmMaybe = true;
function ensureOffscreen() {
  if (!offscreenReady) {
    offscreenReady = (async () => {
      if (await chrome.offscreen.hasDocument()) return;
      await chrome.offscreen.createDocument({ url: 'ai/offscreen.html', reasons: ['WORKERS'], justification: 'Runs the on-device language models that read tone and simplify text.' });
    })().finally(() => { offscreenReady = null; });
  }
  return offscreenReady;
}
const toOff = (msg) => new Promise((res) => {
  chrome.runtime.sendMessage(Object.assign({ target: 'offscreen' }, msg), (r) => { void chrome.runtime.lastError; res(r || null); });
});
async function modelDownload(name) {
  if (!MODEL_KEY[name]) return;
  const st = await getModel(name);
  if (st.state === 'downloading' && Date.now() - (st.at || 0) < 20000) return;
  await setModel(name, { state: 'downloading', progress: 0, at: Date.now() });
  try { await ensureOffscreen(); toOff({ type: 'load', model: name, host: await modelHost() }); } // the page reports back with model-progress / model-done
  catch (e) { setModel(name, { state: 'error', error: String(e && e.message || e).slice(0, 200) }); }
}
async function modelRemove(name) {
  if (!MODEL_KEY[name]) return;
  try { await ensureOffscreen(); await toOff({ type: 'remove', model: name }); } catch (e) {}
  await setModel(name, { state: 'none' });
}
/* One message: Chrome's built-in model if this browser has it, otherwise the sarcasm model if it was downloaded. */
async function aiRead(text, context) {
  const out = {};
  const st = await getModel('irony');
  if (!llmMaybe && st.state !== 'ready') return out;
  await ensureOffscreen();
  if (llmMaybe) {
    const r = await toOff({ type: 'llm', text, context });
    if (r && r.ok) out.llm = r.data; else llmMaybe = false; // do not ask again until the worker restarts
  }
  if (!out.llm && st.state === 'ready') {
    const texts = context ? [text, context + '\n' + text] : [text];
    const r = await toOff({ type: 'classify', texts, host: await modelHost() });
    if (r && r.ok) out.irony = { self: r.scores[0], ctx: texts.length > 1 ? r.scores[1] : null };
  }
  return out;
}
async function aiIrony(texts) {
  if ((await getModel('irony')).state !== 'ready' || !Array.isArray(texts) || !texts.length) return { ok: false };
  await ensureOffscreen();
  return (await toOff({ type: 'classify', texts: texts.slice(0, 12), host: await modelHost() })) || { ok: false };
}
/* Simpler wording: Chrome's built-in model first, then the downloaded simplification model. */
async function aiSimplify(text) {
  const st = await getModel('simplify');
  if (!llmMaybe && st.state !== 'ready') return { ok: false };
  await ensureOffscreen();
  if (llmMaybe) {
    const r = await toOff({ type: 'llm-simplify', text });
    if (r && r.ok) return { ok: true, text: r.text, engine: 'llm' };
    llmMaybe = false;
  }
  if (st.state !== 'ready') return { ok: false };
  const r = await toOff({ type: 'simplify', text, host: await modelHost() });
  return r && r.ok ? { ok: true, text: r.text, changed: r.changed, engine: 'model' } : { ok: false, error: r && r.error };
}
/* Models stay in the browser cache across restarts and extension updates. If the saved state does not say
   "ready" but the files are there, mark the model as installed so it is not downloaded twice. */
let probing = null;
function modelCheck() {
  if (!probing) probing = (async () => {
    const states = {};
    for (const n of Object.keys(MODEL_KEY)) states[n] = await getModel(n);
    for (const n of Object.keys(states)) if (states[n].state === 'downloading' && Date.now() - (states[n].at || 0) > 60000) { states[n] = { state: 'none' }; await setModel(n, states[n]); }
    if (Object.values(states).every((m) => m.state === 'downloading')) return;
    await ensureOffscreen();
    const r = await toOff({ type: 'probe' });
    if (!r || !r.ok) return;
    for (const n of Object.keys(states)) {
      if (states[n].state === 'downloading') continue;
      if (r.have[n] && states[n].state !== 'ready') await setModel(n, { state: 'ready' });
      // marked installed, but a file is missing (a newer CLEAR version needs an extra part, or the cache was cleared)
      else if (!r.have[n] && states[n].state === 'ready') await setModel(n, { state: 'none', partial: !!r.some[n] });
      else if (!r.have[n] && r.some[n] && !states[n].partial && states[n].state === 'none') await setModel(n, { state: 'none', partial: true });
    }
  })().catch(() => {}).finally(() => { probing = null; });
  return probing;
}
chrome.runtime.onStartup.addListener(modelCheck);

/* ---- GIF stills: download, confirm it is animated, return the first frame as a PNG data URL ---- */
function isAnimatedGif(b) {
  if (b.length < 14 || b[0] !== 0x47 || b[1] !== 0x49 || b[2] !== 0x46) return false; // "GIF"
  let p = 13, frames = 0;
  if (b[10] & 0x80) p += 3 * (1 << ((b[10] & 7) + 1)); // global color table
  const skipBlocks = () => { while (p < b.length && b[p] !== 0) p += b[p] + 1; p++; };
  while (p < b.length) {
    const t = b[p++];
    if (t === 0x2C) {                       // image descriptor
      if (++frames > 1) return true;
      const flags = b[p + 8]; p += 9;
      if (flags & 0x80) p += 3 * (1 << ((flags & 7) + 1));
      p++; skipBlocks();
    } else if (t === 0x21) { p++; skipBlocks(); } // extension
    else break;                              // trailer or damaged data
  }
  return false;
}
function toDataUrl(bytes, type) {
  let bin = '';
  for (let i = 0; i < bytes.length; i += 0x8000) bin += String.fromCharCode.apply(null, bytes.subarray(i, i + 0x8000));
  return 'data:' + type + ';base64,' + btoa(bin);
}
const stills = new Map();
async function gifStill(url) {
  if (stills.has(url)) return stills.get(url);
  let out = { ok: false };
  try {
    const res = await fetch(url, { credentials: 'include' });
    const buf = res.ok ? await res.arrayBuffer() : null;
    if (buf && buf.byteLength <= 25e6 && isAnimatedGif(new Uint8Array(buf))) {
      const bmp = await createImageBitmap(new Blob([buf], { type: 'image/gif' }));
      const canvas = new OffscreenCanvas(bmp.width, bmp.height);
      canvas.getContext('2d').drawImage(bmp, 0, 0);
      const png = await canvas.convertToBlob({ type: 'image/png' });
      out = { ok: true, still: toDataUrl(new Uint8Array(await png.arrayBuffer()), 'image/png') };
    }
  } catch (e) {}
  if (stills.size >= 40) stills.delete(stills.keys().next().value);
  stills.set(url, out);
  return out;
}

chrome.runtime.onMessage.addListener((msg, sender, reply) => {
  if (!msg || msg.target === 'offscreen') return;
  if (msg.type === 'gif-still') { gifStill(String(msg.url || '')).then(reply); return true; }
  if (msg.type === 'page-state' && sender.tab && sender.frameId === 0) paint(sender.tab.id, msg.state);
  else if (msg.type === 'open-settings') chrome.runtime.openOptionsPage();
  else if (msg.type === 'relay-explain' && sender.tab) chrome.tabs.sendMessage(sender.tab.id, { type: 'explain', payload: msg.payload }, { frameId: 0 }, quiet);
  else if (msg.type === 'resume-media' && sender.tab) chrome.tabs.sendMessage(sender.tab.id, { type: 'resume-media' }, quiet);
  else if (msg.type === 'explain-active-tab') {
    if (msg.tabId == null) openWindow(''); else explainInTab(msg.tabId, { type: 'explain-selection' }, {}, '');
    reply({ ok: true });
  }
  else if (msg.type === 'model-progress') { const n = msg.model || 'irony'; getModel(n).then((m) => { if (m.state === 'downloading') setModel(n, { state: 'downloading', progress: msg.progress, at: Date.now() }); }); }
  else if (msg.type === 'model-done') setModel(msg.model || 'irony', msg.ok ? { state: 'ready' } : { state: 'error', error: msg.error || 'The model could not be loaded.' });
  else if (msg.type === 'model-check') { modelCheck().then(() => reply({ ok: true })); return true; }
  else if (msg.type === 'model-download') { modelDownload(msg.model || 'irony'); reply({ ok: true }); }
  else if (msg.type === 'model-remove') { modelRemove(msg.model || 'irony').then(() => reply({ ok: true })); return true; }
  else if (msg.type === 'ai-simplify') { aiSimplify(msg.text).then(reply, () => reply({ ok: false })); return true; }
  else if (msg.type === 'ai-read') { aiRead(msg.text, msg.context).then(reply, () => reply({})); return true; }
  else if (msg.type === 'ai-irony') { aiIrony(msg.texts).then(reply, () => reply({ ok: false })); return true; }
});
