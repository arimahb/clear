const $ = (id) => document.getElementById(id);
const get = (o, path) => path.split('.').reduce((a, k) => a[k], o);
const set = (o, path, v) => { const ks = path.split('.'); const last = ks.pop(); ks.reduce((a, k) => a[k], o)[last] = v; };
const LEVEL = { calm: 'Calm page', moderate: 'Moderate page', busy: 'Busy page' };
let S, tabId = null, host = '';

function hsl(hex, lv) {
  const c = [parseInt(hex.slice(1, 3), 16) / 255, parseInt(hex.slice(3, 5), 16) / 255, parseInt(hex.slice(5, 7), 16) / 255, 1];
  return CLEAR.soften(c, lv, false) || hex;
}
function renderAmount(v) {
  $('amount-out').textContent = v > 0 ? v + '%' : 'Off';
  const lv = CLEAR.colorLevel(v);
  document.querySelectorAll('.swatches i').forEach((i) => { i.style.background = hsl(i.dataset.c, lv); });
}
function render() {
  $('enabled').checked = S.enabled;
  $('amount').value = S.sensory.colorAmount; renderAmount(S.sensory.colorAmount);
  document.querySelectorAll('[data-key]').forEach((i) => {
    const v = get(S, i.dataset.key);
    i.checked = i.dataset.on ? v !== i.dataset.off : !!v;
  });
  if (host) { $('site-row').hidden = false; $('host').textContent = host; $('site').checked = !S.disabledSites.includes(host); }
}
function fill(id, arr, cls) {
  const u = $(id); u.textContent = '';
  arr.forEach((t) => { const li = document.createElement('li'); if (cls) li.className = cls; li.textContent = t; u.appendChild(li); });
}
function status() {
  if (tabId == null) return;
  chrome.tabs.sendMessage(tabId, { type: 'status' }, { frameId: 0 }, (r) => {
    if (chrome.runtime.lastError || !r) { $('level').textContent = 'CLEAR cannot run on this page. Browsers block extensions on pages like this one. You can still select text, right-click and choose "Explain this with CLEAR". If you just installed CLEAR, reload the tab.'; fill('items', []); fill('did', []); return; }
    host = r.host; render();
    if (!r.active) { $('level').textContent = S.enabled ? 'CLEAR is paused on this site.' : 'CLEAR is turned off.'; fill('items', []); fill('did', []); return; }
    $('level').className = '';
    $('level').innerHTML = '';
    const dot = document.createElement('span'); dot.className = 'dot ' + r.level;
    const b = document.createElement('b'); b.textContent = LEVEL[r.level] || '';
    $('level').append(dot, b);
    fill('items', r.items.slice(0, 6));
    fill('did', r.did, 'sub');
  });
}
const save = () => CLEAR.save(S).then(() => setTimeout(status, 350));

(async () => {
  S = await CLEAR.load();
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  tabId = tab ? tab.id : null;
  render(); status();

  $('enabled').addEventListener('change', (e) => { S.enabled = e.target.checked; save(); });
  let amountTimer = 0;
  $('amount').addEventListener('input', (e) => {   // the page follows the slider while it is dragged
    S.sensory.colorAmount = Number(e.target.value); renderAmount(S.sensory.colorAmount);
    clearTimeout(amountTimer); amountTimer = setTimeout(() => CLEAR.save(S), 120);
  });
  $('amount').addEventListener('change', () => { clearTimeout(amountTimer); save(); });
  $('site').addEventListener('change', (e) => {
    S.disabledSites = S.disabledSites.filter((h) => h !== host);
    if (!e.target.checked) S.disabledSites.push(host);
    save();
  });
  document.querySelectorAll('[data-key]').forEach((i) => i.addEventListener('change', () => {
    set(S, i.dataset.key, i.dataset.on ? (i.checked ? i.dataset.on : i.dataset.off) : i.checked);
    save();
  }));
  $('explain').addEventListener('click', () => {
    chrome.runtime.sendMessage({ type: 'explain-active-tab', tabId }, () => { void chrome.runtime.lastError; window.close(); });
  });
  $('customize').addEventListener('click', () => chrome.runtime.openOptionsPage());
})();
