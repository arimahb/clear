# CLEAR: Calm Web Co-Pilot

Less guesswork. More control.

## Updating
- Unzip over the old folder (or anywhere) and press the reload arrow on CLEAR in `chrome://extensions`. Do not press Remove: removing an extension deletes its settings and downloaded models.
- The extension has a fixed ID, so settings and downloaded models carry over between versions.
- To test on local files (`file://`), turn on "Allow access to file URLs" on CLEAR's details page.

## Install (Chrome, Edge, Brave)
1. Unzip this folder.
2. Open `chrome://extensions` and turn on **Developer mode** (top right).
3. Click **Load unpacked** and choose the unzipped `clear-extension` folder.
4. The CLEAR website opens. Use it to customize behaviour. You can reopen it any time from the toolbar popup with **Customize**.

## What it does
- **Page forecast**: a short bar when a page opens (reading time, length, videos, moving images, ads, pop-ups, login forms), which then shrinks to a corner button.
- **Calmer pages**: stops autoplay, shows GIFs as a still frame (point at one and press Play), pauses large looping animations, desaturates bright colors (backgrounds, gradients, borders, text, icons) while keeping hue and lightness.
- **Clearer messages**: tone labels such as [Sarcasm?] and dotted underlines on idioms in posts, comments and emails. Hover for the plain meaning. Click a label for a full explanation.
- **Explain this**: select text on any page and press the small "Explain" button, right-click and choose CLEAR > "Explain this", or press Alt+Shift+E. This works on sites where CLEAR is paused. On pages where browsers block extensions (chrome:// pages, the Web Store), the right-click menu opens the explanation in a small window instead.
- **Context for tone**: the Explain panel lists the lines before and after your selection. The rest of the same message and the line just before it are ticked for you. Tick others as needed, or select more text on the page and press "Add text I have selected on the page".
- **Desaturation slider**: in the toolbar popup and on the website. 0 is off, 100 removes the most color.
- **Toolbar icon states**: green = working on this tab, grey "II" = paused on this site, grey "off" = turned off, grey "×" = CLEAR cannot run on this page.

## Simplify
- Select text and press **Simplify** next to it, or right-click and choose CLEAR > "Simplify this". The Explain panel also has a "Rewrite in simpler words" button.
- Without a model, CLEAR swaps idioms and formal words using a built-in list.
- With the optional simplification model (`Xenova/LaMini-Flan-T5-248M`, about 270 MB, downloaded once from Customize > Social clarity), whole sentences are rewritten on your computer. Small models can change details, so check names, numbers and dates against the original.

## On-device AI for sarcasm
- Fixed rules miss most real sarcasm, so CLEAR can run small AI models on your computer. Open Customize > Social clarity > Sarcasm models and press Download (about 194 MB together, one time, from huggingface.co). The Explain panel offers the same button.
- **Neither model may start a label on its own.** The irony classifier rates most cheerful text as ironic, and a sentiment classifier reads words rather than situations ("the bug is fixed now" scores negative on the word "bug"). A label needs a *conflict*: praise with nothing in it ("Fantastic", "My day is complete") next to a clause the sentiment model reads as bad ("the printer is jammed"), or sarcastic wording the built-in rules recognise. Clauses that say things went well (fixed, passed, works now, went smoothly) can never be the bad situation, however negative their words look. The clause logic is in `shared/sarcasm.js`.
- The models then confirm or deny: they firm a guess into a plain label, or withdraw a weak rules guess. `Xenova/twitter-roberta-base-irony` supplies the irony score, `Xenova/distilbert-base-uncased-finetuned-sst-2-english` judges the situation clause.
- Both run in WebAssembly through Transformers.js (bundled in `vendor/`) inside a hidden extension page (`ai/`).
- If your Chrome includes Google's built-in on-device model (Prompt API), CLEAR uses it too, for tone and for "what might be missing".
- Text never leaves your computer. Only the model file is downloaded.

## Designed to be subtle
- Nothing is hidden, removed or rewritten. Every change is reversible.
- Anything you start yourself (pressing Play) is never blocked. Video calls are never paused.
- Tone labels appear only on clear signals. A "?" marks a guess.
- All analysis runs locally in the browser. No page text leaves your computer.

## Files
- `manifest.json`, `background.js`: extension setup, context menu, shortcuts
- `content/`: page behaviour (`content.js`), phrase list (`lexicon.js`), tone rules (`analyze.js`)
- `popup/`: toolbar popup
- `site/`: the CLEAR website and settings page. It can also be hosted on its own domain; add that domain under Customize > Advanced.
- `shared/settings.js`: default settings
