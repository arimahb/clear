/* CLEAR shared renderer for an explanation. Used by the in-page panel, the website and the stand-alone window. */
(function (g) {
  const el = (tag, cls, text) => { const n = document.createElement(tag); if (cls) n.className = cls; if (text != null) n.textContent = text; return n; };

  function explain(body, x, opts) {
    const H = (opts && opts.heading) || 'h3';
    body.textContent = '';

    body.appendChild(el(H, '', 'Tone'));
    if (x.tone) {
      const p = el('div');
      p.append(el('span', 'tag', '[' + x.tone.label + ']'), x.tone.note);
      body.append(p, el('div', 'muted small', 'Why: ' + x.tone.reasons.join('; ') + '.' + (x.tone.strong ? '' : ' This is a guess from the wording, not a certainty.')));
    } else {
      body.appendChild(el('div', 'muted', x.toneNote || ('No strong tone signals found. It can most likely be read literally.' +
        (x.context ? '' : ' If it still feels off, add the lines around it as context.'))));
    }

    body.appendChild(el(H, '', 'What it literally says'));
    const q = el('div', 'quote');
    for (const part of x.parts) {
      if (part.meaning) q.append(el('span', 'dec', part.text), ' ', el('span', 'mean', '(= ' + part.meaning + ')'));
      else q.append(part.text);
    }
    body.appendChild(q);
    if (x.tone && x.tone.key === 'sarcasm') body.appendChild(el('div', 'muted small', 'If this is sarcasm, the writer means roughly the opposite of these words.'));

    body.appendChild(el(H, '', 'What it asks of you'));
    if (x.asks.length) {
      const u = el('ul');
      x.asks.forEach((a) => { const li = el('li'); li.append(el('span', 'tag', a.kind === 'do' ? 'Do' : 'Answer'), a.text); u.appendChild(li); });
      body.appendChild(u);
    } else body.appendChild(el('div', 'muted', 'No direct request found. You probably do not need to do anything unless you want to reply.'));

    body.appendChild(el(H, '', 'What might be missing'));
    if (x.missing.length) { const u = el('ul'); x.missing.forEach((m) => u.appendChild(el('li', '', m))); body.appendChild(u); }
    else body.appendChild(el('div', 'muted', x.complete || 'Nothing obvious is missing.'));
  }

  /* "In simpler words". Shows the rule-based version at once, then swaps in a model's version when one is available.
     api: { ai: boolean, send(msg, cb), offer(box) } */
  function simplify(box, text, api) {
    box.textContent = '';
    const basic = g.CLEAR_ANALYZE.simplifyBasic(text);
    const out = box.appendChild(el('div', 'quote', basic.text));
    const note = box.appendChild(el('div', 'muted small'));
    const basicNote = basic.changed
      ? 'Basic version: idioms and formal words were swapped using CLEAR\'s built-in word list. Sentence structure is unchanged.'
      : 'CLEAR\'s built-in word list found nothing to replace, so the text is unchanged.';
    note.textContent = basicNote;
    if (!api || !api.ai) return;
    const wait = box.appendChild(el('div', 'muted small', 'Asking the on-device model for a fuller rewrite. Long text can take up to a minute...'));
    api.send({ type: 'ai-simplify', text }, (r) => {
      wait.remove();
      if (r && r.ok && r.engine === 'model' && !r.changed) {
        note.textContent = basicNote + ' The simplification model had no usable rewrite for this text, so the basic version is shown.';
      } else if (r && r.ok && r.text) {
        out.textContent = r.text;
        note.textContent = r.engine === 'llm'
          ? 'Rewritten by Chrome\'s on-device AI model. Check important details against the original.'
          : 'Rewritten by the on-device simplification model. Small models can change details, so check names, numbers and dates against the original.';
      } else if (api.offer) api.offer(box);
    });
  }

  g.CLEAR_RENDER = { el, explain, simplify };
})(globalThis);
