/* CLEAR shared settings. Loaded by the content script, popup, website and service worker. */
(function (g) {
  const DEFAULTS = {
    enabled: true,
    sensory: {
      stopAutoplay: true,
      allowVideoSites: true, // do not pause the main video on sites you visit to watch video
      motion: 'gentle',      // off | gentle | strong
      freezeGifs: true,
      colorAmount: 60,       // 0-100, how strongly bright colors are desaturated (0 = off)
      stopFlashing: true,    // cover areas that flash more than 3 times a second
      quietAds: true,        // fade ad slots until you point at them
      softMedia: false,      // also tone down colors in photos and videos
      dim: 0                 // 0-40, warm dim overlay
    },
    forecast: {
      mode: 'bar',           // bar | chip | off
      collapseAfter: 7       // seconds, 0 = stay open
    },
    social: {
      toneBadges: true,
      tones: { sarcasm: true, frustrated: true, joking: true, urgent: true, indirect: true, markers: true },
      sensitivity: 'balanced', // low | balanced | high
      idioms: true,
      subtext: true,
      abbr: true,
      scope: 'social',       // social | all
      selectButton: true,    // small Explain button next to selected text
      ai: 'auto'             // auto | off. Use on-device AI models for tone when they are available
    },
    pausedNote: true,        // brief in-page note on sites where CLEAR is paused
    disabledSites: [],
    trustedHosts: ['localhost', '127.0.0.1']
  };

  const KEY = 'clearSettings';

  function isObj(v) { return v && typeof v === 'object' && !Array.isArray(v); }
  function merge(base, over) {
    const out = {};
    for (const k of Object.keys(base)) {
      const b = base[k];
      const o = over ? over[k] : undefined;
      if (isObj(b)) out[k] = merge(b, isObj(o) ? o : {});
      else if (Array.isArray(b)) out[k] = Array.isArray(o) ? o.slice() : b.slice();
      else out[k] = (o === undefined || typeof o !== typeof b) ? b : o;
    }
    return out;
  }

  /* Carry settings from older versions over to the current shape. */
  function migrate(o) {
    try {
      if (o && o.sensory && typeof o.sensory.colors === 'string' && o.sensory.colorAmount === undefined)
        o.sensory.colorAmount = ({ off: 0, gentle: 45, medium: 65, strong: 90 })[o.sensory.colors] ?? 50;
    } catch (e) {}
    return o;
  }
  /* One formula shared by the page script and the previews. amount 0-100 ->
     s: minimum saturation that counts as "bright", f: share of saturation kept (0 at 100 = grey),
     v / lmin / lmax: brightness range affected, ty: text darker than this is left alone. */
  function colorLevel(amount) {
    const a = Math.max(0, Math.min(100, Number(amount) || 0)) / 100;
    if (!(a > 0)) return null;
    return { s: 0.8 - 0.6 * a, f: Math.pow(1 - a, 1.3), v: 0.7 - 0.3 * a, lmin: 0.25 - 0.1 * a, lmax: 0.82 + 0.1 * a, ty: 0.2 - 0.15 * a };
  }
  /* c = [r, g, b, a] with values 0-1. Returns a softer CSS color, or null when the color is left alone.
     Hue is kept. Lightness moves toward how bright the color looks, so text on it stays readable. */
  function soften(c, lv, isText) {
    if (!c || !lv || c[3] < 0.4) return null;
    const r = Math.min(1, Math.max(0, c[0])), g = Math.min(1, Math.max(0, c[1])), b = Math.min(1, Math.max(0, c[2]));
    const max = Math.max(r, g, b), min = Math.min(r, g, b), d = max - min;
    if (d < 0.05) return null;
    const l = (max + min) / 2;
    const s = Math.min(1, d / (1 - Math.abs(2 * l - 1)));
    if (s < lv.s || max < lv.v || l > lv.lmax || l < lv.lmin) return null;
    const y = 0.2126 * r + 0.7152 * g + 0.0722 * b;
    if (isText && y < lv.ty) return null;
    let h = max === r ? ((g - b) / d) % 6 : max === g ? (b - r) / d + 2 : (r - g) / d + 4;
    h = Math.round(h * 60); if (h < 0) h += 360;
    const l2 = l + (y - l) * (1 - lv.f) * 0.8;
    return 'hsla(' + h + ', ' + Math.round(s * lv.f * 100) + '%, ' + Math.round(l2 * 100) + '%, ' + c[3] + ')';
  }

  function store() {
    try { return (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.sync) || null; }
    catch (e) { return null; }
  }

  g.CLEAR = {
    DEFAULTS, KEY, merge, migrate, colorLevel, soften,
    hasStore() { return !!store(); },
    load() {
      return new Promise((res) => {
        const st = store();
        if (!st) return res(merge(DEFAULTS, {}));
        try { st.get(KEY, (o) => res(merge(DEFAULTS, migrate((o && o[KEY]) || {})))); }
        catch (e) { res(merge(DEFAULTS, {})); }
      });
    },
    save(s) {
      return new Promise((res) => {
        const st = store();
        if (!st) return res(false);
        try { st.set({ [KEY]: merge(DEFAULTS, s) }, () => res(true)); }
        catch (e) { res(false); }
      });
    },
    onChange(cb) {
      try {
        chrome.storage.onChanged.addListener((c, area) => {
          if (area === 'sync' && c[KEY]) cb(merge(DEFAULTS, migrate(c[KEY].newValue || {})));
        });
      } catch (e) { /* not in an extension context */ }
    }
  };
})(globalThis);
