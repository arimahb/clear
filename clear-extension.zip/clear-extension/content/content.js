/* CLEAR content script.
   Principles: change as little as possible, never remove or rewrite page text,
   never block user-started actions, and make every change reversible. */
(() => {
  if (globalThis.__clearLoaded) return;
  globalThis.__clearLoaded = true;

  const IS_TOP = (() => { try { return window.top === window; } catch (e) { return false; } })();
  const HOST = (() => { // frames without their own address (srcdoc, about:blank) belong to the page that holds them
    let h = location.hostname;
    if (!h) { try { h = window.parent.location.hostname; } catch (e) {} }
    return (h || '').replace(/^www\./, '');
  })();
  const A = globalThis.CLEAR_ANALYZE;
  const RENDER = globalThis.CLEAR_RENDER;
  let S = CLEAR.merge(CLEAR.DEFAULTS, {});
  let ready = false;
  const stats = { media: 0, gifs: 0, anims: 0, flashes: 0, slides: 0, embeds: 0 };

  const siteOff = () => S.disabledSites.some((h) => HOST === h || HOST.endsWith('.' + h));
  const on = () => S.enabled && !siteOff();
  const send = (msg) => { try { chrome.runtime.sendMessage(msg, () => void chrome.runtime.lastError); } catch (e) {} };

  /* =====================================================================
     1. AUTOPLAY: pause media that starts without a user action.
     ===================================================================== */
  const allowedMedia = new WeakSet();
  const pausedMedia = new Set();
  const earlyMedia = new Set();
  const VIDEO_SITE = /(^|\.)(youtube\.com|youtu\.be|vimeo\.com|netflix\.com|twitch\.tv|disneyplus\.com|primevideo\.com|hulu\.com|max\.com|dailymotion\.com|spotify\.com|soundcloud\.com|tiktok\.com)$/;

  function isVideoPage() {
    if (!IS_TOP || !VIDEO_SITE.test(HOST)) return false;
    if (/youtube\.com$/.test(HOST) && !/^music\./.test(HOST)) return /^\/(watch|shorts|live|playlist)/.test(location.pathname);
    return true;
  }
  const autoplayOn = () => on() && S.sensory.stopAutoplay && !(S.sensory.allowVideoSites && isVideoPage());
  /* "The person just pressed something": a click, tap or key in the last 1.5 seconds. Chrome's own
     activation flag lasts 5 seconds, which lets unrelated autoplay slip through after any click. */
  let lastGesture = -1e9;
  for (const ev of ['pointerdown', 'pointerup', 'keydown', 'touchend']) addEventListener(ev, (e) => { if (e.isTrusted) lastGesture = performance.now(); }, { capture: true, passive: true });
  const userActive = () => performance.now() - lastGesture < 1500;
  /* Live camera or call streams are never paused. A stream drawn from a <canvas> is page decoration, so it can be. */
  const isLiveStream = (m) => {
    try {
      const so = m.srcObject;
      if (!so || typeof MediaStream === 'undefined' || !(so instanceof MediaStream)) return false;
      const tracks = so.getTracks();
      return !(tracks.length && tracks.every((t) => t.kind === 'video' && 'canvas' in t));
    } catch (e) { return false; }
  };

  const firstFrameWait = new WeakSet();
  function stopMedia(m) {
    try { m.pause(); } catch (e) { return; }
    if (!pausedMedia.has(m)) { pausedMedia.add(m); stats.media++; }
  }
  function guardMedia(m) {
    if (!autoplayOn() || allowedMedia.has(m) || isLiveStream(m)) return; // never touch video calls
    if (userActive()) { allowedMedia.add(m); pausedMedia.delete(m); return; } // the user pressed play
    if (m.paused) return;
    if (m instanceof HTMLVideoElement && m.readyState < 2 && !m.poster) {
      // Nothing has been drawn yet. Stopping now would leave an empty box, so wait (silently) for the first frame.
      if (firstFrameWait.has(m)) return;
      firstFrameWait.add(m);
      const wasMuted = m.muted; m.muted = true;
      const onFrame = () => {
        m.removeEventListener('loadeddata', onFrame);
        firstFrameWait.delete(m); m.muted = wasMuted;
        if (autoplayOn() && !allowedMedia.has(m) && !userActive()) stopMedia(m);
      };
      m.addEventListener('loadeddata', onFrame);
      return;
    }
    stopMedia(m);
  }
  document.addEventListener('play', (e) => {
    const m = e.target;
    if (!(m instanceof HTMLMediaElement)) return;
    if (!ready) { earlyMedia.add(m); return; }
    guardMedia(m);
  }, true);

  function playMedia(m) { allowedMedia.add(m); pausedMedia.delete(m); try { m.play().catch(() => {}); } catch (e) {} }
  function resumeMedia() { for (const m of [...pausedMedia]) playMedia(m); }

  /* =====================================================================
     2. MOTION: stop looping animations (they return to their resting look).
        Small loading spinners keep working. Fast flashing is always stopped.
     ===================================================================== */
  let handledAnims = new WeakSet();
  const stoppedAnims = new Set();
  let motionTimer = 0;
  const flashOn = () => on() && S.sensory.stopFlashing;

  function animProps(eff) {
    const props = new Set();
    try { for (const k of eff.getKeyframes()) for (const p in k) if (!/^(offset|computedOffset|easing|composite)$/.test(p)) props.add(p); } catch (e) {}
    return props;
  }
  function isLoadingSpinner(el, props) {
    const r = el.getBoundingClientRect();
    if (Math.max(r.width, r.height) > 56) return false;
    const quiet = props.size > 0 && [...props].every((p) => /^(transform|rotate|opacity|strokeDashoffset|strokeDasharray)$/.test(p));
    return quiet || /spin|load|progress|busy/i.test((el.getAttribute('class') || '') + ' ' + (el.getAttribute('role') || ''));
  }
  function calmAnimations() {
    if (!document.getAnimations || document.hidden) return;
    const mode = on() ? S.sensory.motion : 'off';
    let list;
    try { list = document.getAnimations(); } catch (e) { return; }
    for (const a of list) {
      if (handledAnims.has(a)) continue;
      handledAnims.add(a);
      const eff = a.effect;
      if (!eff || !eff.getComputedTiming || !eff.target) continue;
      if (eff.target.closest && eff.target.closest('clear-root')) continue;
      const t = eff.getComputedTiming();
      if (!(t.iterations === Infinity || t.iterations > 3)) continue;
      const props = animProps(eff);
      // more than three flashes a second (WCAG 2.3.1) in brightness, color or visibility
      const flashy = flashOn() && typeof t.duration === 'number' && t.duration > 0 && t.duration <= 334 &&
        [...props].some((p) => /^(opacity|visibility|backgroundColor|background|color|filter)$/.test(p));
      if (!flashy && (mode === 'off' || isLoadingSpinner(eff.target, props))) continue;
      try { a.cancel(); stoppedAnims.add(a); if (flashy) stats.flashes++; else stats.anims++; } catch (e) {}
    }
  }
  function applyMotion() {
    const mode = on() ? S.sensory.motion : 'off';
    document.documentElement.classList.toggle('clear-motion-strong', mode === 'strong');
    clearInterval(motionTimer); motionTimer = 0;
    if (mode === 'off') {
      for (const a of stoppedAnims) { try { a.play(); } catch (e) {} }
      stoppedAnims.clear(); handledAnims = new WeakSet(); stats.anims = 0;
      releaseAllHolds();
    }
    if (mode === 'off' && !flashOn()) return;
    calmAnimations();
    motionTimer = setInterval(calmAnimations, 1500);
    if (mode !== 'off') document.querySelectorAll('marquee').forEach((m) => { try { m.stop(); } catch (e) {} });
  }

  /* ---------------------------------------------------------------------
     2b. Script-driven change: slideshows that advance by themselves, and
         areas that flash. Page scripts cannot be stopped from here, so the
         look is pinned with a style rule that the script cannot override.
     --------------------------------------------------------------------- */
  let lastInput = 0;
  for (const ev of ['pointerdown', 'keydown', 'wheel', 'touchstart']) addEventListener(ev, (e) => { lastInput = performance.now(); if (ev === 'pointerdown') userTouched(e.target); }, { capture: true, passive: true });

  // -- flashing --
  const flashTrack = new WeakMap();
  const flashEls = new Map(); // element -> time of last change
  let flashTimer = 0;
  function lumOf(cs) {
    const c = toRGBA(cs.backgroundColor);
    const a = c ? c[3] : 0;
    return (c ? (0.2126 * c[0] + 0.7152 * c[1] + 0.0722 * c[2]) * a : 0) + (1 - a) * 0.5;
  }
  function noteFlash(el, now) {
    if (flashEls.has(el)) { flashEls.set(el, now); return; }
    let t = flashTrack.get(el);
    if (!t) flashTrack.set(el, (t = { times: [], sample: null, swings: 0 }));
    t.times.push(now);
    while (t.times.length && now - t.times[0] > 1000) t.times.shift();
    if (t.times.length < 3) { t.swings = 0; t.sample = null; return; }
    const cs = getComputedStyle(el);
    const smp = { lum: lumOf(cs), op: parseFloat(cs.opacity), vis: cs.visibility !== 'hidden' && cs.display !== 'none' };
    if (t.sample && (Math.abs(smp.lum - t.sample.lum) >= 0.25 || Math.abs(smp.op - t.sample.op) >= 0.5 || smp.vis !== t.sample.vis)) t.swings++;
    t.sample = smp;
    if (t.swings < 3 || t.times.length < 4) return; // four changes within one second = faster than 3 flashes a second
    const r = el.getBoundingClientRect();
    if (r.width * r.height < 4000) return;
    el.setAttribute('data-clear-flash', '');
    flashEls.set(el, now); stats.flashes++;
    if (!flashTimer) flashTimer = setInterval(() => {
      const n = performance.now();
      for (const [e, last] of flashEls) if (n - last > 2500 || !e.isConnected) { e.removeAttribute('data-clear-flash'); flashEls.delete(e); flashTrack.delete(e); }
      if (!flashEls.size) { clearInterval(flashTimer); flashTimer = 0; }
    }, 1000);
  }
  function releaseFlash() { for (const e of flashEls.keys()) e.removeAttribute('data-clear-flash'); flashEls.clear(); }

  // -- slideshows --
  const autoTrack = new WeakMap(); // parent -> {ticks: [], quietUntil}
  const heldGroups = new Set();    // {parent, targets}
  const heldParents = new WeakSet(), allowedParents = new WeakSet();
  let holdSheet = null, holdId = 0;
  const HOLD_PROPS = ['display', 'visibility', 'opacity', 'transform', 'translate', 'left', 'top', 'margin-left', 'margin-top', 'z-index'];
  function writeHoldSheet() {
    if (!holdSheet) { holdSheet = document.createElement('style'); holdSheet.setAttribute('data-clear', 'hold'); (document.head || document.documentElement).appendChild(holdSheet); }
    let css = '';
    for (const g of heldGroups) css += g.css;
    holdSheet.textContent = css;
  }
  function holdGroup(parent) {
    const targets = [parent, ...[...parent.children].slice(0, 24)].filter((e) => e instanceof HTMLElement);
    let css = '';
    for (const e of targets) {
      const id = String(++holdId), cs = getComputedStyle(e);
      css += '[data-clear-hold="' + id + '"]{' + HOLD_PROPS.map((p) => p + ':' + cs.getPropertyValue(p) + '!important').join(';') + ';transition:none!important}';
      e.setAttribute('data-clear-hold', id);
    }
    heldGroups.add({ parent, targets, css }); heldParents.add(parent); stats.slides++;
    writeHoldSheet();
  }
  function releaseGroup(g) {
    for (const e of g.targets) e.removeAttribute('data-clear-hold');
    heldGroups.delete(g); heldParents.delete(g.parent);
    writeHoldSheet();
  }
  function releaseAllHolds() { for (const g of [...heldGroups]) releaseGroup(g); stats.slides = 0; }
  function userTouched(target) { // the person is using the slideshow's own controls: let it move
    if (!heldGroups.size || !(target instanceof Node)) return;
    for (const g of [...heldGroups]) {
      const zone = g.parent.parentElement || g.parent;
      if (!zone.contains(target)) continue;
      releaseGroup(g);
      autoTrack.set(g.parent, { ticks: [], quietUntil: performance.now() + 8000 });
    }
  }
  function noteAuto(el, now) {
    const parent = el.parentElement;
    if (!parent || parent === document.body || heldParents.has(parent) || allowedParents.has(parent) || el.hasAttribute('data-clear-hold')) return;
    let t = autoTrack.get(parent);
    if (!t) autoTrack.set(parent, (t = { ticks: [], quietUntil: 0 }));
    if (now < t.quietUntil) return;
    if (now - lastInput < 1000) { t.ticks = []; return; }          // caused by the person, not a timer
    const last = t.ticks[t.ticks.length - 1];
    if (last !== undefined && now - last < 150) return;              // same step
    if (last !== undefined && now - last < 1000) { t.ticks = [now]; return; } // too fast to be a slideshow
    t.ticks.push(now);
    if (t.ticks.length > 4) t.ticks.shift();
    if (t.ticks.length < 3) return;
    const gaps = t.ticks.slice(1).map((v, i) => v - t.ticks[i]);
    if (Math.max(...gaps) > 20000 || Math.max(...gaps) / Math.min(...gaps) > 1.7) return;
    const r = parent.getBoundingClientRect();
    if (r.width < 150 || r.height < 60 || parent.closest('video, [class*="player" i], clear-root')) { t.quietUntil = now + 60000; return; }
    holdGroup(parent);
  }
  function watchChanges(records) {
    const motion = on() && S.sensory.motion !== 'off', flash = flashOn();
    if (!motion && !flash) return;
    const now = performance.now();
    const seen = new Set();
    for (const r of records) {
      if (r.type !== 'attributes' || (r.attributeName !== 'style' && r.attributeName !== 'class')) continue;
      const t = r.target;
      if (seen.has(t) || !(t instanceof HTMLElement) || t === document.body || t === document.documentElement) continue;
      seen.add(t);
      if (seen.size > 60) break; // heavy script animation: not our case
      if (flash && r.attributeName === 'style') noteFlash(t, now);
      if (motion) noteAuto(t, now);
    }
  }

  /* ---------------------------------------------------------------------
     2c. Embedded players and ad slots.
     --------------------------------------------------------------------- */
  const embedsDone = new WeakMap(); // iframe -> original allow value
  function scanEmbeds() {
    if (!autoplayOn()) return;
    for (const f of document.querySelectorAll('iframe[allow*="autoplay" i], iframe[src*="autoplay=1"], iframe[src*="autoplay=true"]')) {
      if (embedsDone.has(f)) continue;
      const allow = f.getAttribute('allow');
      embedsDone.set(f, allow);
      if (allow && /autoplay/i.test(allow)) {
        const rest = allow.split(';').map((x) => x.trim()).filter((x) => x && !/^autoplay\b/i.test(x)).join('; ');
        rest ? f.setAttribute('allow', rest) : f.removeAttribute('allow');
      }
      const src = f.getAttribute('src') || '';
      if (/[?&]autoplay=(?:1|true)\b/.test(src)) f.setAttribute('src', src.replace(/([?&]autoplay=)(?:1|true)\b/, '$10')); // reloads the player without autoplay
      stats.embeds++;
    }
  }
  const adEls = new Set();
  function scanAds() {
    if (!(on() && S.sensory.quietAds)) return;
    let list;
    try { list = [...document.querySelectorAll(AD_SEL)].slice(0, 200); } catch (e) { return; }
    for (const e of list) {
      if (adEls.has(e) || e.closest('[data-clear-ad]')) continue;
      const r = e.getBoundingClientRect();
      if (r.width < 50 || r.height < 50) continue;
      e.setAttribute('data-clear-ad', ''); adEls.add(e);
    }
  }
  function applyAds() {
    if (on() && S.sensory.quietAds) return scanAds();
    for (const e of adEls) e.removeAttribute('data-clear-ad');
    adEls.clear();
  }

  /* =====================================================================
     3. GIFs: show a still first frame. The <img> itself stays where it is,
        so page layout, lazy loading and links keep working. A "Play" button
        appears when the pointer is over a paused GIF or video.
     ===================================================================== */
  const frozenGifs = new Map();   // img -> {src, srcset, sources, still}
  let gifChecked = new WeakMap(); // img -> address already examined
  const gifUrl = (img) => img.currentSrc || img.src || '';
  const isGifUrl = (u) => /^data:image\/gif/i.test(u) || (!u.startsWith('data:') && (/\.gif(?:[?#]|$)/i.test(u) || /(?:giphy|tenor)\.com\/.*gif/i.test(u)));
  const isGif = (img) => frozenGifs.has(img) || isGifUrl(gifUrl(img));
  const gifsOn = () => on() && S.sensory.freezeGifs;

  function showStill(img, rec) {
    for (const [so] of rec.sources) so.setAttribute('srcset', rec.still);
    if (rec.srcset !== null) img.setAttribute('srcset', rec.still);
    img.setAttribute('src', rec.still);
  }
  function unfreezeGif(img) {
    const rec = frozenGifs.get(img);
    if (!rec) return;
    frozenGifs.delete(img);
    for (const [so, v] of rec.sources) v === null ? so.removeAttribute('srcset') : so.setAttribute('srcset', v);
    if (rec.srcset !== null) img.setAttribute('srcset', rec.srcset);
    rec.src === null ? img.removeAttribute('src') : img.setAttribute('src', rec.src);
  }
  function freezeGif(img) {
    if (!gifsOn() || img.dataset.clearGif === 'played') return;
    const url = gifUrl(img);
    if (!url || !isGifUrl(url) || url.startsWith('blob:') || gifChecked.get(img) === url || url.length > 3e6) return;
    if (!img.complete || !img.naturalWidth) { img.addEventListener('load', () => freezeGif(img), { once: true }); return; }
    gifChecked.set(img, url);
    if (img.clientWidth < 48 || img.clientHeight < 48) return; // icons and placeholders are left alone
    try {
      // The service worker downloads the file, checks that it really is animated, and returns its first frame.
      chrome.runtime.sendMessage({ type: 'gif-still', url }, (r) => {
        void chrome.runtime.lastError;
        if (!r || !r.ok || !gifsOn() || !img.isConnected || gifUrl(img) !== url || img.dataset.clearGif === 'played') return;
        const pic = img.parentElement && img.parentElement.tagName === 'PICTURE' ? img.parentElement : null;
        const rec = { src: img.getAttribute('src'), srcset: img.getAttribute('srcset'), sources: [], still: r.still };
        if (pic) for (const so of pic.querySelectorAll('source')) rec.sources.push([so, so.getAttribute('srcset')]);
        frozenGifs.set(img, rec);
        showStill(img, rec);
        img.dataset.clearGif = 'frozen';
        stats.gifs++;
      });
    } catch (e) {}
  }
  function scanGifs() {
    if (!gifsOn()) return;
    for (const img of document.images) {
      const rec = frozenGifs.get(img);
      if (rec) { if (img.getAttribute('src') !== rec.still && isGifUrl(gifUrl(img))) showStill(img, rec); } // the site put the GIF back
      else if (isGifUrl(gifUrl(img))) freezeGif(img);
    }
    if (frozenGifs.size > 200) for (const img of [...frozenGifs.keys()]) if (!img.isConnected) frozenGifs.delete(img);
  }
  function applyGifs() {
    if (gifsOn()) return scanGifs();
    for (const img of [...frozenGifs.keys()]) { unfreezeGif(img); delete img.dataset.clearGif; }
    gifChecked = new WeakMap();
  }

  /* =====================================================================
     4. COLORS: desaturate bright, highly saturated colors in backgrounds,
        gradients, borders, text and SVG shapes. Hue and lightness are kept,
        so the page keeps its look. Photos are untouched unless asked.
     ===================================================================== */
  let colorAmount = 0, colorLv = null; // amount 0-100 from the slider
  let colorSeen = new WeakSet();
  const colorTouched = new Map(); // element -> {prop: [value, priority]}
  let colorQueue = [], colorBusy = false, colorMore = false;
  const rgbCache = new Map();
  let probe = null;

  function toRGBA(str) {
    let m = /^rgba?\(([^)]+)\)$/.exec(str);
    if (m) { const p = m[1].split(/[\s,\/]+/).map(parseFloat); return [p[0] / 255, p[1] / 255, p[2] / 255, p[3] === undefined || isNaN(p[3]) ? 1 : p[3]]; }
    m = /^color\(srgb ([^)]+)\)$/.exec(str);
    if (m) { const p = m[1].split(/[\s\/]+/).map(parseFloat); return [p[0], p[1], p[2], p[3] === undefined || isNaN(p[3]) ? 1 : p[3]]; }
    if (!/^(?:oklch|oklab|lab|lch|hsl|hwb|color|color-mix)\(/.test(str)) return null;
    if (rgbCache.has(str)) return rgbCache.get(str);
    let out = null;
    try { // let the browser convert any other color space
      probe = probe || document.createElement('canvas').getContext('2d', { willReadFrequently: true });
      probe.clearRect(0, 0, 1, 1); probe.fillStyle = '#000'; probe.fillStyle = str; probe.fillRect(0, 0, 1, 1);
      const d = probe.getImageData(0, 0, 1, 1).data;
      out = [d[0] / 255, d[1] / 255, d[2] / 255, d[3] / 255];
    } catch (e) {}
    if (rgbCache.size < 500) rgbCache.set(str, out);
    return out;
  }
  function softened(str, lv, isText) {
    if (!str || str === 'none' || str === 'transparent') return null;
    return CLEAR.soften(toRGBA(str), lv, isText);
  }
  function softGradient(str, lv) {
    if (str.length > 2000) return null;
    let changed = false;
    const out = str.replace(/rgba?\([^)]*\)|color\(srgb [^)]*\)|okl(?:ch|ab)\([^)]*\)/g, (m) => {
      const v = softened(m, lv, false);
      if (v) { changed = true; return v; }
      return m;
    });
    return changed ? out : null;
  }
  function hasOwnText(el) {
    for (let n = el.firstChild; n; n = n.nextSibling) if (n.nodeType === 3 && n.nodeValue.trim()) return true;
    return false;
  }
  function setP(el, rec, prop, val, orig) {
    rec[prop] = [el.style.getPropertyValue(prop), el.style.getPropertyPriority(prop), orig];
    el.style.setProperty(prop, val, 'important');
  }
  function softenEl(el, lv) {
    const cs = getComputedStyle(el);
    const rec = {};
    if (el instanceof SVGElement) {
      if (!(el instanceof SVGGeometryElement) && el.tagName !== 'text') return;
      const f = softened(cs.fill, lv, false), st = softened(cs.stroke, lv, false);
      if (!f && !st) return;
      const r = el.getBoundingClientRect();
      if (r.width < 12 || r.height < 12) return;
      if (f) setP(el, rec, 'fill', f, cs.fill);
      if (st) setP(el, rec, 'stroke', st, cs.stroke);
    } else {
      const bg = softened(cs.backgroundColor, lv, false);
      const bi = cs.backgroundImage;
      const gi = bi && bi.includes('gradient(') ? softGradient(bi, lv) : null;
      if (bg || gi) {
        const r = el.getBoundingClientRect();
        if (!r.width && !r.height) colorSeen.delete(el); // hidden for now (a closed pop-up, say): look again later
        if (r.width >= 24 && r.height >= 12) {
          if (bg) setP(el, rec, 'background-color', bg, cs.backgroundColor);
          if (gi) setP(el, rec, 'background-image', gi, bi);
        }
      }
      if (hasOwnText(el)) { const fg = softened(cs.color, lv, true); if (fg) setP(el, rec, 'color', fg, cs.color); }
      for (const side of ['top', 'right', 'bottom', 'left']) {
        if (parseFloat(cs.getPropertyValue('border-' + side + '-width')) < 2) continue;
        const orig = cs.getPropertyValue('border-' + side + '-color');
        const bc = softened(orig, lv, false);
        if (bc) setP(el, rec, 'border-' + side + '-color', bc, orig);
      }
      for (const prop of ['text-shadow', 'box-shadow']) {
        const orig = cs.getPropertyValue(prop);
        if (!orig || orig === 'none') continue;
        const v = softGradient(orig, lv);
        if (v) setP(el, rec, prop, v, orig);
      }
    }
    for (const k in rec) { colorTouched.set(el, rec); break; }
  }
  const idle = (fn) => (window.requestIdleCallback ? requestIdleCallback(fn, { timeout: 1500 }) : setTimeout(fn, 200));
  function drainColors(deadline) {
    const lv = colorLv;
    let n = 0;
    while (lv && colorQueue.length && n < 300 && (!deadline || deadline.timeRemaining() > 2 || n < 40)) {
      const el = colorQueue.pop();
      if (el.isConnected) softenEl(el, lv);
      n++;
    }
    if (lv && colorQueue.length) return idle(drainColors);
    colorBusy = false; colorQueue = [];
    if (colorMore) scanColors(); // large pages are covered in several passes
  }
  function scanColors() {
    if (!colorLv || !document.body) return;
    const all = document.body.getElementsByTagName('*');
    const fresh = [];
    colorMore = false;
    for (const top of [document.documentElement, document.body]) if (!colorSeen.has(top)) { colorSeen.add(top); fresh.push(top); } // page background
    for (let i = 0; i < all.length; i++) {
      const el = all[i];
      if (colorSeen.has(el)) continue;
      if (fresh.length >= 2000) { colorMore = true; break; }
      colorSeen.add(el);
      if ((el instanceof HTMLElement || el instanceof SVGElement) && el.tagName !== 'CLEAR-ROOT') fresh.push(el);
    }
    if (!fresh.length) return;
    colorQueue = fresh.reverse().concat(colorQueue);
    if (!colorBusy) { colorBusy = true; idle(drainColors); }
  }
  function restoreOne(el) {
    const rec = colorTouched.get(el);
    if (!rec) return;
    for (const prop in rec) rec[prop][0] ? el.style.setProperty(prop, rec[prop][0], rec[prop][1]) : el.style.removeProperty(prop);
    colorTouched.delete(el);
  }
  function restoreColors() {
    for (const el of [...colorTouched.keys()]) restoreOne(el);
    colorSeen = new WeakSet(); colorQueue = [];
  }
  /* A class change can give an element a new color (hover states, themes). Re-check it. */
  function colorClassChanged(records) {
    const lv = colorLv;
    if (!lv) return;
    let n = 0;
    for (const r of records) {
      if (r.type !== 'attributes' || r.attributeName !== 'class') continue;
      const t = r.target;
      if (t === document.documentElement || t === document.body) { colorSeen = new WeakSet(); continue; }
      if (!(t instanceof Element)) continue;
      if (++n <= 40) { restoreOne(t); softenEl(t, lv); }
      if (!colorTouched.has(t)) colorSeen.delete(t); // look again on the next pass, after any CSS transition has finished
      if (t.childElementCount && n <= 10) { let k = 0; for (const d of t.getElementsByTagName('*')) { if (++k > 300) break; if (!colorTouched.has(d)) colorSeen.delete(d); } }
    }
  }
  /* The slider moved: recompute from the remembered original colors, so nothing flashes. */
  function relevel(lv) {
    for (const [el, rec] of [...colorTouched]) {
      for (const prop of Object.keys(rec)) {
        const [val, prio, orig] = rec[prop];
        const v = !lv ? null : /image|shadow/.test(prop) ? softGradient(orig, lv) : softened(orig, lv, prop === 'color');
        if (v) el.style.setProperty(prop, v, 'important');
        else { val ? el.style.setProperty(prop, val, prio) : el.style.removeProperty(prop); delete rec[prop]; }
      }
      if (!Object.keys(rec).length) colorTouched.delete(el);
    }
  }
  function applyColors() {
    const root = document.documentElement;
    const want = on() ? S.sensory.colorAmount : 0;
    root.classList.toggle('clear-soft-media', want > 0 && S.sensory.softMedia);
    if (want > 0 && S.sensory.softMedia) root.style.setProperty('--clear-sat', String(1 - 0.6 * want / 100)); else root.style.removeProperty('--clear-sat');
    if (want === colorAmount) return;
    colorAmount = want; colorLv = CLEAR.colorLevel(want);
    relevel(colorLv);
    colorSeen = new WeakSet(); colorQueue = [];
    for (const el of colorTouched.keys()) colorSeen.add(el);
    scanColors();
  }

  /* =====================================================================
     5. SOCIAL: tone labels and decoded phrases. Uses an attribute and the
        CSS Highlight API, so the page's own DOM nodes are never rewritten.
     ===================================================================== */
  const SITES = [
    [/(^|\.)(twitter|x)\.com$/, '[data-testid="tweetText"]'],
    [/(^|\.)reddit\.com$/, '[slot="comment"], [slot="text-body"], [data-testid="comment"], .usertext-body .md, [id$="-post-rtjson-content"]'],
    [/^mail\.google\.com$/, '.a3s'],
    [/outlook\.(live|office|office365)\.com$/, '[aria-label="Message body"]'],
    [/mail\.yahoo\.com$/, '[data-test-id="message-view-body"]'],
    [/proton\.me$/, '.message-content'],
    [/news\.ycombinator\.com$/, '.commtext'],
    [/(^|\.)youtube\.com$/, '#content-text'],
    [/(^|\.)facebook\.com$/, '[data-ad-preview="message"], [data-ad-comet-preview="message"], div[role="article"] div[dir="auto"]'],
    [/(^|\.)linkedin\.com$/, '.update-components-text, .comments-comment-item__main-content, .feed-shared-inline-show-more-text'],
    [/bsky\.app$/, '[data-testid="postText"]'],
    [/(^|\.)threads\.(net|com)$/, 'div[data-pressable-container] span[dir="auto"]'],
    [/discord\.com$/, '[id^="message-content-"]'],
    [/slack\.com$/, '.p-rich_text_section'],
    [/web\.whatsapp\.com$/, '.copyable-text .selectable-text'],
    [/(^|\.)tumblr\.com$/, 'article p'],
    [/(stackoverflow|stackexchange|superuser|serverfault|askubuntu)\.com$/, '.comment-copy']
  ];
  const GENERIC = '.comment-body, .comment-content, .comment-text, .comment__body, .comment-message, .status__content, .cooked, .message-body, .post-message, .bbWrapper, [itemprop="commentText"], [data-clear-scan]';
  const EVERYWHERE = 'p, li, blockquote, dd';
  const siteSel = (SITES.find(([re]) => re.test(HOST)) || [])[1];

  const blockText = new WeakMap();   // element -> last analysed text
  const toneInfo = new WeakMap();    // element -> tone result
  const toneEls = new Set();
  const nodePhrases = new WeakMap(); // text node -> [{start,end,match,meaning,range}]
  const phraseNodes = new Set();
  let highlight = null;
  let phraseCount = 0;
  const decoded = new Map();         // phrase -> meaning (for the forecast panel)

  const socialOn = () => on() && (S.social.toneBadges || S.social.idioms || S.social.subtext || S.social.abbr);
  const SKIP = 'code, pre, textarea, input, script, style, noscript, [contenteditable=""], [contenteditable="true"], clear-root';

  function getHighlight() {
    if (highlight) return highlight;
    try {
      if (typeof Highlight === 'undefined' || !CSS.highlights) return null;
      highlight = new Highlight();
      CSS.highlights.set('clear-phrase', highlight);
    } catch (e) { highlight = null; }
    return highlight;
  }
  function clearNode(node) {
    const list = nodePhrases.get(node);
    if (!list) return;
    for (const p of list) { if (highlight) highlight.delete(p.range); phraseCount--; }
    nodePhrases.delete(node); phraseNodes.delete(node);
  }
  function markPhrases(el) {
    const hl = getHighlight();
    if (!hl) return;
    const opts = { idioms: S.social.idioms, subtext: S.social.subtext, abbr: S.social.abbr };
    const walker = document.createTreeWalker(el, NodeFilter.SHOW_TEXT);
    let node;
    while ((node = walker.nextNode())) {
      clearNode(node);
      const v = node.nodeValue;
      if (v.length < 3 || !node.parentElement || node.parentElement.closest(SKIP)) continue;
      const found = A.findPhrases(v, opts);
      if (!found.length) continue;
      const list = [];
      for (const f of found) {
        const range = document.createRange();
        range.setStart(node, f.start); range.setEnd(node, f.end);
        hl.add(range);
        list.push({ start: f.start, end: f.end, match: f.match, meaning: f.meaning, range });
        phraseCount++;
        if (decoded.size < 40) decoded.set(f.match.toLowerCase(), f.meaning);
      }
      nodePhrases.set(node, list); phraseNodes.add(node);
    }
  }
  function processBlock(el) {
    if (el.closest(SKIP) || el.isContentEditable) return;
    const text = el.textContent;
    if (blockText.get(el) === text) return;
    blockText.set(el, text);
    if (S.social.idioms || S.social.subtext || S.social.abbr) markPhrases(el);
    let t = null;
    if (S.social.toneBadges && text.length <= 1500) t = A.tone(text, S.social);
    if (t) { el.setAttribute('data-clear-tone', t.label); toneInfo.set(el, t); toneEls.add(el); }
    else if (el.hasAttribute('data-clear-tone')) { el.removeAttribute('data-clear-tone'); toneEls.delete(el); }
    if (!(t && t.strong)) watchIrony(el);
  }
  /* When the sarcasm model is installed, posts that are on screen are also read by it.
     Results are cached, sent in small batches, and never block the page. */
  const ironyCache = new Map();
  const ironyQueue = new Set();
  let ironyBusy = false, ironyIO = null;
  /* A model result can confirm or deny a sarcasm label on a post, never start one by itself.
     The gate is a conflict: praise with nothing in it next to a situation the sentiment model
     reads as bad. Careful also wants the irony model to agree; Eager accepts strong irony alone. */
  const modelLabels = () => model.state === 'ready' && S.social.ai === 'auto' && S.social.toneBadges && S.social.tones.sarcasm !== false && socialOn();
  function applyIrony(elm, text, res) {
    if (!elm.isConnected || blockText.get(elm) !== elm.textContent || elm.textContent.trim() !== text) return;
    const cur = toneInfo.get(elm), has = elm.hasAttribute('data-clear-tone');
    const ruled = has && cur && cur.key === 'sarcasm';
    const sens = S.social.sensitivity;
    const conflict = res.conflict != null && (sens !== 'low' || res.irony >= 0.5);
    const eager = sens === 'high' && res.bare && res.irony >= 0.9;
    const pct = Math.round(res.irony * 100);

    if (conflict || eager) {
      if (has && !ruled) return; // keep a clear label of another tone
      const firm = ruled || (conflict && res.irony >= 0.6);
      const t = { key: 'sarcasm', label: firm ? 'Sarcasm' : 'Sarcasm?', title: 'Possibly sarcastic', strong: ruled && cur.strong,
        detail: 'The writer may mean the opposite of the literal words. Why: ' +
          (conflict ? res.why + '; the irony model rates this ' + pct + '% likely to be sarcastic.'
                    : 'the irony model rates this ' + pct + '% likely to be sarcastic. Nothing in the message contradicts the praise, so this is a weak guess.') };
      elm.setAttribute('data-clear-tone', t.label); toneInfo.set(elm, t); toneEls.add(elm);
    } else if (ruled && !cur.strong && res.irony <= 0.2) {
      elm.removeAttribute('data-clear-tone'); toneEls.delete(elm); // the rules guessed, both models disagree
    }
  }
  function pumpIrony() {
    if (ironyBusy || !ironyQueue.size || !modelLabels()) return;
    const batch = [...ironyQueue].slice(0, 8);
    batch.forEach((e) => ironyQueue.delete(e));
    const items = batch.filter((e) => e.isConnected).map((e) => [e, e.textContent.trim()]).filter(([, t]) => t.length >= 15 && t.length <= 500);
    const need = [...new Set(items.map(([, t]) => t).filter((t) => !ironyCache.has(t)))];
    const finish = () => { for (const [e, t] of items) if (ironyCache.has(t)) applyIrony(e, t, ironyCache.get(t)); ironyBusy = false; pumpIrony(); };
    if (!need.length) { ironyBusy = true; return finish(); }
    ironyBusy = true;
    ask({ type: 'ai-irony', texts: need }, (r) => {
      if (r && r.ok && r.scores) need.forEach((t, i) => { if (ironyCache.size > 1500) ironyCache.clear(); if (r.scores[i]) ironyCache.set(t, r.scores[i]); });
      finish();
    });
  }
  function watchIrony(elm) {
    if (!modelLabels()) return;
    const n = elm.textContent.trim().length;
    if (n < 15 || n > 500) return;
    if (!ironyIO) ironyIO = new IntersectionObserver((entries) => {
      for (const en of entries) if (en.isIntersecting) { ironyIO.unobserve(en.target); ironyQueue.add(en.target); }
      pumpIrony();
    }, { rootMargin: '200px' });
    ironyIO.observe(elm);
  }

  function leafBlocks(el) {
    const kids = el.querySelectorAll('p, li, blockquote, div');
    const out = [];
    for (const k of kids) {
      if (!k.querySelector('p, li, blockquote, div') && k.textContent.trim().length >= 4) out.push(k);
    }
    return out.length ? out : [el];
  }
  function scanSocial() {
    if (!socialOn() || !document.body) return;
    let sel = siteSel ? siteSel + ', ' + GENERIC : GENERIC;
    if (S.social.scope === 'all') sel += ', ' + EVERYWHERE;
    let cands;
    try { cands = document.body.querySelectorAll(sel); } catch (e) { return; }
    let n = 0;
    for (const c of cands) {
      for (const b of leafBlocks(c)) { processBlock(b); if (++n > 800) return; }
    }
    if (phraseNodes.size > 400) for (const node of [...phraseNodes]) if (!node.isConnected) clearNode(node);
    if (toneEls.size > 400) for (const el of [...toneEls]) if (!el.isConnected) toneEls.delete(el);
  }
  function resetSocial() {
    for (const el of toneEls) el.removeAttribute('data-clear-tone');
    toneEls.clear();
    for (const node of [...phraseNodes]) clearNode(node);
    if (highlight) highlight.clear();
    phraseCount = 0; decoded.clear(); ironyQueue.clear();
    // WeakMaps cannot be cleared, so invalidate cached text by scanning with fresh maps
    socialEpoch++;
  }
  let socialEpoch = 0, appliedEpochKey = '';
  function applySocial() {
    const key = JSON.stringify([on(), S.social, model.state === 'ready']);
    if (key === appliedEpochKey) return;
    appliedEpochKey = key;
    resetSocial();
    // force re-analysis: wipe cached text for connected candidates
    if (document.body) for (const el of document.body.querySelectorAll('*')) blockText.delete(el);
    scanSocial();
  }

  /* =====================================================================
     6. UI (shadow DOM): forecast bar, chip, details, tooltip, explain panel.
     ===================================================================== */
  let ui = null;
  const UI_CSS = `
    :host { all: initial; }
    * { box-sizing: border-box; }
    [hidden] { display: none !important; }
    .box { font: 13px/1.45 system-ui, -apple-system, "Segoe UI", Roboto, sans-serif; color: #2f3a40;
      background: #f7f5ef; border: 1px solid #d8d4c6; box-shadow: 0 4px 18px rgba(40,50,55,.13); }
    button { font: inherit; color: inherit; cursor: pointer; background: none; border: 0; padding: 0; }
    button:focus-visible { outline: 2px solid #5f8575; outline-offset: 2px; }
    #dim { position: fixed; inset: 0; pointer-events: none; background: #3c2300; opacity: 0; }
    #bar { position: fixed; top: 10px; left: 50%; transform: translateX(-50%); max-width: min(760px, calc(100vw - 24px));
      display: flex; align-items: center; gap: 10px; padding: 7px 8px 7px 14px; border-radius: 999px; white-space: nowrap; }
    #bar-items { overflow: hidden; text-overflow: ellipsis; color: #4d5a61; }
    .dot { width: 9px; height: 9px; border-radius: 50%; background: #7fa890; flex: none; display: inline-block; }
    .dot.moderate { background: #c9a961; } .dot.busy { background: #b9795f; }
    .pill { padding: 3px 10px; border-radius: 999px; border: 1px solid #cfcabb; background: #fff; }
    .pill:hover { background: #eef2ee; }
    .x { width: 24px; height: 24px; border-radius: 50%; font-size: 16px; line-height: 1; color: #66737a; }
    .x:hover { background: #e7e4da; }
    #chip { position: fixed; right: 14px; bottom: 14px; display: flex; align-items: center; gap: 7px; padding: 6px 12px;
      border-radius: 999px; font-weight: 600; font-size: 12px; letter-spacing: .04em; opacity: .82; }
    #chip:hover { opacity: 1; }
    #panel { position: fixed; right: 14px; bottom: 54px; width: 320px; max-width: calc(100vw - 28px); max-height: min(70vh, 560px);
      overflow: auto; border-radius: 14px; padding: 14px 16px; }
    #explain { position: fixed; right: 14px; top: 14px; width: 380px; max-width: calc(100vw - 28px); max-height: calc(100vh - 28px);
      overflow: auto; border-radius: 14px; padding: 14px 16px 16px; }
    h2 { font-size: 14px; margin: 0; font-weight: 650; }
    h3 { font-size: 11px; margin: 14px 0 5px; font-weight: 650; letter-spacing: .06em; text-transform: uppercase; color: #5f8575; }
    .head { display: flex; align-items: center; justify-content: space-between; gap: 8px; }
    ul { margin: 0; padding: 0; list-style: none; }
    li { padding: 3px 0; }
    li.sub { color: #5b686f; }
    .actions { display: flex; flex-wrap: wrap; gap: 6px; margin-top: 12px; }
    .quote { background: #fff; border: 1px solid #e2dfd3; border-radius: 8px; padding: 8px 10px; white-space: pre-wrap; overflow-wrap: anywhere; }
    .dec { border-bottom: 2px dotted #5f8575; }
    .mean { color: #47705f; font-weight: 600; }
    .tag { display: inline-block; padding: 1px 7px; border-radius: 5px; background: #e4ebe6; font-weight: 600; margin-right: 6px; }
    .muted { color: #66737a; }
    .small { font-size: 12px; }
    #tip { position: fixed; max-width: 300px; border-radius: 9px; padding: 8px 11px; pointer-events: none; }
    #tip b { display: block; margin-bottom: 2px; }
    #sel { position: fixed; display: flex; align-items: center; border-radius: 999px; font-weight: 600; font-size: 12px; overflow: hidden; }
    #sel button { padding: 4px 11px; } #sel .sep { width: 1px; align-self: stretch; background: #d8d4c6; }
    #sel button:hover, #play:hover { background: #eef2ee; }
    #play { position: fixed; padding: 4px 11px; border-radius: 999px; font-weight: 600; font-size: 12px; }
    #note { position: fixed; right: 14px; bottom: 14px; display: flex; align-items: center; gap: 10px; padding: 7px 8px 7px 14px; border-radius: 999px; }
    .dot.off { background: #a9b0b3; }
    .ctx label { display: flex; gap: 8px; align-items: flex-start; padding: 3px 0; cursor: pointer; }
    .ctx input { margin: 3px 0 0; accent-color: #5f8575; flex: none; }
    .ctx .where { color: #66737a; font-size: 11px; text-transform: uppercase; letter-spacing: .04em; flex: none; width: 40px; padding-top: 2px; }
    .ctx .line { overflow-wrap: anywhere; }
    .engine { margin-top: 12px; padding-top: 10px; border-top: 1px solid #dedacd; }
    button:disabled { opacity: .6; cursor: default; }
    .ctx .here { margin: 4px 0 4px 21px; padding: 4px 9px; border-left: 3px solid #5f8575; background: #e4ebe6; border-radius: 0 6px 6px 0; font-weight: 600; overflow-wrap: anywhere; }
    .ctx .more { display: block; margin: 4px 0 4px 21px; font-size: 12px; color: #47705f; text-decoration: underline; }
    #tip .foot { display: block; margin-top: 4px; font-size: 11px; color: #66737a; }
    @media (prefers-color-scheme: dark) {
      .box { color: #dfe5e3; background: #252b2e; border-color: #3b4448; box-shadow: 0 4px 18px rgba(0,0,0,.4); }
      #bar-items, li.sub, .muted, #tip .foot, .x { color: #a3afb0; }
      #sel button:hover, #play:hover { background: #374145; } #sel .sep { background: #3b4448; } .ctx .where { color: #a3afb0; } .ctx .here { background: #34423c; } .ctx .more { color: #94bba8; }
      .pill { background: #2e3639; border-color: #465055; } .pill:hover { background: #374145; }
      .x:hover { background: #374145; }
      .quote { background: #1e2326; border-color: #3b4448; }
      .tag { background: #34423c; } .mean, h3 { color: #94bba8; }
    }`;
  const UI_HTML = `
    <div id="dim"></div>
    <div id="bar" class="box" role="status" aria-label="CLEAR page forecast" hidden>
      <span class="dot" id="bar-dot"></span><strong id="bar-level"></strong><span id="bar-items"></span>
      <button class="pill" id="bar-more">Details</button>
      <button class="x" id="bar-close" aria-label="Minimize page forecast">×</button>
    </div>
    <button id="chip" class="box" aria-label="Open CLEAR page forecast" hidden><span class="dot" id="chip-dot"></span>CLEAR</button>
    <div id="panel" class="box" role="dialog" aria-label="Page forecast details" hidden>
      <div class="head"><h2 id="panel-title">Page forecast</h2><button class="x" id="panel-close" aria-label="Close">×</button></div>
      <h3>What is on this page</h3><ul id="panel-items"></ul>
      <div id="panel-did-wrap"><h3>What CLEAR changed</h3><ul id="panel-did"></ul></div>
      <div id="panel-dec-wrap"><h3>Phrases decoded</h3><ul id="panel-dec"></ul></div>
      <div class="actions">
        <button class="pill" id="act-play" hidden>Play paused videos</button>
        <button class="pill" id="act-site">Pause CLEAR on this site</button>
        <button class="pill" id="act-hide">Hide on this page</button>
        <button class="pill" id="act-settings">Settings</button>
      </div>
    </div>
    <aside id="explain" class="box" role="dialog" aria-label="CLEAR explanation" hidden>
      <div class="head"><h2>What this message means</h2><button class="x" id="explain-close" aria-label="Close">×</button></div>
      <div id="explain-body"></div>
      <div id="explain-simple"></div>
      <div id="explain-ctx" class="ctx"></div>
      <div id="explain-ai"></div>
      <div class="muted small" style="margin-top:12px">CLEAR reads wording only. It cannot know what the writer feels.</div>
    </aside>
    <div id="sel" class="box" hidden><button id="sel-explain">Explain</button><span class="sep"></span><button id="sel-simplify">Simplify</button></div>
    <button id="play" class="box" hidden></button>
    <div id="note" class="box" role="status" hidden><span class="dot off"></span><span id="note-text"></span><button class="pill" id="note-resume">Resume</button><button class="x" id="note-close" aria-label="Dismiss">×</button></div>
    <div id="tip" class="box" role="tooltip" hidden></div>`;

  function ensureUI() {
    if (ui) return ui;
    const host = document.createElement('clear-root');
    host.style.cssText = 'all:initial;position:fixed;top:0;left:0;width:0;height:0;z-index:2147483646;';
    const root = host.attachShadow({ mode: 'closed' });
    root.innerHTML = '<style>' + UI_CSS + '</style>' + UI_HTML;
    (document.documentElement || document.body).appendChild(host);
    const $ = (id) => root.getElementById(id);
    ui = { host, root, $ };
    $('sel').addEventListener('mousedown', (e) => e.preventDefault()); // keep the selection
    $('sel-explain').addEventListener('click', () => { $('sel').hidden = true; explainSelection(false); });
    $('sel-simplify').addEventListener('click', () => { $('sel').hidden = true; explainSelection(true); });
    $('play').addEventListener('click', () => {
      const t = playTarget; playTarget = null; $('play').hidden = true;
      if (!t) return;
      if (!(t instanceof Element)) { allowedParents.add(t.parent); releaseGroup(t); return; }
      if (t instanceof HTMLMediaElement) playMedia(t);
      else { unfreezeGif(t); t.dataset.clearGif = 'played'; }
    });
    if (IS_TOP) {
      $('bar-more').addEventListener('click', () => { collapseBar(); openPanel(); });
      $('bar-close').addEventListener('click', collapseBar);
      $('bar').addEventListener('mouseenter', () => clearTimeout(barTimer));
      $('chip').addEventListener('click', () => ($('panel').hidden ? openPanel() : closePanel()));
      $('panel-close').addEventListener('click', closePanel);
      $('explain-close').addEventListener('click', closeExplain);
      $('note-close').addEventListener('click', () => { $('note').hidden = true; });
      $('note-resume').addEventListener('click', async () => {
        const st = await CLEAR.load();
        st.disabledSites = st.disabledSites.filter((h) => !(HOST === h || HOST.endsWith('.' + h)));
        CLEAR.save(st); $('note').hidden = true;
      });
      $('act-play').addEventListener('click', () => { resumeMedia(); send({ type: 'resume-media' }); renderPanel(); });
      $('act-site').addEventListener('click', async () => {
        const s = await CLEAR.load();
        if (!s.disabledSites.includes(HOST)) s.disabledSites.push(HOST);
        CLEAR.save(s);
      });
      $('act-hide').addEventListener('click', () => { forecastHidden = true; closePanel(); $('chip').hidden = true; $('bar').hidden = true; });
      $('act-settings').addEventListener('click', () => send({ type: 'open-settings' }));
    }
    return ui;
  }
  const el = RENDER.el;

  /* ---------- forecast ---------- */
  let forecast = null, forecastHidden = false, barTimer = 0, barShown = false;
  const FEED = /(^|\.)(x|twitter|facebook|instagram|tiktok|reddit|linkedin|pinterest|tumblr|threads|bsky)\.(com|app|net)$/;
  const AD_SEL = 'ins.adsbygoogle,[id^="google_ads"],[id^="div-gpt-ad"],[data-ad-slot],[data-ad-unit],[aria-label="Advertisement" i],iframe[src*="doubleclick"],iframe[src*="googlesyndication"],iframe[src*="amazon-adsystem"],iframe[src*="adnxs"],[id^="taboola"],.OUTBRAIN,[class*="ad-slot" i],[class*="adslot" i],[class*="advert" i]';
  const POP_SEL = 'dialog[open],[role="dialog"],[role="alertdialog"],[aria-modal="true"],[id*="cookie" i],[class*="cookie" i],[id*="consent" i],[class*="consent" i],[class*="paywall" i],[class*="newsletter" i][class*="modal" i]';
  const plural = (n, one, many) => n + ' ' + (n === 1 ? one : many || one + 's');
  const big = (e, w, h) => { const r = e.getBoundingClientRect(); return r.width >= w && r.height >= h; };
  function outermost(list) { const out = []; for (const e of list) if (!out.some((o) => o.contains(e))) out.push(e); return out; }

  function computeForecast() {
    if (!document.body) return null;
    const main = document.querySelector('main, article, [role="main"]') || document.body;
    const words = ((main.innerText || '').match(/\S+/g) || []).length;
    const minutes = Math.round(words / 200);
    const screens = Math.max(1, Math.round(document.documentElement.scrollHeight / Math.max(1, innerHeight)));
    const videos = [...document.querySelectorAll('video')].filter((v) => big(v, 80, 60));
    const embeds = [...document.querySelectorAll('iframe')].filter((f) => /youtube|youtu\.be|vimeo|twitch|dailymotion|tiktok/.test(f.src || '') && big(f, 80, 60));
    const autoplaying = videos.filter((v) => v.autoplay || pausedMedia.has(v) || (!v.paused && !allowedMedia.has(v))).length;
    const sound = [...document.querySelectorAll('video,audio')].some((m) => !m.paused && !m.muted && m.volume > 0);
    const gifs = [...document.images].filter(isGif).length;
    const images = [...document.images].filter((i) => i.clientWidth >= 120 && i.clientHeight >= 90).length;
    let ads = 0, popups = 0, loginForm = false, forms = 0;
    try { ads = outermost([...document.querySelectorAll(AD_SEL)].slice(0, 200).filter((e) => big(e, 50, 50))).length; } catch (e) {}
    try {
      popups = outermost([...document.querySelectorAll(POP_SEL)].slice(0, 80).filter((e) => {
        const cs = getComputedStyle(e);
        if (cs.display === 'none' || cs.visibility === 'hidden') return false;
        if (cs.position !== 'fixed' && cs.position !== 'sticky' && e.tagName !== 'DIALOG') return false;
        return big(e, 200, 36);
      })).length;
    } catch (e) {}
    loginForm = [...document.querySelectorAll('input[type="password"]')].some((i) => big(i, 20, 10));
    forms = [...document.forms].filter((f) => f.querySelectorAll('input:not([type="hidden"]), select, textarea').length >= 3).length;
    const moving = gifs + stats.anims + stats.slides + stats.flashes;
    let later = 0;
    try { later = [...document.querySelectorAll('[aria-modal="true"], [role="dialog"], [role="alertdialog"], dialog:not([open])')].filter((e) => !e.closest('clear-root') && e.getClientRects().length === 0).length; } catch (e) {}
    const feed = FEED.test(HOST) || (/youtube\.com$/.test(HOST) && location.pathname === '/');

    const score = later * 2 + stats.flashes * 4 + autoplaying * 3 + (videos.length + embeds.length - autoplaying) * 0.5 + moving * 1.5 + ads * 2 + popups * 3 +
      (sound ? 3 : 0) + (images > 30 ? 2 : 0) + (screens > 15 ? 1.5 : 0) + (feed ? 1.5 : 0);
    const level = score < 4 ? 'calm' : score < 10 ? 'moderate' : 'busy';

    const items = [];
    if (minutes >= 1) items.push('About ' + plural(minutes, 'minute') + ' to read');
    else if (words > 40) items.push('Under a minute to read');
    items.push(feed ? 'Endless feed (it keeps loading as you scroll)' : screens === 1 ? 'Fits on one screen' : screens + ' screens long');
    const nv = videos.length + embeds.length;
    if (nv) items.push(plural(nv, 'video') + (autoplaying ? ' (' + autoplaying + ' set to autoplay)' : ''));
    if (sound) items.push('Sound is playing');
    if (moving) items.push(plural(moving, 'moving image or animation', 'moving images or animations'));
    if (images) items.push(plural(images, 'image'));
    if (ads) items.push(plural(ads, 'ad'));
    if (popups) items.push(plural(popups, 'pop-up or banner', 'pop-ups or banners'));
    if (later) items.push(plural(later, 'pop-up') + ' may appear later');
    if (stats.flashes) items.push('Has flashing content');
    if (loginForm) items.push('Asks you to log in');
    else if (forms) items.push(plural(forms, 'form') + ' to fill in');
    return { level, items, minutes, screens };
  }
  const LEVEL_NAME = { calm: 'Calm page', moderate: 'Moderate page', busy: 'Busy page' };

  function changesList() {
    const did = [];
    if (stats.media) did.push('Stopped ' + plural(stats.media, 'autoplaying video') + ' (point at one and press Play)');
    if (stats.gifs) did.push('Paused ' + plural(stats.gifs, 'GIF') + ' (point at one and press Play)');
    if (stats.anims) did.push('Stopped ' + plural(stats.anims, 'looping animation'));
    if (stats.slides) did.push('Stopped ' + plural(stats.slides, 'slideshow') + ' that changed by itself (its own buttons still work)');
    if (stats.flashes) did.push('Covered ' + plural(stats.flashes, 'flashing area'));
    if (stats.embeds) did.push('Turned off autoplay for ' + plural(stats.embeds, 'embedded player'));
    if (adEls.size) did.push('Faded ' + plural(adEls.size, 'ad') + ' (point at one to see it)');
    if (colorTouched.size) did.push('Softened ' + plural(colorTouched.size, 'very bright color'));
    if (toneEls.size) did.push('Added ' + plural(toneEls.size, 'tone label'));
    return did;
  }
  function renderBar() {
    if (!forecast) return;
    const { $ } = ensureUI();
    $('bar-dot').className = 'dot ' + forecast.level; $('chip-dot').className = 'dot ' + forecast.level;
    $('bar-level').textContent = LEVEL_NAME[forecast.level];
    $('bar-items').textContent = forecast.items.slice(0, 4).map((s) => s.replace(/ \(it keeps.*\)/, '')).join('  ·  ');
  }
  function renderPanel() {
    const { $ } = ensureUI();
    forecast = computeForecast() || forecast;
    if (!forecast) return;
    renderBar();
    $('panel-title').textContent = 'Page forecast: ' + LEVEL_NAME[forecast.level].toLowerCase();
    const fill = (id, arr, cls) => { const u = $(id); u.textContent = ''; arr.forEach((t) => u.appendChild(el('li', cls, t))); };
    fill('panel-items', forecast.items);
    const did = changesList();
    $('panel-did-wrap').hidden = !did.length; fill('panel-did', did, 'sub');
    $('panel-dec-wrap').hidden = !decoded.size;
    const u = $('panel-dec'); u.textContent = '';
    [...decoded].slice(0, 10).forEach(([k, v]) => { const li = el('li', 'sub'); li.append(el('span', 'dec', k), ' means ', el('span', 'mean', v)); u.appendChild(li); });
    $('act-play').hidden = !pausedMedia.size;
  }
  function openPanel() { renderPanel(); ensureUI().$('panel').hidden = false; }
  function closePanel() { if (ui) ui.$('panel').hidden = true; }
  function collapseBar() {
    clearTimeout(barTimer);
    const { $ } = ensureUI();
    $('bar').hidden = true;
    $('chip').hidden = forecastHidden;
  }
  function showForecast(first) {
    if (!IS_TOP) return;
    const mode = on() ? S.forecast.mode : 'off';
    if (mode === 'off' || forecastHidden) { if (ui) { ui.$('bar').hidden = true; ui.$('chip').hidden = true; closePanel(); } return; }
    if (innerWidth < 260 || innerHeight < 160) return; // tiny popups and frames
    forecast = computeForecast();
    if (!forecast) return;
    const { $ } = ensureUI();
    renderBar();
    if (mode === 'bar' && first && !barShown) {
      barShown = true;
      $('bar').hidden = false; $('chip').hidden = true;
      clearTimeout(barTimer);
      if (S.forecast.collapseAfter > 0) barTimer = setTimeout(collapseBar, S.forecast.collapseAfter * 1000);
    } else if ($('bar').hidden) {
      $('chip').hidden = false;
    }
  }

  /* ---------- tooltip ---------- */
  let lastX = 0, lastY = 0, lastTarget = null, moveRaf = 0;
  function onBadge(elm, x, y) {
    const r = document.createRange();
    r.selectNodeContents(elm);
    const rects = r.getClientRects();
    if (!rects.length) return false;
    for (const rc of rects) if (x >= rc.left && x <= rc.right && y >= rc.top && y <= rc.bottom) return false;
    const last = rects[rects.length - 1];
    const b = elm.getBoundingClientRect();
    if (x < b.left || x > b.right || y < b.top || y > b.bottom + 2) return false;
    if (y >= last.top - 3 && y <= last.bottom + 3) return x > last.right && x < last.right + 150;
    return y > last.bottom && y < last.bottom + 30 && x < b.left + 150;
  }
  function phraseAt(x, y) {
    let node, off;
    if (document.caretPositionFromPoint) {
      const p = document.caretPositionFromPoint(x, y); if (!p) return null; node = p.offsetNode; off = p.offset;
    } else if (document.caretRangeFromPoint) {
      const r = document.caretRangeFromPoint(x, y); if (!r) return null; node = r.startContainer; off = r.startOffset;
    } else return null;
    const list = nodePhrases.get(node);
    if (!list) return null;
    for (const p of list) {
      if (off < p.start || off > p.end) continue;
      for (const rc of p.range.getClientRects()) if (x >= rc.left - 1 && x <= rc.right + 1 && y >= rc.top - 1 && y <= rc.bottom + 1) return p;
    }
    return null;
  }
  function badgeTarget(target, x, y) {
    const e = target instanceof Element ? target.closest('[data-clear-tone]') : null;
    return e && toneInfo.has(e) && onBadge(e, x, y) ? e : null;
  }
  /* "Play" button for a paused GIF or video under the pointer. It sits in CLEAR's own layer,
     so pressing it never follows a link the picture is part of. */
  let playTarget = null;
  function findPaused(x, y) {
    let n = 0;
    const hit = (e) => {
      if (++n > 150 || !e.isConnected) return false;
      const r = e.getBoundingClientRect();
      return r.width >= 48 && r.height >= 48 && x >= r.left && x <= r.right && y >= r.top && y <= r.bottom;
    };
    for (const img of frozenGifs.keys()) if (hit(img)) return img;
    for (const m of pausedMedia) if (m instanceof HTMLVideoElement && m.paused && !m.controls && hit(m)) return m;
    for (const g of heldGroups) if (hit(g.parent)) return g;
    return null;
  }
  function updatePlay() {
    if (ui && lastTarget === ui.host) return; // pointer is on CLEAR's own button
    const t = (frozenGifs.size || pausedMedia.size || heldGroups.size) && on() ? findPaused(lastX, lastY) : null;
    if (!t) { playTarget = null; if (ui) ui.$('play').hidden = true; return; }
    if (t === playTarget) return;
    playTarget = t;
    const b = ensureUI().$('play');
    b.textContent = t instanceof HTMLMediaElement ? '▶ Play video' : t instanceof Element ? '▶ Play GIF' : '▶ Play slideshow';
    const anchor = t instanceof Element ? t : t.parent;
    b.hidden = false;
    const r = anchor.getBoundingClientRect();
    b.style.left = Math.max(6, Math.min(r.left + 8, innerWidth - b.offsetWidth - 6)) + 'px';
    b.style.top = Math.max(6, Math.min(Math.max(r.top, 0) + 8, innerHeight - b.offsetHeight - 6)) + 'px';
  }
  function hitTest() {
    moveRaf = 0;
    updatePlay();
    if (!toneEls.size && phraseCount <= 0) return;
    let tip = null;
    const b = badgeTarget(lastTarget, lastX, lastY);
    if (b) { const t = toneInfo.get(b); tip = { title: t.title, body: t.detail, foot: 'Click the label for a full explanation.' }; }
    if (!tip && phraseCount > 0) { const p = phraseAt(lastX, lastY); if (p) tip = { title: '"' + p.match + '"', body: 'Plain meaning: ' + p.meaning }; }
    if (!tip) { if (ui) ui.$('tip').hidden = true; return; }
    const t = ensureUI().$('tip');
    t.textContent = '';
    t.append(el('b', '', tip.title), tip.body);
    if (tip.foot) t.append(el('span', 'foot', tip.foot));
    t.hidden = false;
    const w = t.offsetWidth, h = t.offsetHeight;
    t.style.left = Math.max(8, Math.min(lastX + 12, innerWidth - w - 8)) + 'px';
    t.style.top = (lastY + 22 + h > innerHeight ? Math.max(8, lastY - h - 12) : lastY + 22) + 'px';
  }
  document.addEventListener('mousemove', (e) => {
    if (!toneEls.size && phraseCount <= 0 && !frozenGifs.size && !pausedMedia.size && !heldGroups.size) return;
    lastX = e.clientX; lastY = e.clientY; lastTarget = e.target;
    if (!moveRaf) moveRaf = requestAnimationFrame(hitTest);
  }, { passive: true, capture: true });
  document.addEventListener('scroll', () => { if (ui) { ui.$('tip').hidden = true; ui.$('play').hidden = true; playTarget = null; } }, { passive: true, capture: true });
  document.addEventListener('click', (e) => {
    if (!toneEls.size) return;
    const b = badgeTarget(e.target, e.clientX, e.clientY);
    if (!b) return;
    e.preventDefault(); e.stopPropagation();
    const txt = b.textContent.trim();
    const rg = document.createRange(); rg.selectNodeContents(b);
    deliver(Object.assign({ text: txt }, nearbyLines(rg, txt)));
  }, true);

  /* ---------- explain panel (works on every page, even where CLEAR is paused) ---------- */
  /* Collect the lines before and after a range by walking the page's text nodes outward from it.
     This does not depend on how a site lays out or transforms its text. */
  const JUNK = 'nav, header, footer, aside, button, select, label, form, [role="navigation"], [role="banner"], [role="contentinfo"], [role="search"], [role="button"], [role="menu"], [role="tablist"], [role="toolbar"], [aria-hidden="true"], clear-root';
  const goodLine = (t) => t.length >= 12 && t.split(/\s+/).length >= 3 && /[a-z]{3}/i.test(t);
  const splitLines = (v) => v.split(/\n+|(?<=[.!?…])\s+(?=["'“(]?[A-Z0-9])/).map((x) => x.replace(/\s+/g, ' ').trim()).filter(Boolean);

  function walkLines(range, dir, max, selText) {
    const out = [];
    const blocks = new Map();
    const blockOf = (node) => {
      let e = node.nodeType === 1 ? node : node.parentElement;
      const first = e;
      if (blocks.has(first)) return blocks.get(first);
      while (e && e !== document.body && e.parentElement) {
        const d = getComputedStyle(e).display;
        if (!d.startsWith('inline') && d !== 'contents') break;
        e = e.parentElement;
      }
      e = e || document.body;
      blocks.set(first, e);
      return e;
    };
    const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT | NodeFilter.SHOW_ELEMENT,
      { acceptNode: (n) => (n.nodeType === 3 || n.tagName === 'BR' ? NodeFilter.FILTER_ACCEPT : NodeFilter.FILTER_SKIP) });
    const node0 = dir < 0 ? range.startContainer : range.endContainer;
    const off0 = dir < 0 ? range.startOffset : range.endOffset;
    let buf = '', cur = null, selBlock = null;

    if (node0.nodeType === 3) {
      buf = dir < 0 ? node0.nodeValue.slice(0, off0) : node0.nodeValue.slice(off0);
      cur = selBlock = blockOf(node0);
      walker.currentNode = node0;
    } else if (dir < 0) {
      let n = node0.childNodes[off0 - 1];
      if (n) { while (n.lastChild) n = n.lastChild; walker.currentNode = n; if (n.nodeType === 3) { buf = n.nodeValue; cur = selBlock = blockOf(n); } }
      else walker.currentNode = node0;
    } else {
      let n = node0.childNodes[off0];
      if (n && n.nodeType === 3) { buf = n.nodeValue; cur = blockOf(n); walker.currentNode = n; }
      else if (n) { // step to just before n, so that nextNode() enters it
        let l = n.previousSibling || node0;
        if (l !== node0) while (l.lastChild) l = l.lastChild;
        walker.currentNode = l;
      } else { let l = node0; while (l.lastChild) l = l.lastChild; walker.currentNode = l; }
    }
    if (!selBlock) selBlock = blockOf(range.commonAncestorContainer);

    const selRect = range.getBoundingClientRect();
    let far = false;
    const flush = () => {
      const txt = buf, b = cur;
      buf = '';
      if (!b || !txt.trim() || b.closest(JUNK)) return;
      const r = b.getBoundingClientRect();
      if (!r.width && !r.height) return;
      const same = b === selBlock || b.contains(selBlock) && b !== document.body && r.height < 400;
      if (!same && (dir < 0 ? selRect.top - r.bottom : r.top - selRect.bottom) > 700) { far = true; return; } // too far away to be related
      let ls = splitLines(txt).filter(goodLine);
      if (dir < 0) ls.reverse();
      for (const l of ls) {
        const text = l.length > 300 ? l.slice(0, 297) + '...' : l;
        if (text === selText || out.some((o) => o.text === text)) continue;
        out.push({ text, same });
        if (out.length >= max) return;
      }
    };
    let seen = 0, chars = 0;
    while (out.length < max && seen < 800 && chars < 10000 && !far) {
      const n = dir < 0 ? walker.previousNode() : walker.nextNode();
      if (!n) break;
      seen++;
      if (n.nodeType === 1) { buf = dir < 0 ? '\n' + buf : buf + '\n'; continue; } // <br>
      const pe = n.parentElement;
      if (!pe || /^(SCRIPT|STYLE|NOSCRIPT|TEXTAREA|OPTION|TITLE)$/.test(pe.tagName)) continue;
      if (!n.nodeValue.trim()) { if (cur && cur.contains(n)) buf = dir < 0 ? ' ' + buf : buf + ' '; continue; }
      if (pe.getClientRects().length === 0) continue; // not rendered
      const b = blockOf(n);
      if (b !== cur) { flush(); cur = b; }
      buf = dir < 0 ? n.nodeValue + buf : buf + n.nodeValue;
      chars += n.nodeValue.length;
    }
    if (out.length < max && !far) flush();
    return dir < 0 ? out.reverse() : out;
  }
  function nearbyLines(range, text) {
    const out = { before: [], after: [] };
    if (!range || !document.body) return out;
    try { out.before = walkLines(range, -1, 8, text); } catch (e) {}
    try { out.after = walkLines(range, 1, 8, text); } catch (e) {}
    return out;
  }
  function deliver(p) { if (IS_TOP) openExplain(p); else send({ type: 'relay-explain', payload: p }); }
  function explainSelection(simplify) {
    const sel = getSelection();
    const text = String(sel || '').trim();
    if (!text) return false;
    deliver(Object.assign({ text, simplify: !!simplify }, nearbyLines(sel.rangeCount ? sel.getRangeAt(0) : null, text)));
    return true;
  }
  let ex = null; // {text, before:[{text,on,same}], after:[...], added:[...], showB, showA}
  function closeExplain() { if (ui) ui.$('explain').hidden = true; }
  const visB = () => ex.before.slice(Math.max(0, ex.before.length - ex.showB));
  const visA = () => ex.after.slice(0, ex.showA);
  const contextText = () => ex.before.concat(ex.added, ex.after).filter((l) => l.on).map((l) => l.text).join('\n');

  /* On-device model state, kept by the service worker in chrome.storage.local. */
  let model = { state: 'none' };
  const ask = (msg, cb) => { try { chrome.runtime.sendMessage(msg, (r) => { void chrome.runtime.lastError; cb && cb(r); }); } catch (e) { cb && cb(null); } };
  try {
    chrome.storage.local.get('clearModel', (o) => { void chrome.runtime.lastError; if (o && o.clearModel) model = o.clearModel; });
    chrome.storage.onChanged.addListener((c, area) => {
      if (area !== 'local' || !c.clearModel) return;
      const was = model.state;
      model = c.clearModel.newValue || { state: 'none' };
      if (ui && ex && !ui.$('explain').hidden) { if (model.state === 'ready' && was !== 'ready') renderAnalysis(); else renderEngine(lastAI); }
      if (model.state === 'ready' && was !== 'ready') { appliedEpochKey = ''; applySocial(); }
    });
  } catch (e) {}

  let modelS = { state: 'none' }; // simplification model
  try {
    chrome.storage.local.get('clearModelSimplify', (o) => { void chrome.runtime.lastError; if (o && o.clearModelSimplify) modelS = o.clearModelSimplify; });
    chrome.storage.onChanged.addListener((c, area) => {
      if (area !== 'local' || !c.clearModelSimplify) return;
      const was = modelS.state;
      modelS = c.clearModelSimplify.newValue || { state: 'none' };
      if (!ui || !ex || ui.$('explain').hidden || !ex.simple) return;
      if (modelS.state === 'ready' && was !== 'ready') renderSimple(); else offerSimplify(null);
    });
  } catch (e) {}

  /* Offer (or show progress of) the simplification model below a basic rewrite. */
  function offerSimplify(box) {
    const { $ } = ensureUI();
    const host = box || $('explain-simple');
    let slot = host.querySelector('.offer');
    if (!slot) slot = host.appendChild(el('div', 'offer'));
    slot.textContent = '';
    if (modelS.state === 'ready') return;
    if (modelS.state === 'downloading') { slot.appendChild(el('div', 'muted small', 'Downloading the simplification model: ' + (modelS.progress || 0) + '%. You can keep browsing.')); return; }
    if (modelS.state === 'error') slot.appendChild(el('div', 'muted small', 'The simplification model could not be downloaded (' + (modelS.error || 'unknown error') + ').'));
    const b = el('button', 'pill', modelS.state === 'error' ? 'Try the download again' : 'Get the simplification model (about 270 MB, one time)');
    b.style.marginTop = '6px';
    b.addEventListener('click', () => { ask({ type: 'model-download', model: 'simplify' }); b.disabled = true; b.textContent = 'Starting the download...'; });
    slot.appendChild(b);
  }
  function renderSimple() {
    const { $ } = ensureUI();
    const box = $('explain-simple'); box.textContent = '';
    box.appendChild(el('h3', '', 'In simpler words'));
    if (!ex.simple) {
      const b = el('button', 'pill', 'Rewrite in simpler words');
      b.addEventListener('click', () => { ex.simple = true; renderSimple(); });
      box.appendChild(b);
      return;
    }
    const inner = box.appendChild(el('div'));
    RENDER.simplify(inner, ex.text, { ai: S.social.ai === 'auto', send: ask, offer: () => offerSimplify(box) });
  }

  let aiSeq = 0, lastAI = null;
  function renderEngine(r) {
    const { $ } = ensureUI();
    const box = $('explain-ai'); box.textContent = '';
    if (S.social.ai !== 'auto') return;
    const line = (t) => box.appendChild(el('div', 'muted small engine', t));
    if (r && r.llm) return line('Tone and missing details were read by Chrome\'s on-device AI model. Nothing left this computer.');
    if (r && r.irony) return line('Sarcasm was checked by the on-device models. They confirm or rule out sarcasm; they never claim it on their own. Nothing left this computer.');
    if (model.state === 'ready') return line('Reading with the on-device sarcasm models...');
    if (!renderEngine.checked) { renderEngine.checked = true; ask({ type: 'model-check' }); } // already downloaded earlier?
    if (model.state === 'downloading') return line('Downloading the sarcasm models: ' + (model.progress || 0) + '%. You can keep browsing.');
    line(model.state === 'error'
      ? 'The sarcasm models could not be downloaded (' + (model.error || 'unknown error') + '). This reading uses CLEAR\'s built-in rules.'
      : model.partial ? 'CLEAR\'s sarcasm reader now uses a second small model. Until it is downloaded, this reading uses the built-in rules.'
      : 'This reading uses CLEAR\'s built-in rules, which miss subtle sarcasm.');
    const b = el('button', 'pill', model.state === 'error' ? 'Try the download again' : model.partial ? 'Download the missing part (about 68 MB)' : 'Get the sarcasm models (about 194 MB, one time)');
    b.style.marginTop = '6px';
    b.addEventListener('click', () => { ask({ type: 'model-download' }); b.disabled = true; b.textContent = 'Starting the download...'; });
    box.appendChild(b);
  }
  function renderAnalysis() {
    const { $ } = ensureUI();
    const ctx = contextText();
    const x = A.explain(ex.text, ctx);
    RENDER.explain($('explain-body'), x, { heading: 'h3' });
    lastAI = null;
    renderEngine(null);
    if (S.social.ai !== 'auto') return;
    const seq = ++aiSeq;
    ask({ type: 'ai-read', text: x.text, context: ctx }, (r) => {
      if (seq !== aiSeq || !ex || !r || !(r.llm || r.irony)) return;
      lastAI = r;
      RENDER.explain($('explain-body'), A.withModel(x, r), { heading: 'h3' });
      renderEngine(r);
    });
  }
  function renderContext() {
    const { $ } = ensureUI();
    const box = $('explain-ctx'); box.textContent = '';
    box.appendChild(el('h3', '', 'Lines around it'));
    const any = ex.before.length || ex.after.length || ex.added.length;
    box.appendChild(el('div', 'muted small', any
      ? 'Tone depends on context. Ticked lines are read together with your selection. The rest of the same message and the line just before it are ticked for you. Untick anything unrelated.'
      : 'CLEAR found no related lines next to your selection. To add context, select more text on the page and press the button below.'));
    const row = (l, where) => {
      const lab = el('label');
      const cb = el('input'); cb.type = 'checkbox'; cb.checked = l.on;
      cb.addEventListener('change', () => { l.on = cb.checked; renderAnalysis(); });
      lab.append(cb, el('span', 'where', where), el('span', 'line', l.text));
      box.appendChild(lab);
    };
    const more = (label, fn) => { const b = el('button', 'more', label); b.addEventListener('click', () => { fn(); renderContext(); }); box.appendChild(b); };
    if (ex.before.length > ex.showB) more('Show earlier lines', () => { ex.showB += 3; });
    visB().forEach((l) => row(l, 'before'));
    if (any) box.appendChild(el('div', 'here', ex.text.length > 90 ? ex.text.slice(0, 87) + '...' : ex.text));
    ex.added.forEach((l) => row(l, 'added'));
    visA().forEach((l) => row(l, 'after'));
    if (ex.after.length > ex.showA) more('Show later lines', () => { ex.showA += 3; });

    const acts = el('div', 'actions');
    const add = el('button', 'pill', 'Add text I have selected on the page');
    add.addEventListener('mousedown', (e) => e.preventDefault()); // keep the page selection
    add.addEventListener('click', () => {
      const t = String(getSelection() || '').replace(/\s+/g, ' ').trim().slice(0, 1200);
      if (!t || t === ex.text.replace(/\s+/g, ' ') || ex.added.some((l) => l.text === t)) {
        add.textContent = 'Select other text on the page first';
        setTimeout(() => { add.textContent = 'Add text I have selected on the page'; }, 2200);
        return;
      }
      ex.added.push({ text: t, on: true });
      renderContext(); renderAnalysis();
    });
    acts.appendChild(add);
    box.appendChild(acts);
  }
  function openExplain(p) {
    const text = String(p && p.text || '').trim();
    if (!text) return;
    const { $ } = ensureUI();
    const norm = (arr) => (arr || []).map((l) => (typeof l === 'string' ? { text: l, on: false } : { text: l.text, on: !!l.same }));
    ex = { text, before: norm(p.before), after: norm(p.after), added: [], showB: 3, showA: 3, simple: !!p.simplify };
    // the line just before a message is its most likely trigger, so it is read by default
    if (ex.before.length && !ex.before.some((l) => l.on)) ex.before[ex.before.length - 1].on = true;
    // lines of the same message stay visible even when there are more than three
    ex.showB = Math.max(3, ex.before.filter((l) => l.on).length); ex.showA = Math.max(3, ex.after.filter((l) => l.on).length);
    renderAnalysis(); renderSimple(); renderContext();
    if (!$('bar').hidden) collapseBar();
    closePanel(); $('tip').hidden = true; $('sel').hidden = true;
    $('explain').hidden = false;
    $('explain').scrollTop = 0;
    $('explain-close').focus({ preventScroll: true });
    if (ex.simple) $('explain-simple').scrollIntoView({ block: 'nearest' });
  }

  /* ---------- small "Explain" button next to selected text ---------- */
  let selTimer = 0;
  function hideSel() { if (ui) ui.$('sel').hidden = true; }
  function updateSel() {
    selTimer = 0;
    if (!S.enabled || !S.social.selectButton) return hideSel();
    const sel = getSelection();
    if (!sel || sel.isCollapsed || !sel.rangeCount) return hideSel();
    const text = String(sel).trim();
    if (text.length < 8 || text.length > 4000) return hideSel();
    const an = sel.anchorNode, pe = an && (an.nodeType === 1 ? an : an.parentElement);
    if (!pe || pe.closest('input, textarea, [contenteditable=""], [contenteditable="true"], clear-root')) return hideSel();
    const rects = sel.getRangeAt(0).getClientRects();
    const last = rects[rects.length - 1];
    if (!last || (!last.width && !last.height)) return hideSel();
    const b = ensureUI().$('sel');
    b.hidden = false;
    b.style.left = Math.max(6, Math.min(last.right + 6, innerWidth - b.offsetWidth - 6)) + 'px';
    b.style.top = Math.max(6, Math.min(last.bottom + 6, innerHeight - b.offsetHeight - 6)) + 'px';
  }
  const queueSel = () => { clearTimeout(selTimer); selTimer = setTimeout(updateSel, 250); };
  document.addEventListener('mouseup', (e) => { if (!ui || e.target !== ui.host) queueSel(); }, true);
  document.addEventListener('keyup', (e) => { if (e.shiftKey || e.key === 'Shift') queueSel(); }, true);
  document.addEventListener('mousedown', (e) => { if (!ui || e.target !== ui.host) hideSel(); }, true);
  document.addEventListener('scroll', hideSel, { passive: true, capture: true });

  document.addEventListener('keydown', (e) => {
    if (e.key !== 'Escape' || !ui) return;
    if (!ui.$('explain').hidden) closeExplain(); else if (!ui.$('panel').hidden) closePanel();
  }, true);

  /* =====================================================================
     7. Wiring: settings, scanning, messages, website bridge.
     ===================================================================== */
  let scanTimer = 0;
  function scan() {
    scanTimer = 0;
    if (!on()) return;
    scanGifs(); scanColors(); scanSocial(); scanEmbeds(); scanAds();
  }
  const scheduleScan = () => { if (!scanTimer) scanTimer = setTimeout(scan, 800); };

  function applyDim() {
    if (!IS_TOP) return;
    const d = on() ? Math.max(0, Math.min(40, S.sensory.dim)) : 0;
    if (!d && !ui) return;
    ensureUI().$('dim').style.opacity = String(d / 100 * 0.6);
  }
  /* Tell the toolbar icon what is happening on this tab, so it is visible without opening the popup. */
  function reportState() { if (IS_TOP && ready) send({ type: 'page-state', state: !S.enabled ? 'off' : siteOff() ? 'paused' : 'on' }); }
  addEventListener('pageshow', reportState);

  function applyAll(first) {
    if (!document.body) return;
    applyMotion(); applyGifs(); applyColors(); applySocial(); applyDim(); applyAds(); scanEmbeds();
    if (!flashOn()) releaseFlash();
    if (!first) showForecast(false);
    if (!on() && ui) ui.$('tip').hidden = true;
    if (!S.enabled) hideSel();
    if (on() && ui) ui.$('note').hidden = true;
    reportState();
  }

  function start() {
    applyAll(true);
    new MutationObserver((records) => { watchChanges(records); colorClassChanged(records); scheduleScan(); })
      .observe(document.documentElement, { childList: true, subtree: true, characterData: true, attributes: true, attributeFilter: ['class', 'style', 'src', 'srcset', 'allow'] });
    if (IS_TOP && S.enabled && siteOff() && S.pausedNote && innerWidth >= 260) {
      const { $ } = ensureUI();
      $('note-text').textContent = 'CLEAR is paused on this site';
      $('note').hidden = false;
      setTimeout(() => { $('note').hidden = true; }, 6000);
    }
    const firstForecast = () => setTimeout(() => showForecast(true), 900);
    if (document.readyState === 'complete') firstForecast(); else addEventListener('load', firstForecast, { once: true });
    // single-page apps: refresh the forecast quietly when the address changes
    let href = location.href;
    setInterval(() => {
      if (location.href === href) return;
      href = location.href; forecastHidden = false;
      setTimeout(() => showForecast(false), 1500);
    }, 1500);
  }

  CLEAR.load().then((s) => {
    S = s; ready = true;
    reportState();
    for (const m of earlyMedia) guardMedia(m);
    earlyMedia.clear();
    if (autoplayOn()) document.querySelectorAll('video, audio').forEach(guardMedia);
    if (document.body) start(); else document.addEventListener('DOMContentLoaded', start, { once: true });
  });
  CLEAR.onChange((s) => { S = s; if (ready) applyAll(false); postToSite(); });

  try {
    chrome.runtime.onMessage.addListener((msg, _sender, reply) => {
      if (!msg) return;
      if (msg.type === 'resume-media') { resumeMedia(); return; }
      if (msg.type === 'explain') {           // from the right-click menu, sent to the frame that was clicked
        if (msg.payload) { if (IS_TOP) openExplain(msg.payload); }
        else if (!explainSelection(msg.simplify)) deliver({ text: msg.text || '', simplify: !!msg.simplify });
        reply({ ok: true }); return;
      }
      if (msg.type === 'explain-selection') { // keyboard shortcut or popup button, sent to every frame
        const found = explainSelection(false);
        if (IS_TOP) reply({ ok: true, found });
        return;
      }
      if (!IS_TOP) return;
      if (msg.type === 'status') {
        const f = on() ? (computeForecast() || forecast) : null;
        reply({ host: HOST, active: on(), siteOff: siteOff(), level: f && f.level, items: f ? f.items : [], did: changesList() });
      }
    });
  } catch (e) {}

  /* Bridge so a hosted copy of the CLEAR website can read and save settings.
     Only pages on hosts listed in "trusted hosts" are answered. */
  const trusted = () => S.trustedHosts.includes(location.hostname);
  function postToSite() { if (IS_TOP && ready && trusted()) window.postMessage({ source: 'clear-ext', type: 'settings', settings: S }, location.origin); }
  if (IS_TOP) window.addEventListener('message', (e) => {
    if (e.source !== window || !e.data || e.data.source !== 'clear-site' || !ready || !trusted()) return;
    if (e.data.type === 'hello') postToSite();
    else if (e.data.type === 'save' && e.data.settings) CLEAR.save(CLEAR.merge(CLEAR.DEFAULTS, e.data.settings));
  });
})();
