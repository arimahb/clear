/* CLEAR text analysis. Small, local, rule-based. Nothing leaves the browser.
   Design goal: high precision. It is better to show no label than a wrong one. */
(function (g) {
  const LEX = g.CLEAR_LEXICON || [];
  const BIG = new RegExp('(?<![\\w/])(?:' + LEX.map((e) => '(' + e.p + ')').join('|') + ')(?![\\w])', 'gi');

  /** Find figurative phrases. opts: {idioms, subtext, abbr} booleans (default all on). */
  function findPhrases(text, opts) {
    const o = opts || {};
    const out = [];
    if (!text || text.length < 3) return out;
    BIG.lastIndex = 0;
    let m;
    while ((m = BIG.exec(text))) {
      if (m[0].length === 0) { BIG.lastIndex++; continue; }
      let idx = -1;
      for (let i = 1; i < m.length; i++) if (m[i] !== undefined) { idx = i - 1; break; }
      if (idx < 0) continue;
      const e = LEX[idx];
      if (e.cat === 'idiom' && o.idioms === false) continue;
      if (e.cat === 'subtext' && o.subtext === false) continue;
      if (e.cat === 'abbr') {
        if (o.abbr === false) continue;
        // "ooo" / "eod" style abbreviations: skip when part of a longer shouted word run
        if (/^ooo$/i.test(m[0]) && m[0] !== 'OOO') continue;
      }
      out.push({ start: m.index, end: m.index + m[0].length, match: m[0], meaning: e.m, cat: e.cat, tone: e.tone });
    }
    return out;
  }

  // ---- tone rules: [tone, weight, regex, human reason] ----
  const R = [
    // explicit tone markers (written by the author, so reliable)
    ['sarcasm', 3, /(?:^|\s)\/s(?:arcasm)?(?=$|[\s.,!?)])/i, 'the writer added "/s", a marker for sarcasm'],
    ['joking', 3, /(?:^|\s)\/(?:j|hj|joke)(?=$|[\s.,!?)])/i, 'the writer added "/j", a marker for joking'],
    ['sincere', 3, /(?:^|\s)\/(?:srs|gen|genq|g)(?=$|[\s.,!?)])/i, 'the writer added a marker meaning "I am being serious"'],
    ['lighthearted', 3, /(?:^|\s)\/(?:lh|pos|nm|nbh)(?=$|[\s.,!?)])/i, 'the writer added a marker meaning "this is friendly, not angry"'],

    // sarcasm: fixed expressions that are rarely sincere
    ['sarcasm', 2.5, /\byeah,? (?:right|sure)\b/i, '"yeah, right" usually means the opposite'],
    ['sarcasm', 3, /\bsaid no one,? ever\b/i, '"said no one ever" reverses the sentence before it'],
    ['sarcasm', 3, /\bthanks for nothing\b|\bthanks a lot for (?:nothing|that)\b/i, 'thanking someone for something unwanted'],
    ['sarcasm', 3, /\b(?:great|nice|good) (?:job|work|going),? (?:genius|einstein|buddy|pal|sherlock)\b|\bthanks,? (?:captain obvious|genius|einstein|sherlock)\b|\bno sh[i*]t,? sherlock\b/i, 'mock praise'],
    ['sarcasm', 3, /\bi (?:just |really |absolutely )?love (?:it )?(?:when|how) (?:\w+ ){0,6}(?:break|crash|fail|ignore|forget|cancel|delete|lose|loses|freeze|late|never|doesn'?t|don'?t|won'?t|can'?t|stop)/i, '"I love when" followed by something bad'],
    ['sarcasm', 2.5, /\breal(?:ly)? (?:helpful|mature|professional|classy|smart|original)\b|\bcool story\b/i, 'mock praise'],
    ['sarcasm', 2, /\bwhat a (?:surprise|shock(?:er)?)\b|\bbig surprise\b|\bshocker\b|\bcolou?r me (?:shocked|surprised)\b/i, 'pretending to be surprised'],
    ['sarcasm', 2, /\bwhat could (?:possibly )?go wrong\b/i, 'this phrase usually predicts that things will go wrong'],
    ['sarcasm', 2, /\b(?:sure|yeah|right),? because\b|\bbecause (?:of course|obviously)\b/i, 'gives a reason the writer does not believe'],
    ['sarcasm', 2, /\bhow (?:original|shocking|surprising|convenient)\b/i, 'mock reaction'],
    ['sarcasm', 2, /\bwho (?:would have|would've|could have|could've|woulda) (?:thought|guessed|known)\b/i, 'pretending the outcome was not obvious'],
    ['sarcasm', 2, /\bjust what (?:i|we) (?:needed|wanted)\b|\blucky (?:me|us)\b|\blove that for (?:me|us)\b|\bgood luck with that\b/i, 'a phrase usually said about something unwanted'],
    ['sarcasm', 2, /🙄/u, 'eye-roll emoji'],
    ['sarcasm', 1.5, /\b(?:my|the) (?:day|week|morning|night|life|weekend) is (?:now |finally )?(?:complete|made)\b|\bbest (?:day|week|monday|morning) ever\b|\bliving the dream\b|\bcould(?:n'?t| not) be (?:happier|better)\b/i, 'a line of exaggerated happiness'],
    // openers and weaker hints: these only count for much when bad news is mentioned too (see below)
    ['sarcasm', 1.25, /\boh,? (?:great|joy|goody|wonderful|fantastic|perfect|brilliant|sure|good|wow|nice)\b/i, 'an "oh great" style opener'],
    ['sarcasm', 1.5, /\b(?:suu+re|rii+ght|gree+at|nii+ce|soo+|woo+w|yeaa+h|okaa+y)\b/i, 'a stretched-out word, often a mocking tone'],
    ['sarcasm', 1.5, /["“](?:fix|fixed|improvement|improved|feature|help|helpful|upgrade|expert|genius|update|support)["”]/i, 'a positive word placed in quotation marks'],
    ['sarcasm', 1.5, /\bof course (?:it|they|he|she|you) (?:did|does|do|is|was|are|would)(?=[.!,…]|$)|\bnice try\b|\bmust be nice\b|\btotally not\b/i, 'wording often used sarcastically'],
    ['sarcasm', 1, /(?:^|[.!?]\s+)(?:great|perfect|wonderful|fantastic|awesome|lovely|brilliant|nice|cool|super|yay|wow)[.!,…]/i, 'a one-word positive opener'],
    ['sarcasm', 0.5, /\bcan'?t wait\b|\bso (?:glad|happy|excited|thrilled)\b|\bmy favou?rite\b|\bi'?m (?:so|totally|absolutely) (?:shocked|surprised)\b/i, 'strong positive wording'],

    ['frustrated', 2, /\bfed up\b|\bsick (?:and tired )?of\b|\bhad (?:it|enough)\b/i, 'the writer says they have run out of patience'],
    ['frustrated', 2, /\bso (?:annoying|frustrating|infuriating|irritating)\b|\bdriv(?:es|ing) me (?:crazy|nuts|insane|up the wall)\b/i, 'the writer names their annoyance directly'],
    ['frustrated', 2, /\bthis is (?:ridiculous|unacceptable|absurd|a joke|insane|getting old)\b/i, 'strong complaint wording'],
    ['frustrated', 2, /\bfor the (?:last|hundredth|thousandth|millionth|nth|umpteenth) time\b|\bhow many times\b/i, 'the writer feels they are repeating themselves'],
    ['frustrated', 2, /\bwhy is (?:it|this|everything) so (?:hard|difficult|complicated|slow)\b|\bwhat is wrong with\b/i, 'complaint phrased as a question'],
    ['frustrated', 2, /\bi can'?t (?:even|stand|take|deal)\b|\bwtf\b|\bffs\b|\bugh+\b|\bargh+\b/i, 'exasperation wording'],
    ['frustrated', 2, /[😤😡🤬]/u, 'angry emoji'],

    ['joking', 3, /\bjk\b|\bjust (?:kidding|joking|messing with you)\b|\bonly joking\b|\bkidding!/i, 'the writer says they are joking'],
    ['joking', 1, /\b(?:lol|lmao|lmfao|rofl)\b|\bhaha+\b/i, 'laughter wording'],
    ['joking', 1, /[😂🤣😜😝😉]/u, 'laughing or winking emoji'],

    ['urgent', 2, /\basap\b|\bas soon as possible\b|\burgent(?:ly)?\b|\bimmediately\b|\bright (?:now|away)\b|\btime[- ]sensitive\b/i, 'the writer asks for speed'],
    ['urgent', 2, /\bby (?:eod|cob|end of (?:the )?day|tonight|noon|midnight|tomorrow morning)\b|\bdeadline is\b|\bdue (?:today|tonight|tomorrow)\b/i, 'a close deadline is stated']
  ];

  const INFO = {
    sarcasm: { label: 'Sarcasm', title: 'Possibly sarcastic', note: 'The writer may mean the opposite of the literal words.' },
    frustrated: { label: 'Frustrated', title: 'Sounds frustrated', note: 'The writer seems annoyed. The annoyance may be about the situation, not about you.' },
    joking: { label: 'Joking', title: 'Probably joking', note: 'This is likely meant to be funny, not taken literally.' },
    urgent: { label: 'Urgent', title: 'Time pressure', note: 'The writer wants this handled quickly.' },
    indirect: { label: 'Indirect', title: 'Polite wording, firmer meaning', note: 'The words are polite, but they often carry a firmer message.' },
    sincere: { label: 'Sincere', title: 'Meant seriously', note: 'The writer marked this as serious and literal.' },
    lighthearted: { label: 'Friendly', title: 'Friendly intent', note: 'The writer marked this as friendly, not angry.' }
  };
  const THRESH = { low: 3, balanced: 2, high: 1.5 };
  const NOT_SHOUT = /^(ASAP|NASA|HTML|HTTP|HTTPS|JSON|TODO|NOTE|FYI|USA|API|FAQ|PDF|EDIT|UPDATE|TLDR|LMAO|ROFL|IIRC|AFAIK|IMHO)$/;

  const POS = /\b(?:great|awesome|wonderful|fantastic|perfect|brilliant|lovely|amazing|nice|love (?:it|that|this)|thanks|thank you|good job|well done|genius|excellent|terrific|so fun)\b/i;
  const NEG = /\b(?:crash(?:ed|es|ing)?|broken?|breaks?|fail(?:ed|s|ure|ing)?|delet(?:ed|es)|lost|delay(?:ed|s)?|cancel(?:l?ed|s)?|worst|ruin(?:ed|s)?|errors?|bugs?|stuck|missed|forgot|terrible|awful|disaster|mess|outage|rejected|denied|fired|down again|not working|doesn'?t work|never works?|again|another (?:meeting|delay|bug|error|update|outage|bill|fee|email)|late|waiting|traffic|overtime|unpaid|price (?:hike|increase)|ads?|paywall|spam|frozen?|froze|slow|useless|pointless|jammed|dead|flat tyre|flat tire|broke down|leak(?:ing|ed|s)?|flooded|out of order|locked out|overdue|spilled|spilt|cracked|hung|timed out|offline|is down|are down|went down|sick|declined|towed|stolen|burnt|burned|soaked|out of (?:stock|battery|gas|petrol|ink|paper|milk|coffee)|no (?:signal|wifi|internet|power|heating|hot water)|overbooked|sold out|double[- ]booked|rescheduled|moved to \d|parking ticket|fine of|invoice|bill)\b/i;
  // "it is fixed" cancels sarcasm; "will it ever get fixed" does not
  const RESOLVED = /(?<!\b(?:ever|never|get|gets|getting|got|be|been|being|to)\s)\b(?:fixed|resolved|solved|sorted|recovered)\b|\bworks? now\b|\bworking (?:again|now)\b|\bno (?:more )?(?:errors?|bugs?|delays?)\b|\bfound it\b|\bback up\b|\bfinally works?\b/i;
  const SINCERE = /\b(?:thank you so much|thanks so much|really appreciate|appreciate (?:it|you|this|that)|congrat\w*|well deserved|proud of|so happy for|means a lot)\b|[❤🎉🙏🥳😊💕]/iu;

  /** Detect one dominant tone. opts: {sensitivity, tones:{...}}. context: optional surrounding lines.
      Returns null when unsure. */
  function tone(text, opts, context) {
    const o = opts || {};
    const t = (text || '').trim();
    if (t.length < 4 || t.length > 1500) return null;
    const ctx = String(context || '').trim().slice(0, 3000);
    const score = {}, why = {};
    let usedContext = false;
    const direct = {};
    const add = (k, w, r) => { score[k] = (score[k] || 0) + w; (why[k] = why[k] || []).push(r); };

    for (const [k, w, re, r] of R) {
      if (re.test(t)) { add(k, w, r); direct[k] = true; if (k === 'sarcasm' && w === 3 && r.includes('"/s"')) direct.sarcasmMarker = true; }
      else if (ctx && re.test(ctx)) { add(k, w / 2, 'in the surrounding lines: ' + r); usedContext = true; }
    }
    for (const p of findPhrases(t, { idioms: false, abbr: false })) {
      if (p.tone === 'indirect') direct.indirect = true;
      if (p.tone === 'indirect') add('indirect', 2, '"' + p.match + '" often means: ' + p.meaning);
    }
    // Sarcasm is praise that does not fit the facts. A hint counts for more when bad news is mentioned,
    // and for less when the message is clearly grateful or the problem is solved.
    const resolved = RESOLVED.test(t), sincere = SINCERE.test(t);
    if (score.sarcasm && !resolved) {
      const neg = NEG.exec(t);
      if (neg) add('sarcasm', score.sarcasm >= 1.25 ? 1.5 : 1, 'positive wording about something bad ("' + neg[0] + '")');
    }
    if (ctx && !resolved && !sincere) {
      const pos = POS.exec(t), neg = NEG.exec(ctx);
      if (pos && neg && !NEG.test(t)) {
        add('sarcasm', 2, 'positive wording ("' + pos[0] + '") next to bad news in the surrounding lines ("' + neg[0] + '")');
        usedContext = true;
      }
    }
    if (score.sarcasm && (sincere || resolved) && !direct.sarcasmMarker) score.sarcasm -= 1.5;
    // supporting cues only strengthen frustration that is already indicated
    if (score.frustrated) {
      if (/!{2,}|\?!|!\?/.test(t)) add('frustrated', 1, 'repeated punctuation');
      const caps = (t.match(/\b[A-Z]{4,}\b/g) || []).filter((w) => !NOT_SHOUT.test(w));
      if (caps.length >= 2) add('frustrated', 1, 'several words in capital letters');
    }
    // sarcasm marker beats laughter; a "jk" beats a guessed sarcasm
    const enabled = o.tones || {};
    const allowed = (k) => {
      if (k === 'sincere' || k === 'lighthearted') return enabled.markers !== false;
      return enabled[k] !== false;
    };
    const min = THRESH[o.sensitivity] || THRESH.balanced;
    let best = null;
    for (const k of Object.keys(score)) {
      if (!allowed(k) || score[k] < min) continue;
      if (!best || score[k] > score[best]) best = k;
    }
    if (!best) return null;
    const strong = score[best] >= 3;
    let info = INFO[best];
    if (!direct[best] && best !== 'sarcasm') info = { label: info.label, title: info.title, note: 'The surrounding lines carry this tone. The selected words alone do not show it.' };
    return {
      key: best,
      label: info.label + (strong ? '' : '?'),
      title: info.title,
      note: info.note,
      reasons: why[best],
      strong, usedContext,
      detail: info.note + ' Why: ' + why[best][0] + '.' + (strong ? '' : ' This is a guess from the wording.')
    };
  }

  // ---- explain: literal meaning, what is asked, what is missing ----
  const REQUEST = /\b(?:please|pls|plz|could you|can you|would you|will you|i need you to|we need to|you need to|you(?:'ll| will) need to|you should|you must|you have to|make sure|don'?t forget|remember to|let me know|get back to me|send (?:me|us|over)|rsvp|i'?d like you to|would you mind|it would be (?:great|good|helpful|nice) if|i was (?:just )?wondering if|need(?:ed)? by|waiting (?:on|for) your)\b/i;
  const IMPERATIVE = /^(?:send|call|email|e-mail|check|review|update|submit|fill|complete|bring|join|share|tell|give|add|remove|fix|read|sign|confirm|reply|respond|schedule|book|pay|upload|attach|forward|finish|prepare|contact|register|bring|meet|come|stop|start|use|try|look|see|note)\b/i;
  const TIME_REF = /\b(?:today|tonight|tomorrow|yesterday|monday|tuesday|wednesday|thursday|friday|saturday|sunday|(?:mon|tue|tues|wed|thu|thurs|fri)\b|january|february|march \d|april|may \d|june|july|august|september|october|november|december|(?:jan|feb|mar|apr|jun|jul|aug|sep|sept|oct|nov|dec)\.? \d|\d{1,2}(?::\d{2})?\s?(?:am|pm)|\d{1,2}[\/.-]\d{1,2}|noon|midnight|eod|cob|end of (?:the )?(?:day|week|month)|next week|this week|\d(?:st|nd|rd|th)\b)/i;
  const VAGUE_TIME = /\b(?:soon|asap|as soon as possible|later|sometime|some time|at some point|shortly|in a bit|eventually|when(?:ever)? you (?:get|have) a (?:chance|minute|moment|sec|second)|at your earliest convenience)\b/i;
  const VAGUE_THING = /\b(?:the thing|that thing|the stuff|that stuff|the usual|you know what|the other one|the issue we discussed|what we talked about)\b/i;

  /* ---- "What might be missing": look for the specific gaps in this message and quote its own words ---- */
  const cut = (v, n) => { n = n || 60; v = v.replace(/\s+/g, ' ').trim(); return v.length > n ? v.slice(0, n - 3).trim() + '...' : v; };
  const KNOWN_CAPS = /^(?:OK|USA|UK|EU|US|UN|ASAP|FYI|PDF|URL|FAQ|CEO|CTO|CFO|COO|HR|IT|AI|TV|PC|ID|AM|PM|PS|TBD|TBA|DIY|ETA|RSVP|LOL|OMG|WTF|IMO|IMHO|TLDR|EOD|COB|WFH|OOO|API|HTML|CSS|NASA|DM|PR|QA|UI|UX|II|III|IV|GIF|JPG|PNG|GPS|ATM|VIP|DVD|USB|SMS|PIN|NYC|LA|DC|BBC|CNN|FBI|CIA|NBA|NFL|GOP|AKA|RIP|BTW|IDK|IIRC|AFAIK|FWIW|YMMV|NGL|TBH|SMH|ICYMI|FTFY|IYKYK|NOT|AND|THE|YES|NO|ALL|NEW|SO|VERY)$/;
  const DELIVER_HOW = /\b(?:to (?:me|us|him|her|them)\b|to \S+@|via |by e-?mail|e-?mail (?:me|it|us)|on slack|in slack|on teams|here\b|drive|folder|link|portal|form|dm\b|message me|text me|in (?:the )?(?:chat|thread|channel|doc))/i;
  const PLACE = /\b(?:zoom|teams|google meet|meet\.google|skype|discord|link|room|office|online|remote|virtual|address|at (?:my|our|the|your) [a-z]+|at [A-Z][a-z]+|in (?:the )?[a-z]+ room|\d+ [A-Z]?[a-z]+ (?:st|street|ave|avenue|road|rd|blvd))\b/;

  function findMissing(clean, ctx, asks, tn) {
    const missing = [];
    const push = (t) => { if (missing.length < 4 && !missing.includes(t)) missing.push(t); };
    const all = clean + ' ' + ctx;
    const words = clean.split(/\s+/).filter(Boolean);
    const dos = asks.filter((a) => a.kind === 'do');
    const time = TIME_REF.exec(clean);

    // very short replies carry almost no information by themselves
    const react = /^(?:ok(?:ay)?|k+|fine|sure|whatever|noted|alright|if you say so|great|nice|cool|interesting|wow)[.!…]*$/i.exec(clean);
    if (react && !ctx) push('"' + clean + '" on its own can mean real agreement or quiet annoyance. The words do not show which. If it matters, you can ask: "Are you happy with that?"');
    const lead = /^(?:this|that|it|these|those|they|same|ditto|agreed|exactly|yes|no|yep|nope|true|right)\b/i.exec(clean);
    if (lead && !react && !ctx) push('It starts with "' + lead[0] + '", which points back to something said earlier. Tick the lines before it so CLEAR can see what it refers to.');

    const TALK = /\bwe need to talk\b|\bcan we talk\b|\bquick (?:chat|call|word)\b|\bgot a (?:minute|sec|second)\b|\bneed a word\b/i;
    dos.slice(0, 2).forEach((a, idx) => {
      if (TALK.test(a.text)) return; // handled below: the gap there is the topic, not a deadline
      const q = '"' + cut(a.text) + '"';
      const light = /^(?:see|note|look|fyi)\b/i.test(a.text); // pointing at something, not a task
      const vt = VAGUE_TIME.exec(a.text);
      if (vt) push('"' + vt[0] + '" in ' + q + ' is not a specific time. You can ask: "What date or time do you need this by?"');
      else if (!light && !TIME_REF.test(a.text) && !TIME_REF.test(all)) push('No deadline is given for ' + q + '. You can ask: "When do you need this by?"');
      const obj = /\b(send|do|fix|check|finish|bring|share|update|review|handle|sort|sign|submit|approve|forward|read|complete|change|move|delete|add)\s+(it|this|that|them|those|these)\b/i.exec(a.text);
      if (obj && !ctx && a.text === sentences(clean)[0]) push('"' + obj[0] + '": it is not stated what "' + obj[2] + '" is. Tick the earlier lines, or ask which item is meant.');
      const dv = /\b(send|share|submit|forward|upload)\b/i.exec(a.text);
      if (dv && !DELIVER_HOW.test(a.text) && idx === 0) push('It does not say how to ' + dv[1].toLowerCase() + ' it (email, chat, shared folder).');
      const who = /\b(?:someone|somebody|anyone|anybody|one of (?:you|us))\b|\b(?:needs?|has|have) to be \w+(?:ed|ne|en)\b|\bshould be \w+(?:ed|ne|en)\b|\bwe (?:should|need to|have to|must)\b/i.exec(a.text);
      if (who) push('"' + who[0] + '" does not say who is expected to do it. You can ask: "Do you want me to do this?"');
      const amt = /\b(?:a few|a couple(?: of)?|some|several|a bit(?: of)?|a little|enough|a lot of|more|fewer|less)\s+[a-z]+/i.exec(a.text);
      if (amt) push('"' + amt[0] + '" is not an exact amount. You can ask how many or how much.');
      const qual = /\b(?:quick(?:ly)?|brief(?:ly)?|short|rough|detailed|better|nicer|cleaner|improve|polish|tidy|clean up|professional|proper(?:ly)?|reasonable|decent)\b/i.exec(a.text);
      if (qual) push('"' + qual[0] + '" is not defined. You can ask how long or how detailed the result should be, or ask for an example.');
    });

    const ev = /\b(?:meeting|meet(?: up)?|call|sync|catch[- ]up|lunch|dinner|coffee|party|interview|appointment|session|stand-?up|event|drinks|hang ?out)\b/i.exec(clean);
    const planning = /\b(?:let'?s|we should|want to|wanna|shall we|are you (?:free|coming|joining|around)|join (?:us|me)|invit\w+|schedul\w+|set up|book|plan(?:ning)?|grab|see you|come to|there (?:is|will be)|we(?:'re| are) having|up for|free for|how about)\b/i.test(clean);
    if (ev && planning) {
      if (!TIME_REF.test(all)) push('"' + ev[0] + '" has no date or time.');
      if (!PLACE.test(all) && /\b(?:meeting|meet|lunch|dinner|coffee|party|interview|appointment|drinks|event)\b/i.test(ev[0])) push('"' + ev[0] + '" has no place or link.');
    }
    const vg = VAGUE_THING.exec(clean);
    if (vg) push('"' + vg[0] + '" does not say exactly what is meant. You can ask which one they mean.');
    const talk = TALK.exec(clean);
    if (talk) push('"' + talk[0] + '" does not say what the topic is. You can ask: "What is it about?"');
    const fb = /\bthoughts\?|\bwhat do you think\?|\bfeedback\?|\bany comments\?/i.exec(clean);
    if (fb) push('"' + fb[0] + '" does not say what kind of answer is wanted: a quick yes or no, or detailed comments.');
    const att = /\b(?:attached|attachment|see below|the link|linked|enclosed|screenshot)\b/i.exec(clean);
    if (att && !/https?:\/\//.test(all)) push('It mentions "' + att[0] + '". Check that you actually received it.');
    const caps = [...new Set((clean.match(/\b[A-Z]{2,6}\b/g) || []).filter((w) => !KNOWN_CAPS.test(w)))];
    if (caps.length && caps.length <= 3 && words.length > 4 && clean !== clean.toUpperCase())
      push('"' + caps.join('", "') + '" ' + (caps.length > 1 ? 'are abbreviations that are' : 'is an abbreviation that is') + ' not explained here.');

    if (!asks.length && !missing.length) {
      if (tn && tn.key === 'sarcasm') push('The writer\'s real opinion is not stated. With sarcasm it is usually the opposite of the words, so it is probably negative.');
      else if (tn && tn.key === 'frustrated') push('It does not say what the writer wants from you. They may want to be heard, not a solution. You can ask: "Do you want help, or do you just want to tell me?"');
      else if (/\b(?:i think|i feel|imo|imho|in my opinion|i believe|personally|honestly)\b/i.test(clean) && !/\bbecause\b|https?:\/\/|\d/.test(clean)) push('This is an opinion. It gives no reasons or sources.');
      else if (time && words.length > 3) push('It gives information ("' + time[0] + '") but does not say whether you need to confirm or reply.');
    }

    let complete = '';
    if (!missing.length) {
      if (dos.length) complete = 'It says what is wanted ("' + cut(dos[0].text, 50) + '")' + (time ? ' and when ("' + time[0] + '").' : '.') + ' Nothing important seems to be missing.';
      else if (asks.length) complete = 'It asks one clear question ("' + cut(asks[0].text, 50) + '"). Nothing else seems to be needed to answer it.';
      else complete = 'It is a statement with no request or question, so there is nothing you need to find out.';
    }
    return { missing, complete };
  }

  /* Combine the rule-based reading with a result from an on-device model (see ai/offscreen.js). */
  const LLM_TONE = { sarcastic: 'sarcasm', joking: 'joking', frustrated: 'frustrated', urgent: 'urgent', sincere: 'sincere' };
  function withModel(x, ai) {
    const out = Object.assign({}, x);
    const explicit = x.tone && x.tone.key === 'sarcasm' && x.tone.reasons.some((r) => r.includes('"/s"'));
    const make = (key, strong, reasons, note) => {
      const info = INFO[key];
      return { key, label: info.label + (strong ? '' : '?'), title: info.title, note: note || info.note, reasons, strong, detail: (note || info.note) + ' Why: ' + reasons[0] + '.' };
    };
    if (ai && ai.llm) {
      const l = ai.llm, key = LLM_TONE[l.tone];
      out.engine = 'llm';
      if (explicit) { /* the writer's own "/s" wins */ }
      else if (key) out.tone = make(key, l.confidence >= 0.75, [l.why || 'read by the on-device AI model']);
      else out.tone = null, out.toneNote = l.tone === 'unclear' ? 'The on-device AI model could not tell the tone from the words. ' + (l.why || '') : 'The on-device AI model reads this as neutral. ' + (l.why || '');
      if (Array.isArray(l.missing) && l.missing.length) { out.missing = l.missing; out.complete = ''; }
      return out;
    }
    if (ai && ai.irony && ai.irony.self) {
      /* A model may confirm or deny sarcasm, never claim it on its own. The irony classifier rates
         most cheerful text as ironic, and the sentiment model reads words rather than situations,
         so a label needs either a conflict the models found together, or sarcastic wording. */
      const self = ai.irony.self, ctx = ai.irony.ctx;
      const useCtx = ctx && ctx.conflict != null && self.conflict == null;
      const r = useCtx ? ctx : self;
      const ruled = !!(x.tone && x.tone.key === 'sarcasm');
      out.engine = 'irony';
      out.irony = Math.round(r.irony * 100);
      out.conflict = r.conflict != null;
      if (explicit) return out;

      if (r.conflict != null) {
        const why = r.why + (useCtx ? ', in the ticked lines' : '');
        const firm = ruled || r.irony >= 0.6;
        out.tone = make('sarcasm', firm, [why].concat(ruled ? x.tone.reasons : []).concat(
          'the irony model rates this ' + out.irony + '% likely to be sarcastic'));
      } else if (ruled) {
        if (r.irony <= 0.2 && !x.tone.strong) {
          out.tone = tone(x.text.slice(0, 1500), { sensitivity: 'high', tones: { sarcasm: false } }, x.context);
          out.toneNote = 'The wording has a pattern that is sometimes sarcastic, but the irony model rates it only ' + out.irony + '% likely, and nothing in the message contradicts the praise. It is probably meant literally.';
        } else {
          out.tone = make('sarcasm', x.tone.strong, x.tone.reasons.concat('the models found nothing in the message that contradicts the praise, so this rests on the wording'));
        }
      } else {
        out.toneNote = 'The on-device models found no praise that is contradicted by a bad situation, so this is probably meant literally.' +
          (x.context ? '' : ' If it still feels off, tick the lines around it.');
      }
      if (out.tone && out.tone.key === 'sarcasm' && !x.asks.length && x.missing.length === 0)
        out.missing = ['The writer\'s real opinion is not stated. With sarcasm it is usually the opposite of the words, so it is probably negative.'], out.complete = '';
    }
    return out;
  }

  /* ---- Basic simplification without a model: literal meanings for idioms, plain words for formal ones ---- */
  const PLAIN = [
    ['due to the fact that', 'because'], ['in the event that', 'if'], ['at this point in time', 'now'], ['at the present time', 'now'],
    ['for the purpose of', 'to'], ['in order to', 'to'], ['with regards? to', 'about'], ['in regards? to', 'about'], ['prior to', 'before'],
    ['subsequent to', 'after'], ['a large number of', 'many'], ['the majority of', 'most'], ['in spite of', 'despite'], ['in addition', 'also'],
    ['as a result', 'so'], ['on the other hand', 'but'], ['in the near future', 'soon'], ['is able to', 'can'], ['are able to', 'can'],
    ['utili[sz]e', 'use'], ['utili[sz]es', 'uses'], ['utili[sz]ed', 'used'], ['utili[sz]ing', 'using'], ['commence', 'start'], ['commenced', 'started'],
    ['terminate', 'end'], ['terminated', 'ended'], ['approximately', 'about'], ['additional', 'more'], ['assistance', 'help'], ['assist', 'help'],
    ['purchase', 'buy'], ['purchased', 'bought'], ['requires', 'needs'], ['required', 'needed'], ['require', 'need'], ['sufficient', 'enough'],
    ['numerous', 'many'], ['demonstrate', 'show'], ['demonstrates', 'shows'], ['demonstrated', 'showed'], ['facilitate', 'help'], ['endeavou?r', 'try'],
    ['subsequently', 'later'], ['regarding', 'about'], ['concerning', 'about'], ['obtain', 'get'], ['obtained', 'got'], ['inquire', 'ask'], ['enquire', 'ask'],
    ['indicate', 'show'], ['indicates', 'shows'], ['indicated', 'showed'], ['modify', 'change'], ['modified', 'changed'], ['attempt', 'try'], ['attempted', 'tried'],
    ['however', 'but'], ['therefore', 'so'], ['consequently', 'so'], ['nevertheless', 'but'], ['nonetheless', 'but'], ['furthermore', 'also'], ['moreover', 'also'],
    ['leverage', 'use'], ['optimal', 'best'], ['expedite', 'speed up'], ['ascertain', 'find out'], ['comprehend', 'understand'], ['initiate', 'start'],
    ['initiated', 'started'], ['conclude', 'end'], ['concluded', 'ended'], ['remainder', 'rest'], ['residence', 'home'], ['individuals', 'people'],
    ['commencing', 'starting'], ['notify', 'tell'], ['notified', 'told'], ['prioriti[sz]e', 'put first'], ['beneficial', 'helpful'], ['detrimental', 'harmful'],
    ['frequently', 'often'], ['immediately', 'right away'], ['previously', 'before'], ['currently', 'now'], ['primarily', 'mainly'], ['significant', 'big'],
    ['substantial', 'large'], ['adjacent to', 'next to'], ['participate', 'take part'], ['anticipate', 'expect'], ['determine', 'find out'], ['implement', 'carry out'],
    ['discontinue', 'stop'], ['accomplish', 'do'], ['aforementioned', 'mentioned earlier'], ['henceforth', 'from now on'], ['whilst', 'while'], ['thus', 'so']
  ];
  const PLAIN_RE = new RegExp('\\b(?:' + PLAIN.map((e) => '(' + e[0] + ')').join('|') + ')\\b', 'gi');
  function simplifyBasic(text) {
    let changed = 0;
    let out = String(text || '');
    // idioms first (right to left, so positions stay valid)
    const ph = findPhrases(out, { subtext: false, abbr: false });
    for (let i = ph.length - 1; i >= 0; i--) { out = out.slice(0, ph[i].start) + ph[i].meaning + out.slice(ph[i].end); changed++; }
    out = out.replace(PLAIN_RE, (m, ...g) => {
      const idx = g.findIndex((v, i) => i < PLAIN.length && v !== undefined);
      if (idx < 0) return m;
      changed++;
      const rep = PLAIN[idx][1];
      return m[0] === m[0].toUpperCase() ? rep[0].toUpperCase() + rep.slice(1) : rep;
    });
    const semi = out.replace(/;\s+([a-z])/g, (m, c) => { changed++; return '. ' + c.toUpperCase(); });
    return { text: semi, changed };
  }

  function sentences(text) {
    return text.split(/(?<=[.!?…])\s+|\n+/).map((s) => s.trim()).filter((s) => s.length > 1);
  }

  function explain(text, context) {
    const clean = String(text || '').replace(/[ \t]+/g, ' ').trim().slice(0, 4000);
    const ctx = String(context || '').replace(/[ \t]+/g, ' ').trim().slice(0, 3000);
    const phrases = findPhrases(clean);
    const tn = tone(clean.slice(0, 1500), { sensitivity: 'high' }, ctx);

    // text split into plain parts and decoded parts
    const parts = [];
    let pos = 0;
    for (const p of phrases) {
      if (p.start < pos) continue;
      if (p.start > pos) parts.push({ text: clean.slice(pos, p.start) });
      parts.push({ text: clean.slice(p.start, p.end), meaning: p.meaning });
      pos = p.end;
    }
    if (pos < clean.length) parts.push({ text: clean.slice(pos) });

    const asks = [];
    const sarcastic = tn && tn.key === 'sarcasm';
    for (const s of sentences(clean)) {
      const bare = s.replace(/^(?:hi|hey|hello|ok|okay|so|and|also|then)[,!]?\s+/i, '');
      if (REQUEST.test(s) || bare.split(/[,;:] +/).some((c) => IMPERATIVE.test(c))) asks.push({ kind: 'do', text: s });
      else if (/\?["')\]]*$/.test(s) && !sarcastic) asks.push({ kind: 'answer', text: s });
      if (asks.length >= 6) break;
    }

    const found = findMissing(clean, ctx, asks, tn);
    return { text: clean, context: ctx, tone: tn, phrases, parts, asks, missing: found.missing, complete: found.complete };
  }

  g.CLEAR_ANALYZE = { findPhrases, tone, explain, withModel, simplifyBasic, INFO };
})(globalThis);
