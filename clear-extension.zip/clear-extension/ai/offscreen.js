/* CLEAR on-device models. Runs in a hidden extension page, so pages you visit never slow down.
   1. Sarcasm reader: two small classifiers used together. An irony classifier (RoBERTa), and a sentiment
      classifier (DistilBERT) that checks whether empty praise sits next to a bad situation.
   2. Simplification model: a small instruction-following text-to-text model (LaMini-Flan-T5).
      Both run with Transformers.js / ONNX in WebAssembly. Each is downloaded once, only after you ask
      for it, and then kept in the browser cache.
   3. Chrome's built-in language model, when the browser has one. Used first when available.
   Text is processed on this computer only. */
import { pipeline, env } from '../vendor/transformers.min.js';

const MODELS = {
  irony: { task: 'text-classification', id: 'Xenova/twitter-roberta-base-irony' },
  sentiment: { task: 'text-classification', id: 'Xenova/distilbert-base-uncased-finetuned-sst-2-english' },
  simplify: { task: 'text2text-generation', id: 'Xenova/LaMini-Flan-T5-248M' }
};
env.allowLocalModels = false;
env.useBrowserCache = true;
env.backends.onnx.wasm.wasmPaths = chrome.runtime.getURL('vendor/');
env.backends.onnx.wasm.numThreads = 1;

const pipes = {}, loading = {}, lastPct = {};
let idleTimer = 0;
const tell = (msg) => { try { chrome.runtime.sendMessage(msg, () => void chrome.runtime.lastError); } catch (e) {} };

/* What the person downloads as one item -> the model files behind it, with their share of the download. */
const GROUPS = { irony: [['irony', 0.65], ['sentiment', 0.35]], simplify: [['simplify', 1]] };

function loadOne(name, host, onPct) {
  if (pipes[name]) return Promise.resolve(pipes[name]);
  if (loading[name]) return loading[name];
  if (host) env.remoteHost = host;
  const m = MODELS[name];
  loading[name] = pipeline(m.task, m.id, {
    dtype: 'q8', device: 'wasm',
    progress_callback: (p) => { if (p.status === 'progress_total' && onPct) onPct(p.progress); }
  }).then((p) => { pipes[name] = p; delete loading[name]; return p; }, (e) => { delete loading[name]; throw e; });
  return loading[name];
}
async function load(group, host) {
  let done = 0;
  for (const [name, share] of GROUPS[group]) {
    await loadOne(name, host, (pct) => {
      const total = Math.floor((done + share * pct / 100) * 100);
      if (total !== lastPct[group]) { lastPct[group] = total; tell({ type: 'model-progress', model: group, progress: total }); }
    });
    done += share;
  }
  return pipes[GROUPS[group][0][0]];
}

/* Reads two separate signals for each text and reports both. It does not decide:
   a sarcasm label needs a conflict (praise with nothing in it next to a genuinely bad
   situation), because each model on its own produces far too many false alarms.
     conflict: how sure the sentiment model is that the situation clause is bad, or null
     irony:    the irony classifier's own score, used only to firm up or veto */
const pick = (labels, yes, no) => {
  const list = Array.isArray(labels) ? labels : [labels];
  const hit = list.find((l) => yes.test(l.label) && !/non|not/i.test(l.label));
  if (hit) return hit.score;
  const miss = list.find((l) => no.test(l.label));
  return miss ? 1 - miss.score : 0;
};
async function classify(texts, host) {
  await load('irony', host);
  texts = texts.map((t) => String(t).slice(0, 1200));
  const irony = (await pipes.irony(texts, { top_k: 2 })).map((l) => pick(l, /irony|sarcas|(^|_)1$/i, /non|not|(^|_)0$/i));
  const plans = texts.map((t) => globalThis.CLEAR_SARCASM.plan(t));
  const jobs = []; // [textIndex, clauseIndex]
  plans.forEach((p, ti) => { if (p.bare.length && !p.blocked) for (const ci of p.rest) if (jobs.length < 32) jobs.push([ti, ci]); });
  const neg = texts.map(() => ({}));
  if (jobs.length) {
    const out = await pipes.sentiment(jobs.map(([ti, ci]) => plans[ti].cs[ci]), { top_k: 2 });
    out.forEach((l, k) => { neg[jobs[k][0]][jobs[k][1]] = pick(l, /neg|(^|_)0$/i, /pos|(^|_)1$/i); });
  }
  return texts.map((t, i) => {
    const c = globalThis.CLEAR_SARCASM.contrast(plans[i], neg[i]);
    return {
      irony: irony[i],
      bare: plans[i].bare.length > 0 && !plans[i].blocked,
      conflict: c ? c.strength : null,
      why: c ? 'praise with nothing in it ("' + c.positive + '") next to a bad situation ("' + c.negative + '")' : null
    };
  });
}

/* Rewrite text in simpler words. Works a few sentences at a time, which small models handle best.
   A piece is kept as it was when the model returns nothing usable for it. */
const words = (t) => (t.match(/\S+/g) || []).length;
function chunks(text) {
  const parts = text.split(/(?<=[.!?…])\s+|\n+/).map((x) => x.trim()).filter(Boolean);
  const out = [];
  let cur = '';
  for (const s of parts) {
    if (cur && words(cur) + words(s) > 45) { out.push(cur); cur = s; } else cur = cur ? cur + ' ' + s : s;
  }
  if (cur) out.push(cur);
  return out.slice(0, 12);
}
async function simplify(text, host) {
  await load('simplify', host);
  const p = pipes.simplify;
  const out = [];
  let changed = 0;
  for (const c of chunks(String(text).slice(0, 2500))) {
    let r = '';
    try {
      const g = await p('Rewrite the following text using simple words and short sentences. Keep every fact.\n\n' + c,
        { max_new_tokens: Math.min(220, Math.round(words(c) * 1.8) + 24), do_sample: false, repetition_penalty: 1.2, no_repeat_ngram_size: 4 });
      r = String((Array.isArray(g) ? g[0] : g).generated_text || '').trim();
    } catch (e) { r = ''; }
    const ok = r && words(r) >= Math.max(2, words(c) * 0.3) && words(r) <= words(c) * 2 + 10;
    if (ok && r !== c) changed++;
    out.push(ok ? r : c);
  }
  return { text: out.join(' '), changed };
}

/* ---- Chrome's built-in model (Prompt API), if this browser has it ---- */
const SYSTEM =
  'You help autistic readers understand messages. Judge only the Message. Use the surrounding lines only to understand it. ' +
  'Reply with JSON only, with these keys: ' +
  '"tone": one of "sincere", "sarcastic", "joking", "frustrated", "urgent", "neutral", "unclear"; ' +
  '"confidence": a number from 0 to 1; ' +
  '"why": one short plain sentence naming the words or facts that show the tone; ' +
  '"missing": a list of 0 to 4 short plain sentences, each naming one specific piece of information the reader would need but the message does not give ' +
  '(for example a deadline, a place, who should act, what "it" refers to). Quote the unclear words. Use an empty list if nothing is missing. ' +
  'Do not invent facts. If the tone cannot be known from the words, answer "unclear".';
const SCHEMA = {
  type: 'object',
  properties: {
    tone: { type: 'string', enum: ['sincere', 'sarcastic', 'joking', 'frustrated', 'urgent', 'neutral', 'unclear'] },
    confidence: { type: 'number' }, why: { type: 'string' },
    missing: { type: 'array', items: { type: 'string' }, maxItems: 4 }
  },
  required: ['tone', 'confidence', 'why', 'missing']
};
const SIMPLE_SYSTEM =
  'Rewrite the text the user gives you in plain, literal English for an autistic reader. Use common words and short sentences. ' +
  'Replace idioms and figures of speech with their literal meaning. Keep every fact, name, number and date. Do not add anything. ' +
  'Reply with the rewritten text only.';
async function llmAvailable() {
  try { return !!globalThis.LanguageModel && (await globalThis.LanguageModel.availability()) === 'available'; } catch (e) { return false; }
}
async function llm(text, context) {
  if (!(await llmAvailable())) return { ok: false };
  let session;
  try {
    session = await globalThis.LanguageModel.create({ initialPrompts: [{ role: 'system', content: SYSTEM }] });
    const q = (context ? 'Surrounding lines:\n' + String(context).slice(0, 1500) + '\n\n' : '') + 'Message:\n' + String(text).slice(0, 2000);
    let raw;
    try { raw = await session.prompt(q, { responseConstraint: SCHEMA }); } catch (e) { raw = await session.prompt(q); }
    const m = /\{[\s\S]*\}/.exec(String(raw));
    const d = JSON.parse(m ? m[0] : raw);
    if (!d || typeof d.tone !== 'string') return { ok: false };
    return { ok: true, data: { tone: d.tone, confidence: Number(d.confidence) || 0.5, why: String(d.why || '').slice(0, 300), missing: (Array.isArray(d.missing) ? d.missing : []).map((x) => String(x).slice(0, 240)).slice(0, 4) } };
  } catch (e) { return { ok: false }; }
  finally { try { session && session.destroy(); } catch (e) {} }
}
async function llmSimplify(text) {
  if (!(await llmAvailable())) return { ok: false };
  let session;
  try {
    session = await globalThis.LanguageModel.create({ initialPrompts: [{ role: 'system', content: SIMPLE_SYSTEM }] });
    const out = String(await session.prompt(String(text).slice(0, 2500))).trim();
    return out ? { ok: true, text: out } : { ok: false };
  } catch (e) { return { ok: false }; }
  finally { try { session && session.destroy(); } catch (e) {} }
}
/* Has this already been downloaded? Looks for the weight files in the browser cache.
   have: every file is there. some: at least one is (an older version, or an interrupted download). */
const WEIGHTS = { irony: ['onnx/model_quantized.onnx'], sentiment: ['onnx/model_quantized.onnx'], simplify: ['onnx/encoder_model_quantized.onnx', 'onnx/decoder_model_merged_quantized.onnx'] };
async function probe() {
  const have = {}, some = {};
  try {
    const cache = await caches.open(env.cacheKey || 'transformers-cache');
    const urls = (await cache.keys()).map((r) => r.url);
    for (const group of Object.keys(GROUPS)) {
      const found = [];
      for (const [name] of GROUPS[group]) for (const f of WEIGHTS[name]) found.push(urls.some((u) => u.includes(MODELS[name].id) && u.endsWith(f)));
      have[group] = found.every(Boolean); some[group] = found.some(Boolean);
    }
  } catch (e) {}
  return { have, some };
}
async function removeModel(group) {
  const cache = await caches.open(env.cacheKey || 'transformers-cache');
  let n = 0;
  for (const [name] of GROUPS[group]) {
    delete pipes[name];
    for (const req of await cache.keys()) if (req.url.includes(MODELS[name].id)) { await cache.delete(req); n++; }
  }
  return n;
}

chrome.runtime.onMessage.addListener((msg, _sender, reply) => {
  if (!msg || msg.target !== 'offscreen') return;
  clearTimeout(idleTimer);
  idleTimer = setTimeout(() => { if (!Object.keys(loading).length) window.close(); }, 10 * 60 * 1000); // free the memory when unused
  (async () => {
    try {
      if (msg.type === 'load') {
        await load(msg.model, msg.host);
        tell({ type: 'model-done', model: msg.model, ok: true });
        reply({ ok: true });
      } else if (msg.type === 'classify') reply({ ok: true, scores: await classify(msg.texts, msg.host) });
      else if (msg.type === 'simplify') reply(Object.assign({ ok: true }, await simplify(msg.text, msg.host)));
      else if (msg.type === 'llm') reply(await llm(msg.text, msg.context));
      else if (msg.type === 'llm-simplify') reply(await llmSimplify(msg.text));
      else if (msg.type === 'probe') reply(Object.assign({ ok: true }, await probe()));
      else if (msg.type === 'remove') reply({ ok: true, removed: await removeModel(msg.model) });
      else reply({ ok: false });
    } catch (e) {
      const error = String(e && e.message || e).slice(0, 200);
      if (msg.type === 'load') tell({ type: 'model-done', model: msg.model, ok: false, error });
      reply({ ok: false, error });
    }
  })();
  return true;
});
