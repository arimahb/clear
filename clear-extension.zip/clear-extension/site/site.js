/* CLEAR website logic. Works in three modes:
   ext     - opened from the extension (reads and writes chrome.storage directly)
   bridge  - hosted on a trusted host; talks to the extension's content script
   preview - extension not found; settings are kept in this browser only */
const $ = (s) => document.querySelector(s);
const $$ = (s) => [...document.querySelectorAll(s)];
const get = (o, path) => path.split('.').reduce((a, k) => a[k], o);
const set = (o, path, v) => { const ks = path.split('.'); const last = ks.pop(); ks.reduce((a, k) => a[k], o)[last] = v; };
const el = (tag, cls, text) => { const n = document.createElement(tag); if (cls) n.className = cls; if (text != null) n.textContent = text; return n; };

let S = CLEAR.merge(CLEAR.DEFAULTS, {});
let mode = 'preview';

function save() {
  if (mode === 'ext') CLEAR.save(S);
  else if (mode === 'bridge') window.postMessage({ source: 'clear-site', type: 'save', settings: S }, location.origin);
  else { try { localStorage.setItem(CLEAR.KEY, JSON.stringify(S)); } catch (e) {} }
  render();
}

/* same softening maths as the extension, for the swatch preview */
function soften(hex, lv) {
  const c = [parseInt(hex.slice(1, 3), 16) / 255, parseInt(hex.slice(3, 5), 16) / 255, parseInt(hex.slice(5, 7), 16) / 255, 1];
  return CLEAR.soften(c, lv, false) || hex;
}

function render() {
  $$('[data-key]').forEach((i) => {
    const v = get(S, i.dataset.key);
    if (i.type === 'checkbox') i.checked = !!v; else i.value = String(v);
  });
  $('#master-label').textContent = S.enabled ? 'CLEAR is on' : 'CLEAR is off';
  $('#dim-out').textContent = S.sensory.dim ? 'Now: ' + S.sensory.dim + '%.' : 'Now: off.';
  const lv = S.enabled ? CLEAR.colorLevel(S.sensory.colorAmount) : null;
  $('#amount-out').textContent = S.sensory.colorAmount ? 'Now: ' + S.sensory.colorAmount + '%.' : 'Now: off.';
  $$('.sw').forEach((sw) => { sw.style.background = soften(sw.dataset.c, lv); });
  $('#trusted').value = S.trustedHosts.join('\n');
  const ul = $('#sites'); ul.textContent = '';
  if (!S.disabledSites.length) ul.appendChild(el('li', 'empty', 'None. CLEAR is active on every site.'));
  S.disabledSites.forEach((h) => {
    const li = el('li'); const b = el('button', '', 'Resume'); b.type = 'button';
    b.setAttribute('aria-label', 'Resume CLEAR on ' + h);
    b.addEventListener('click', () => { S.disabledSites = S.disabledSites.filter((x) => x !== h); save(); });
    li.append(el('span', '', h), b); ul.appendChild(li);
  });
  $('#status').textContent = mode === 'ext' ? 'Connected to the extension. Changes save automatically.'
    : mode === 'bridge' ? 'Connected to the CLEAR extension in this browser.'
    : 'Preview mode: the CLEAR extension was not detected, so changes stay on this page.';
}

function bind() {
  $$('[data-key]').forEach((i) => i.addEventListener('change', () => {
    let v = i.type === 'checkbox' ? i.checked : i.value;
    if (i.type === 'range' || i.dataset.type === 'number') v = Number(v);
    set(S, i.dataset.key, v); save();
  }));
  $$('[data-live]').forEach((i) => i.addEventListener('input', () => { set(S, i.dataset.key, Number(i.value)); save(); }));
  $('#site-form').addEventListener('submit', (e) => {
    e.preventDefault();
    let h = $('#site-input').value.trim().toLowerCase();
    if (!h) return;
    try { h = new URL(/^[a-z]+:\/\//.test(h) ? h : 'https://' + h).hostname; } catch (err) { return; }
    h = h.replace(/^www\./, '');
    if (h && !S.disabledSites.includes(h)) S.disabledSites.push(h);
    $('#site-input').value = ''; save();
  });
  $('#trusted').addEventListener('change', (e) => {
    S.trustedHosts = e.target.value.split(/\s+/).map((x) => x.trim().toLowerCase()).filter(Boolean); save();
  });
  $('#reset').addEventListener('click', () => {
    if (!confirm('Reset every CLEAR setting to its default?')) return;
    S = CLEAR.merge(CLEAR.DEFAULTS, {}); save();
  });
  $('#try-input').addEventListener('input', explain);
  $('#try-context').addEventListener('input', explain);
  $('#try-simplify').addEventListener('click', trySimplify);
  $('#try-input').addEventListener('input', () => { $('#try-simple').hidden = true; });
  $$('[data-ex]').forEach((b) => b.addEventListener('click', () => { $('#try-input').value = b.dataset.ex; $('#try-context').value = b.dataset.ctx || ''; explain(); }));
}

let trySeq = 0;
function explain() {
  const out = $('#try-out');
  const text = $('#try-input').value.trim();
  if (!text) { out.textContent = ''; out.appendChild(el('p', 'muted', 'Type a message to see how CLEAR reads it.')); return; }
  const x = CLEAR_ANALYZE.explain(text, $('#try-context').value);
  CLEAR_RENDER.explain(out, x, { heading: 'h4' });
  if (mode !== 'ext' || S.social.ai !== 'auto') return;
  const seq = ++trySeq;
  clearTimeout(explain.timer);
  explain.timer = setTimeout(() => chrome.runtime.sendMessage({ type: 'ai-read', text: x.text, context: x.context }, (r) => {
    void chrome.runtime.lastError;
    if (seq !== trySeq || !r || !(r.llm || r.irony)) return;
    CLEAR_RENDER.explain(out, CLEAR_ANALYZE.withModel(x, r), { heading: 'h4' });
    out.appendChild(el('div', 'muted small', r.llm ? 'Read by Chrome\'s on-device AI model.' : 'Sarcasm read by the on-device sarcasm models.')).style.marginTop = '10px';
  }), 350);
}

/* On-device models: status, download, remove. */
const MODEL_KEY = { irony: 'clearModel', simplify: 'clearModelSimplify' };
const MODEL_TEXT = {
  irony: { ready: 'Installed. Sarcasm is now read by the models in the Explain panel and for tone labels on posts.',
    none: 'Not installed. Without them, sarcasm is read by fixed rules, which miss subtle cases.',
    partial: 'Update: the sarcasm reader now uses a second small model. Download the missing part (about 68 MB).' },
  simplify: { ready: 'Installed. "Simplify" now rewrites whole sentences in simpler words.',
    none: 'Not installed. Without it, "Simplify" only swaps idioms and formal words from a built-in list.' }
};
function renderModel(name, m) {
  m = m || { state: 'none' };
  const row = document.querySelector('[data-model="' + name + '"]');
  const st = row.querySelector('.model-status'), get = row.querySelector('.model-get'), rm = row.querySelector('.model-remove');
  if (mode !== 'ext') { st.textContent = 'Open this page from the CLEAR extension to download the model.'; get.hidden = true; rm.hidden = true; return; }
  get.hidden = m.state === 'ready'; rm.hidden = m.state !== 'ready'; get.disabled = m.state === 'downloading';
  get.textContent = m.state === 'downloading' ? 'Downloading ' + (m.progress || 0) + '%' : m.state === 'error' ? 'Try again' : m.partial ? 'Download missing part' : 'Download (about ' + row.dataset.size + ')';
  st.textContent = m.state === 'ready' ? MODEL_TEXT[name].ready
    : m.state === 'downloading' ? 'Downloading once from huggingface.co. You can keep browsing.'
    : m.state === 'error' ? 'The download failed: ' + (m.error || 'unknown error') + '. Check your connection and try again.'
    : m.partial && MODEL_TEXT[name].partial ? MODEL_TEXT[name].partial
    : MODEL_TEXT[name].none + ' One-time download from huggingface.co, then it works offline.';
}
function bindModel() {
  for (const name of Object.keys(MODEL_KEY)) {
    if (mode !== 'ext') { renderModel(name, null); continue; }
    const key = MODEL_KEY[name], row = document.querySelector('[data-model="' + name + '"]');
    chrome.storage.local.get(key, (o) => renderModel(name, o && o[key]));
    row.querySelector('.model-get').addEventListener('click', () => chrome.runtime.sendMessage({ type: 'model-download', model: name }, () => void chrome.runtime.lastError));
    row.querySelector('.model-remove').addEventListener('click', () => chrome.runtime.sendMessage({ type: 'model-remove', model: name }, () => void chrome.runtime.lastError));
  }
  if (mode === 'ext') chrome.runtime.sendMessage({ type: 'model-check' }, () => void chrome.runtime.lastError); // already downloaded earlier?
  if (mode === 'ext') chrome.storage.onChanged.addListener((c, area) => {
    if (area !== 'local') return;
    for (const name of Object.keys(MODEL_KEY)) if (c[MODEL_KEY[name]]) { renderModel(name, c[MODEL_KEY[name]].newValue); if (name === 'irony') explain(); }
  });
}
function trySimplify() {
  const text = $('#try-input').value.trim();
  const box = $('#try-simple');
  if (!text) { box.hidden = true; return; }
  box.hidden = false; box.textContent = '';
  box.appendChild(el('h4', '', 'In simpler words'));
  const inner = box.appendChild(el('div'));
  const ext = mode === 'ext' && S.social.ai === 'auto';
  CLEAR_RENDER.simplify(inner, text, {
    ai: ext,
    send: (msg, cb) => chrome.runtime.sendMessage(msg, (r) => { void chrome.runtime.lastError; cb(r); }),
    offer: () => inner.appendChild(el('div', 'muted small', 'For a fuller rewrite, download the simplification model under Customize, Social clarity.'))
  });
}

function tryBridge() {
  return new Promise((res) => {
    let done = false;
    window.addEventListener('message', (e) => {
      if (e.source !== window || !e.data || e.data.source !== 'clear-ext' || e.data.type !== 'settings') return;
      S = CLEAR.merge(CLEAR.DEFAULTS, CLEAR.migrate(e.data.settings));
      if (!done) { done = true; res(true); } else render();
    });
    const hello = () => window.postMessage({ source: 'clear-site', type: 'hello' }, location.origin);
    hello(); setTimeout(hello, 400);
    setTimeout(() => { if (!done) { done = true; res(false); } }, 1200);
  });
}

(async () => {
  bind();
  if (CLEAR.hasStore()) {
    mode = 'ext';
    S = await CLEAR.load();
    CLEAR.onChange((s) => { S = s; render(); });
  } else if (location.protocol.startsWith('http') && await tryBridge()) {
    mode = 'bridge';
  } else {
    try { S = CLEAR.merge(CLEAR.DEFAULTS, CLEAR.migrate(JSON.parse(localStorage.getItem(CLEAR.KEY) || '{}'))); } catch (e) {}
  }
  render(); bindModel(); explain();
})();
