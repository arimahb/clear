const text = document.getElementById('text');
const context = document.getElementById('context');
const out = document.getElementById('out');
const simple = document.getElementById('simple');
const E = CLEAR_RENDER.el;

function run() {
  const t = text.value.trim();
  if (!t) { out.textContent = ''; out.appendChild(E('p', 'muted', 'Paste a message above to see how CLEAR reads it.')); return; }
  CLEAR_RENDER.explain(out, CLEAR_ANALYZE.explain(t, context.value), { heading: 'h4' });
}
function showSimple(go) {
  simple.textContent = '';
  simple.appendChild(E('h4', '', 'In simpler words'));
  const t = text.value.trim();
  if (!go || !t) {
    const b = E('button', '', 'Rewrite in simpler words'); b.type = 'button';
    b.addEventListener('click', () => showSimple(true));
    simple.appendChild(b);
    return;
  }
  CLEAR_RENDER.simplify(simple.appendChild(E('div')), t, {
    ai: true,
    send: (msg, cb) => chrome.runtime.sendMessage(msg, (r) => { void chrome.runtime.lastError; cb(r); }),
    offer: (box) => box.appendChild(E('div', 'muted small', 'For a fuller rewrite, download the simplification model in CLEAR settings, under Social clarity.'))
  });
}

try { text.value = decodeURIComponent(location.hash.slice(1)); } catch (e) {}
if (!text.value) document.getElementById('why').textContent = 'No selected text could be read from the page. Paste the message below.';
text.addEventListener('input', () => { run(); showSimple(false); });
context.addEventListener('input', run);
run();
showSimple(new URLSearchParams(location.search).has('simplify'));
