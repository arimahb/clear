/**
 * media.js
 * "Mute videos": runs in the page AND in every embedded frame (YouTube embeds,
 * video ads, pop-up players), because a page cannot reach videos inside a
 * frame from another site.
 *
 * Rule: every video plays muted. If you unmute a video yourself (click or key
 * press within the last second), CLEAR leaves that video alone. If the site's
 * own scripts unmute it, CLEAR mutes it again.
 */
(function () {
  const CLEAR = globalThis.CLEAR;
  if (!CLEAR || globalThis.__clearMediaReady) return;
  globalThis.__clearMediaReady = true;

  const USER_WINDOW_MS = 1000; // how recent a click/key press must be to count as "you did it"
  const userUnmuted = new WeakSet();
  const watchedRoots = new WeakSet();
  let prefs = CLEAR.merge(CLEAR.DEFAULTS, {});
  let lastInput = 0;
  let timer = 0;
  let tick = 0;

  /** Host name of the tab's top page, so "pause on this site" also covers its frames. */
  function topHost() {
    try {
      const anc = location.ancestorOrigins;
      if (anc && anc.length) return new URL(anc[anc.length - 1]).hostname;
    } catch (err) {
      /* fall through */
    }
    return location.hostname;
  }
  const host = topHost();

  const active = () => prefs.enabled && prefs.layout.muteVideos && !prefs.disabledSites.includes(host);
  const byUser = () => Date.now() - lastInput < USER_WINDOW_MS;

  /** Mute one video unless the user chose to hear it. */
  function mute(v) {
    if (!active() || userUnmuted.has(v)) return;
    if (!v.muted) v.muted = true;
  }

  /** Media events do not bubble and do not leave shadow roots, so listen on each root in capture. */
  function watchRoot(root) {
    if (watchedRoots.has(root)) return;
    watchedRoots.add(root);
    root.addEventListener('play', onMedia, true);
    root.addEventListener('playing', onMedia, true);
    root.addEventListener('loadedmetadata', onMedia, true);
    root.addEventListener('volumechange', onVolume, true);
  }

  function onMedia(ev) {
    if (ev.target && ev.target.tagName === 'VIDEO') mute(ev.target);
  }

  function onVolume(ev) {
    const v = ev.target;
    if (!v || v.tagName !== 'VIDEO' || v.muted || v.volume === 0) return;
    if (byUser()) userUnmuted.add(v); // you unmuted it: respect that
    else mute(v); // the site unmuted it: undo
  }

  /** Mute every video, including ones inside open shadow roots (web-component players). */
  function sweep(deep) {
    if (!active()) return;
    for (const v of document.querySelectorAll('video')) mute(v);
    if (!deep) return;
    const walk = (scope, level) => {
      if (level > 3) return;
      for (const el of scope.querySelectorAll('*')) {
        if (!el.shadowRoot) continue;
        watchRoot(el.shadowRoot);
        for (const v of el.shadowRoot.querySelectorAll('video')) mute(v);
        walk(el.shadowRoot, level + 1);
      }
    };
    walk(document, 0);
  }

  function update() {
    clearInterval(timer);
    if (!active()) return;
    sweep(true);
    // Light check every 1.5 s, deep (shadow DOM) check every 6 s.
    timer = setInterval(() => sweep(++tick % 4 === 0), 1500);
  }

  // Remember the user's own clicks and key presses (also inside players' shadow DOM).
  const noteInput = () => (lastInput = Date.now());
  window.addEventListener('pointerdown', noteInput, true);
  window.addEventListener('keydown', noteInput, true);
  watchRoot(document);

  chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== 'sync' || !changes.prefs) return;
    prefs = CLEAR.merge(CLEAR.DEFAULTS, CLEAR.migrate(changes.prefs.newValue));
    update();
  });
  CLEAR.loadPrefs().then((p) => {
    prefs = p;
    update();
  });
  document.addEventListener('DOMContentLoaded', () => sweep(true), { once: true });
})();
