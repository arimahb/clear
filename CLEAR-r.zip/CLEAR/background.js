/**
 * background.js (service worker)
 *  - opens the onboarding page on first install
 *  - adds the "Simplify with CLEAR" right-click menu item
 *  - relays AI requests from content scripts to the Flask backend
 *    (the OpenAI key never leaves the backend)
 */
importScripts('shared.js');

const ALLOWED_PATHS = new Set(['simplify', 'simplify-batch', 'labels', 'health', 'clarify']);

// Hosted AI function used when Settings > AI service is "CLEAR online assistant".
const HOSTED_ENDPOINT = 'https://base44.app/api/apps/6af8bdd4880b8cc2bfb32dd0/functions/clarifyText';
const HOSTED_MODES = ['plain', 'shorter', 'bullets', 'terms', 'ask'];

// ----- Answer cache -----
// Every hosted request uses Base44 integration credits (the free plan has about 100 a
// month), so identical requests are answered from this cache instead. It lives in
// chrome.storage.session: kept while the browser is open, cleared when it closes.
const CACHE_KEY = 'aiCache';
const CACHE_MAX = 200;

async function cacheKey(parts) {
  const bytes = new TextEncoder().encode(JSON.stringify(parts));
  const hash = await crypto.subtle.digest('SHA-256', bytes);
  return Array.from(new Uint8Array(hash).slice(0, 12), (b) => b.toString(16).padStart(2, '0')).join('');
}

async function cacheGet(key) {
  const store = (await chrome.storage.session.get(CACHE_KEY))[CACHE_KEY] || {};
  return store[key] ? store[key].v : null;
}

async function cachePut(key, value) {
  const store = (await chrome.storage.session.get(CACHE_KEY))[CACHE_KEY] || {};
  store[key] = { v: value, t: Date.now() };
  const keys = Object.keys(store);
  if (keys.length > CACHE_MAX) {
    keys.sort((a, b) => store[a].t - store[b].t).slice(0, keys.length - CACHE_MAX).forEach((k) => delete store[k]);
  }
  await chrome.storage.session.set({ [CACHE_KEY]: store });
}

/** True when an error message is about running out of credits or hitting a rate limit. */
const LIMIT_RE = /limit|credit|quota|exceed|too many|insufficient|upgrade|429|402/i;
const LIMIT_HELP =
  'The CLEAR online assistant has used up its AI allowance. It runs on Base44, whose free plan includes about ' +
  '100 AI uses a month. To fix it: wait for the monthly reset, upgrade the Base44 plan for this app, or switch ' +
  'Settings > AI help > AI service to "My own backend" (uses your own OpenAI key).';

/** Call the hosted clarifyText function. Resolves to {ok:true,data:{result}} or {ok:false,error}. */
async function callHosted(body) {
  const text = body && typeof body.text === 'string' ? body.text.trim() : '';
  const mode = body && HOSTED_MODES.includes(body.mode) ? body.mode : 'plain';
  const question = body && typeof body.question === 'string' ? body.question.trim().slice(0, 500) : '';
  if (!text) return { ok: false, error: 'Select some text first.' };

  const key = await cacheKey([text.slice(0, 8000), mode, question]);
  const cached = await cacheGet(key).catch(() => null);
  if (cached) return { ok: true, data: { result: cached, cached: true } };

  const ctrl = new AbortController();
  const timeout = setTimeout(() => ctrl.abort(), 45000);
  try {
    const res = await fetch(HOSTED_ENDPOINT, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ text: text.slice(0, 8000), mode, question }),
      signal: ctrl.signal
    });
    const raw = await res.text();
    let data = {};
    try {
      data = JSON.parse(raw);
    } catch (err) {
      /* not JSON */
    }
    // Accept {result}, or the same wrapped in {data:{result}} by some hosting setups.
    const result = data.result || (data.data && data.data.result);
    if (!res.ok || !result) {
      console.warn('[CLEAR] assistant replied', res.status, raw.slice(0, 500));
      const reason = String(data.error || data.message || (data.data && data.data.error) || '');
      if (res.status === 429 || res.status === 402 || LIMIT_RE.test(reason)) return { ok: false, limit: true, error: LIMIT_HELP };
      return { ok: false, error: reason ? `The CLEAR assistant said: ${reason}` : `The CLEAR assistant could not answer (HTTP ${res.status}). Try again in a moment.` };
    }
    const answer = String(result).trim();
    cachePut(key, answer).catch(() => {});
    return { ok: true, data: { result: answer } };
  } catch (err) {
    console.warn('[CLEAR] assistant request failed:', err);
    if (err.name === 'AbortError') return { ok: false, error: 'The CLEAR assistant took too long to answer. Try a shorter passage.' };
    return { ok: false, error: 'Could not reach the CLEAR assistant. Check your internet connection.' };
  } finally {
    clearTimeout(timeout);
  }
}

chrome.runtime.onInstalled.addListener(async (details) => {
  if (details.reason === 'install') {
    await chrome.storage.sync.set({ prefs: CLEAR.DEFAULTS });
    chrome.tabs.create({ url: chrome.runtime.getURL('onboarding.html') });
  }
  chrome.contextMenus.removeAll(() => {
    chrome.contextMenus.create({
      id: 'clear-simplify',
      title: 'Simplify with CLEAR',
      contexts: ['selection']
    });
  });
});

chrome.contextMenus.onClicked.addListener((info, tab) => {
  if (info.menuItemId !== 'clear-simplify' || !tab || tab.id == null) return;
  chrome.tabs
    .sendMessage(tab.id, { type: 'simplifySelection', text: info.selectionText || '' })
    .catch(() => {}); // page without the content script (e.g. chrome:// pages)
});

/** Call the Flask backend. Resolves to {ok:true,data} or {ok:false,error}. */
async function callBackend(path, body) {
  const prefs = await CLEAR.loadPrefs();
  let base;
  try {
    const u = new URL(prefs.backendUrl);
    if (!/^https?:$/.test(u.protocol)) throw new Error('protocol');
    base = u.origin + u.pathname.replace(/\/+$/, '');
  } catch (err) {
    return { ok: false, error: 'The backend URL in CLEAR settings is not valid.' };
  }

  const ctrl = new AbortController();
  const timeout = setTimeout(() => ctrl.abort(), 45000);
  try {
    const res =
      path === 'health'
        ? await fetch(`${base}/api/health`, { signal: ctrl.signal })
        : await fetch(`${base}/api/${path}`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(body || {}),
            signal: ctrl.signal
          });
    let data = null;
    try {
      data = await res.json();
    } catch (err) {
      /* non-JSON body */
    }
    if (!res.ok) return { ok: false, error: (data && data.error) || `The backend returned HTTP ${res.status}.` };
    return { ok: true, data };
  } catch (err) {
    return {
      ok: false,
      error:
        err.name === 'AbortError'
          ? 'The backend took too long to respond.'
          : `Could not reach the CLEAR backend at ${base}. Is it running? Open ${base}/api/health in a browser tab: it should show {"ok":true,...}. If not, start it with start.bat (Windows) or start.sh (Mac/Linux) in the CLEAR/backend folder.`
    };
  } finally {
    clearTimeout(timeout);
  }
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (sender.id !== chrome.runtime.id) return;
  if (msg && msg.type === 'openSettings') {
    chrome.runtime.openOptionsPage();
    return;
  }
  if (msg && msg.type === 'api' && ALLOWED_PATHS.has(msg.path)) {
    (msg.path === 'clarify' ? callHosted(msg.body) : callBackend(msg.path, msg.body)).then(sendResponse);
    return true; // keep the channel open for the async response
  }
});
