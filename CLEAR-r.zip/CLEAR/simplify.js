/**
 * simplify.js
 * AI text simplification:
 *  1. "Simplify with CLEAR" for highlighted text (button near the selection
 *     and the right-click menu item), shown in a small panel.
 *  2. Optional "Simplify page text" button when the Simplified text
 *     preference is on. It rewrites the first paragraphs of the main content
 *     in place, with a way back to the original.
 * All AI output is rendered with textContent, never as HTML.
 */
(function () {
  const CLEAR = (globalThis.CLEAR = globalThis.CLEAR || {});
  const h = CLEAR.h;

  const MAX_CHARS = 6000;
  const MAX_PARAS = 20;
  const prefs = () => CLEAR.state.prefs;
  const enabled = () => CLEAR.state.active && prefs().ai.enabled;

  let selBtn = null;
  let pendingText = '';
  let panel = null;

  // ---------- Highlight -> button ----------

  function hideSelBtn() {
    if (selBtn) selBtn.remove();
    selBtn = null;
  }

  function inEditable(node) {
    const el = node && (node.nodeType === 1 ? node : node.parentElement);
    return !!(el && el.closest('input,textarea,[contenteditable=""],[contenteditable="true"]'));
  }

  /** After a mouse/keyboard selection, offer the Simplify button next to it. */
  function onSelectionEnd(ev) {
    if (ev.target === CLEAR.overlay.host) return;
    setTimeout(() => {
      hideSelBtn();
      if (!enabled()) return;
      const sel = window.getSelection();
      const text = sel ? sel.toString().trim() : '';
      if (text.length < 8 || !sel.rangeCount || inEditable(sel.anchorNode)) return;
      const r = sel.getRangeAt(0).getBoundingClientRect();
      if (!r.width && !r.height) return;
      pendingText = text;
      selBtn = h('button', { class: 'selbtn', type: 'button', text: 'Simplify with CLEAR' });
      // Keep the text selected when the button is pressed.
      selBtn.addEventListener('mousedown', (e) => e.preventDefault());
      selBtn.addEventListener('click', () => {
        hideSelBtn();
        openPanel(pendingText);
      });
      CLEAR.overlay.layer().appendChild(selBtn);
      const below = r.bottom + 10 < window.innerHeight - 50;
      selBtn.style.left = Math.max(8, Math.min(r.left, window.innerWidth - 190)) + 'px';
      selBtn.style.top = (below ? r.bottom + 10 : Math.max(8, r.top - 46)) + 'px';
    }, 0);
  }

  function onSelectionChange() {
    const sel = window.getSelection();
    if (!sel || sel.isCollapsed) hideSelBtn();
  }

  // ---------- Result panel ----------

  function closePanel() {
    if (panel) panel.remove();
    panel = null;
  }

  function select(options, value, onchange) {
    const s = h('select', {}, options.map(([v, l]) => h('option', { value: v, text: l })));
    s.value = value;
    s.addEventListener('change', () => onchange(s.value));
    return s;
  }

  /** Turn "- item" / "1. item" lines into lists and other lines into paragraphs. */
  function renderText(container, text) {
    const lines = String(text).split(/\n+/).map((l) => l.trim()).filter(Boolean);
    let list = null;
    for (const line of lines) {
      const bullet = line.match(/^[-•*]\s+(.*)/);
      const num = line.match(/^\d+[.)]\s+(.*)/);
      const kind = bullet ? 'ul' : num ? 'ol' : null;
      if (kind) {
        if (!list || list.tagName.toLowerCase() !== kind) {
          list = h(kind);
          container.append(list);
        }
        list.append(h('li', { text: (bullet || num)[1] }));
      } else {
        list = null;
        container.append(h('p', { text: line }));
      }
    }
  }

  /**
   * Open the panel for `text` and request a simplification from the backend.
   * The original text stays available under "Original text".
   */
  function openLocalPanel(text) {
    if (!enabled() || !text) return;
    closePanel();
    const p = prefs();
    const truncated = text.length > MAX_CHARS;
    const original = text.slice(0, MAX_CHARS);
    const state = { level: p.ai.level, format: p.ai.format, req: 0 };

    const out = h('div', { 'aria-live': 'polite' });
    const controls = h('div', { class: 'controls' },
      h('label', {}, 'Level', select(CLEAR.OPTIONS.level, state.level, (v) => { state.level = v; run(); })),
      h('label', {}, 'Format', select(CLEAR.OPTIONS.format, state.format, (v) => { state.format = v; run(); }))
    );
    const copyBtn = h('button', { class: 'btn', type: 'button', text: 'Copy' });
    copyBtn.disabled = true;
    const body = h('div', { class: 'body' },
      controls,
      out,
      truncated ? h('p', { class: 'note', text: `Only the first ${MAX_CHARS} characters were simplified.` }) : null,
      h('details', {}, h('summary', { text: 'Original text' }), h('p', { text: original })),
      h('div', { class: 'row' }, copyBtn)
    );
    const closeBtn = h('button', { class: 'x', type: 'button', 'aria-label': 'Close', text: '×' });
    closeBtn.addEventListener('click', closePanel);
    panel = h('div', { class: 'panel', role: 'dialog', 'aria-label': 'CLEAR simplified text' },
      h('header', {}, h('strong', { text: 'CLEAR' }), closeBtn), body);
    CLEAR.overlay.layer().appendChild(panel);
    closeBtn.focus();

    let resultText = '';
    copyBtn.addEventListener('click', async () => {
      try {
        await navigator.clipboard.writeText(resultText);
        copyBtn.textContent = 'Copied';
      } catch (err) {
        copyBtn.textContent = 'Copy failed';
      }
      setTimeout(() => (copyBtn.textContent = 'Copy'), 1500);
    });

    async function run() {
      const id = ++state.req;
      out.replaceChildren(h('p', { class: 'status', text: 'Simplifying…' }));
      copyBtn.disabled = true;
      const ai = prefs().ai;
      const res = await CLEAR.api('simplify', {
        text: original,
        level: state.level,
        format: state.format,
        tasks: {
          explainWords: ai.explainWords,
          simplifySentences: ai.simplifySentences,
          summarize: ai.summarize,
          bullets: ai.bullets,
          steps: ai.steps
        }
      });
      if (id !== state.req || !panel) return; // a newer request replaced this one
      out.replaceChildren();
      if (!res.ok) {
        out.append(h('div', { class: 'error', role: 'alert', text: res.error }));
        return;
      }
      const data = res.data || {};
      resultText = String(data.simplified || '');
      if (!resultText) {
        out.append(h('div', { class: 'error', text: 'The AI returned no text. Try again.' }));
        return;
      }
      renderText(out, resultText);
      const glossary = Array.isArray(data.glossary) ? data.glossary : [];
      if (glossary.length) {
        const dl = h('dl');
        for (const g of glossary) {
          if (g && g.term && g.meaning) dl.append(h('dt', { text: String(g.term) }), h('dd', { text: String(g.meaning) }));
        }
        out.append(h('h4', { text: 'Word meanings' }), dl);
      }
      copyBtn.disabled = false;
    }
    run();
  }

  // ---------- Hosted assistant panel (default) ----------

  const HOSTED_MODES = [
    ['plain', 'Plain language'],
    ['shorter', 'Shorter'],
    ['bullets', 'Key points'],
    ['terms', 'Hard terms'],
    ['steps', 'Steps']
  ];
  const STEPS_QUESTION =
    'Rewrite this passage as short numbered steps, in the order it gives them. Do not add steps that are not in the passage.';

  /**
   * Send one request to the chosen AI service.
   *  'chrome' : Google's Gemini Nano built into Chrome (free, on this computer).
   *            If this computer can't run it, the online assistant is used instead.
   *  'hosted' : the CLEAR online assistant (Base44, limited credits).
   */
  async function ask(body, onStatus) {
    if (prefs().ai.provider === 'chrome') {
      const res = await CLEAR.chromeAI.run(body, onStatus);
      if (res.ok || !res.unavailable) return res;
      const fallback = await CLEAR.api('clarify', hostedBody(body));
      if (fallback.ok) fallback.data.note = `${res.error} This answer came from the CLEAR online assistant instead.`;
      else fallback.error = `${res.error}\n\nThe online assistant also failed: ${fallback.error}`;
      return fallback;
    }
    return CLEAR.api('clarify', hostedBody(body));
  }

  /** The hosted assistant has no "steps" mode, so steps become a question. */
  function hostedBody(body) {
    return body.mode === 'steps' ? { mode: 'ask', text: body.text, question: STEPS_QUESTION } : body;
  }

  /** Pick the starting mode from the user's AI preferences. */
  function defaultMode(ai) {
    const f = ai.format;
    if (f === 'steps' || (f === 'auto' && ai.steps)) return 'steps';
    if (f === 'bullets' || (f === 'auto' && ai.bullets)) return 'bullets';
    if (f === 'summary' || (f === 'auto' && ai.summarize)) return 'shorter';
    return 'plain';
  }

  /** Dispatch to the panel for the chosen AI service. */
  function openPanel(text) {
    if (!enabled() || !text) return;
    if (prefs().ai.provider === 'local') openLocalPanel(text);
    else openHostedPanel(text); // also used for Chrome's built-in AI
  }

  /**
   * Panel for the hosted assistant: mode buttons (plain language, shorter, key
   * points, hard terms, steps) and a box to ask questions about the passage.
   */
  function openHostedPanel(text) {
    closePanel();
    const truncated = text.length > MAX_CHARS;
    const original = text.slice(0, MAX_CHARS);
    const state = { req: 0, busy: false };
    let resultText = '';

    const out = h('div', { 'aria-live': 'polite' }, h('p', { class: 'note', text: 'Pick a way to make this clearer, or ask a question below.' }));
    const chat = h('div', { class: 'chat', 'aria-live': 'polite' });
    const copyBtn = h('button', { class: 'btn', type: 'button', text: 'Copy' });
    copyBtn.disabled = true;
    const input = h('input', { type: 'text', placeholder: 'Ask about this passage…', 'aria-label': 'Ask about this passage', maxlength: '500' });
    const send = h('button', { type: 'submit', text: 'Ask' });

    const chipEls = HOSTED_MODES.map(([mode, label]) => {
      const b = h('button', { class: 'chip', type: 'button', text: label });
      b.addEventListener('click', () => {
        chipEls.forEach((c) => c.classList.toggle('active', c === b));
        chat.replaceChildren();
        runMode(mode);
      });
      b.dataset.mode = mode;
      return b;
    });

    async function runMode(mode) {
      const id = ++state.req;
      const status = h('p', { class: 'status', text: 'Working…' });
      out.replaceChildren(status);
      copyBtn.disabled = true;
      const res = await ask({ mode, text: original }, (msg) => (status.textContent = msg));
      if (id !== state.req || !panel) return;
      out.replaceChildren();
      if (!res.ok) {
        out.append(h('div', { class: 'error', role: 'alert', text: res.error }));
        if (res.limit) {
          const go = h('button', { class: 'btn', type: 'button', text: 'Open AI settings' });
          go.addEventListener('click', () => chrome.runtime.sendMessage({ type: 'openSettings' }).catch(() => {}));
          out.append(h('div', { class: 'row' }, go));
        }
        return;
      }
      resultText = res.data.result;
      renderText(out, resultText);
      if (res.data.note) out.append(h('p', { class: 'note', text: res.data.note }));
      copyBtn.disabled = false;
    }

    const form = h('form', { class: 'askform' }, input, send);
    form.addEventListener('submit', async (ev) => {
      ev.preventDefault();
      const question = input.value.trim();
      if (!question || state.busy) return;
      input.value = '';
      state.busy = send.disabled = true;
      chat.append(h('div', { class: 'bubble me', text: question }));
      const wait = h('div', { class: 'bubble ai', text: 'Working…' });
      chat.append(wait);
      const res = await ask({ mode: 'ask', text: original, question }, (msg) => (wait.textContent = msg));
      wait.className = res.ok ? 'bubble ai' : 'bubble error';
      wait.textContent = res.ok ? res.data.result : res.error;
      state.busy = send.disabled = false;
      wait.scrollIntoView({ block: 'nearest' });
    });

    copyBtn.addEventListener('click', async () => {
      try {
        await navigator.clipboard.writeText(resultText);
        copyBtn.textContent = 'Copied';
      } catch (err) {
        copyBtn.textContent = 'Copy failed';
      }
      setTimeout(() => (copyBtn.textContent = 'Copy'), 1500);
    });

    const closeBtn = h('button', { class: 'x', type: 'button', 'aria-label': 'Close', text: '×' });
    closeBtn.addEventListener('click', closePanel);
    panel = h('div', { class: 'panel', role: 'dialog', 'aria-label': 'CLEAR simplified text' },
      h('header', {}, h('strong', { text: 'CLEAR' }), closeBtn),
      h('div', { class: 'body' },
        h('div', { class: 'chips' }, chipEls),
        out,
        truncated ? h('p', { class: 'note', text: `Only the first ${MAX_CHARS} characters were used.` }) : null,
        chat,
        h('details', {}, h('summary', { text: 'Original text' }), h('p', { text: original })),
        h('div', { class: 'row' }, copyBtn),
        form));
    CLEAR.overlay.layer().appendChild(panel);

    const first = defaultMode(prefs().ai);
    chipEls.find((c) => c.dataset.mode === first).click();
  }

  /** Simplify several paragraphs with whichever AI service is selected. */
  async function simplifyTexts(texts) {
    if (prefs().ai.provider === 'local') {
      const res = await CLEAR.api('simplify-batch', { texts, level: prefs().ai.level });
      return res.ok ? { ok: true, results: (res.data && res.data.results) || [] } : res;
    }
    if (prefs().ai.provider === 'chrome' && (await CLEAR.chromeAI.status()) !== 'unavailable' && (await CLEAR.chromeAI.status()) !== 'unsupported') {
      // Built-in AI is free, so each paragraph gets its own request (more reliable than splitting one answer).
      const results = [];
      for (const text of texts) {
        const res = await CLEAR.chromeAI.run({ mode: 'plain', text });
        if (!res.ok) return res;
        results.push(res.data.result);
      }
      return { ok: true, results };
    }
    // One request for the whole batch (saves AI credits): number the paragraphs and split the answer.
    const numbered = texts.map((t, i) => `[${i + 1}] ${t}`).join('\n\n');
    const res = await CLEAR.api('clarify', {
      mode: 'ask',
      text: numbered,
      question:
        'Rewrite each numbered paragraph in plain, easy language. Keep the same meaning and all important details. ' +
        'Start each rewritten paragraph with its number in square brackets, like [1]. Do not merge, skip or add paragraphs.'
    });
    if (!res.ok) return res;
    const parts = {};
    String(res.data.result).split(/\[(\d+)\]\s*/).forEach((chunk, i, arr) => {
      if (i % 2 === 1) parts[Number(chunk)] = (arr[i + 1] || '').trim();
    });
    return { ok: true, results: texts.map((_, i) => parts[i + 1] || '') };
  }

  // ---------- "Simplified text" mode: rewrite page paragraphs ----------

  const originals = new Map(); // <p> -> original child nodes
  const rewritten = new Map(); // <p> -> simplified text
  let showingSimplified = false;
  let busy = false;
  let pageBtn = null;
  let toast = null;
  let toastTimer = 0;

  function say(msg) {
    if (toast) toast.remove();
    toast = h('div', { class: 'toast', role: 'status', text: msg });
    CLEAR.overlay.dock().append(toast);
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => toast && toast.remove(), 7000);
  }

  function goodParagraph(p) {
    return (
      (p.textContent || '').trim().length >= 60 &&
      !p.querySelector('a,img,button,input,svg') &&
      !p.closest('nav,aside,footer,header,form,[data-clear-cat="comments"],[data-clear-cat="ads"]')
    );
  }

  function showSimplified(on) {
    showingSimplified = on;
    for (const [p, nodes] of originals) {
      if (on) p.textContent = rewritten.get(p);
      else p.replaceChildren(...nodes);
    }
    updatePageBtn();
  }

  async function simplifyPage() {
    if (busy) return;
    if (originals.size) return showSimplified(!showingSimplified);
    busy = true;
    updatePageBtn();
    const root = document.querySelector('main,[role="main"],article') || document.body;
    const paras = [...root.querySelectorAll('p')].filter(goodParagraph).slice(0, MAX_PARAS);
    if (!paras.length) {
      say('No plain paragraphs were found to simplify on this page.');
      busy = false;
      return updatePageBtn();
    }
    for (let i = 0; i < paras.length; i += 5) {
      const batch = paras.slice(i, i + 5);
      const res = await simplifyTexts(batch.map((p) => p.textContent.trim()));
      if (!res.ok) {
        say(res.error);
        break;
      }
      const results = res.results;
      batch.forEach((p, j) => {
        const t = String(results[j] || '').trim();
        if (!t) return;
        originals.set(p, Array.from(p.childNodes));
        rewritten.set(p, t);
      });
      showSimplified(true);
      say(`Simplified ${Math.min(i + 5, paras.length)} of ${paras.length} paragraphs…`);
    }
    busy = false;
    updatePageBtn();
  }

  function updatePageBtn() {
    const want = CLEAR.state.active && prefs().textMode === 'simplified' && prefs().ai.enabled;
    if (!want) {
      if (pageBtn) pageBtn.remove();
      pageBtn = null;
      return;
    }
    if (!pageBtn || !pageBtn.isConnected) {
      pageBtn = h('button', { class: 'pill', type: 'button' });
      pageBtn.addEventListener('click', simplifyPage);
      CLEAR.overlay.dock().append(pageBtn);
    }
    pageBtn.disabled = busy;
    pageBtn.textContent = busy ? 'Simplifying…' : originals.size ? (showingSimplified ? 'Show original text' : 'Show simplified text') : 'Simplify page text';
  }

  // ---------- Lifecycle ----------

  function start() {
    document.addEventListener('mouseup', onSelectionEnd, true);
    document.addEventListener('keyup', onSelectionEnd, true);
    document.addEventListener('selectionchange', onSelectionChange);
    window.addEventListener('scroll', hideSelBtn, { passive: true });
  }

  function stop() {
    document.removeEventListener('mouseup', onSelectionEnd, true);
    document.removeEventListener('keyup', onSelectionEnd, true);
    document.removeEventListener('selectionchange', onSelectionChange);
    window.removeEventListener('scroll', hideSelBtn);
    hideSelBtn();
    closePanel();
    if (originals.size && showingSimplified) showSimplified(false);
    originals.clear();
    rewritten.clear();
    showingSimplified = false;
    busy = false;
    pageBtn = toast = null;
  }

  /** Called when preferences change while CLEAR is active. */
  function refresh() {
    if (!prefs().ai.enabled) {
      hideSelBtn();
      closePanel();
    }
    if (prefs().textMode !== 'simplified' && originals.size) {
      showSimplified(false);
      originals.clear();
      rewritten.clear();
    }
    updatePageBtn();
  }

  CLEAR.simplify = { start, stop, refresh, openPanel };
})();
