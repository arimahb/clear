# CLEAR

A Chrome (Manifest V3) extension that adapts webpages to the reader: blur distractions, reveal sections one at a time, change text and layout, and simplify highlighted text with AI.

## Run it

**AI service.** By default CLEAR uses **Google's Gemini Nano, built into Chrome** (the Prompt API). It is free, needs no account or key, has no usage limit, and the text never leaves your computer. Requirements: a recent Chrome on Windows 10/11, macOS 13+, Linux or a Chromebook Plus; about 22 GB free disk space; and a GPU with more than 4 GB of memory or 16 GB of RAM. Chrome downloads the model once, the first time you simplify (or press "Set up Google's AI now" in Settings > AI help, which also shows whether your computer can run it). On computers that can't run it, CLEAR falls back to the hosted CLEAR assistant (`clarifyText` on base44.app, about 100 uses a month on Base44's free plan). "My own backend" (Flask + OpenAI key) is the third option.

**1. Own backend (optional)**

Easiest: double-click `backend/start.bat` (Windows) or run `backend/start.sh` (Mac/Linux). On the first run it creates `backend/.env` and stops; paste your `OPENAI_API_KEY` into it, save, and run it again. Leave the window open while you browse.

Check it works: open http://127.0.0.1:5001/api/health in a browser. It should show `{"ok":true,...,"openai_configured":true}`.

Manual setup:

```bash
cd backend
python -m venv .venv && source .venv/bin/activate     # Windows: .venv\Scripts\activate
pip install -r requirements.txt
cp .env.example .env                                   # then put your OPENAI_API_KEY in .env
python app.py                                          # http://127.0.0.1:5001
```

Port 5001 is used because macOS reserves 5000 for AirPlay. The key stays in `backend/.env`. The extension never sees it. The server listens on 127.0.0.1 only.

**2. Extension**

1. Open `chrome://extensions` and turn on **Developer mode**.
2. Click **Load unpacked** and choose this `CLEAR` folder (the one with `manifest.json`).
3. The setup screen opens on first install. Open any news site, blog or shop.

Blur, reveal, text and layout features work without the backend.

## Files

| File | Purpose |
|---|---|
| `manifest.json` | MV3 manifest, content script list, permissions |
| `shared.js` | Default preferences, Chrome Storage helpers, backend call helper |
| `sections.js` | Detects sections (main, ads, comments, related, sidebars, pop-ups, images, videos) |
| `blur.js` | Per-section blur, click-to-reveal, re-blur, Reveal all, labels |
| `overlay.js` | Shadow-DOM layer for labels, buttons and the result panel |
| `formatting.js`, `content.css` | Text size/spacing/font, animation, layout rules; blur CSS |
| `chrome-ai.js` | Google's Gemini Nano built into Chrome (free, on-device AI) |
| `simplify.js` | Highlight → "Simplify with CLEAR" panel; optional page-text simplification |
| `media.js` | Mutes videos in the page and in every embedded frame (players, video ads) |
| `content.js` | Starts/stops features, watches for new content, handles messages |
| `background.js` | Install hook, right-click menu, relays AI calls to the backend |
| `popup.*` | Toolbar popup |
| `onboarding.*`, `settings.*`, `prefs-form.js`, `pages.css` | Setup wizard and full settings page |
| `backend/app.py` | Flask + OpenAI endpoints (`/api/simplify`, `/api/simplify-batch`, `/api/labels`, `/api/health`) |

## How it behaves

- **Frost** is a CSS blur on each detected section, not on the page. Navigation bars, search and anything outside a section stay usable. Hold the mouse button down and drag across a frosted section to wipe it clear; each movement clears a soft round patch, and once about 55% is wiped the rest fades away. Plain clicks on frosted sections do nothing. Keyboard: Tab to a section and press Enter. Settings > Blurring > Reveal style can switch to "clear while hovered". Nested sections count as one. A revealed section shows **Frost again** on hover. **Reveal all** is in the popup and at the bottom-left of the page. Labels appear only on sections at least 140 x 70 px.
- **Pop-up videos**: a video player inside a small `position: fixed` box that is mostly video (a corner or picture-in-picture player) is frosted as one "Pop-up video" section, including players that start floating when you scroll and players built as web components.
- **Labels** use facts from the page (alt text, headings, counts). With **Describe sections with AI** on, a short excerpt of each blurred section is sent to your backend, which may answer with nothing if it cannot tell what the section is. Off by default. Skipped on pages with a password field.
- **Simplify with CLEAR**: highlight text, press the button that appears (or right-click). With the hosted assistant the panel has Plain language, Shorter, Key points, Hard terms and Steps buttons plus an "Ask about this passage" box. With your own backend it has Level and Format menus. The original text is kept under "Original text".
- **Dynamic pages**: new nodes are scanned after 250 ms, and a full re-scan runs every 5 s.
- **Pause on a site**: popup toggle. Paused sites are listed in settings.

## Known limits (not hidden)

- **Not tested in a real browser or with a real OpenAI key.** Syntax checks only. Expect to tune the detection on real sites.
- Section detection is heuristic (tag names, ARIA roles, class/id names, fixed positioning). It will miss unusual markup and may blur the wrong block on some sites. At most 1500 sections per page; videos and pop-ups are always tracked.
- Wiping uses `backdrop-filter` and CSS masks. While a section is being wiped, its frost pane is repositioned every frame, so very fast scrolling can show a sliver of unfrosted content at the edge for a moment.
- Pages with no `<main>`/`<article>` use a guess (the block with the most paragraph text) for "main content".
- Only the top-level page is processed. Ads and embeds inside iframes are blurred as a whole iframe, not inside.
- **Larger text** scales paragraph-like elements (p, li, td, …). Text styled on other elements may not grow.
- **Videos**: **Mute videos** (on by default) makes every video play muted, in the page and inside embedded frames such as YouTube embeds and video ads. Unmute a video with its own sound button and CLEAR leaves it alone; if the site unmutes it by itself, CLEAR mutes it again. Videos behind frost are also paused.
- **Reduce animations** shortens CSS animations/transitions. It cannot stop animated GIFs or canvas/JS animations.
- **Fonts**: Verdana and Comic Sans (system fonts). OpenDyslexic is not bundled.
- **Simplified text** rewrites only the first 20 plain paragraphs (no links) of the main content, on request.
- The backend has no login. Keep it on localhost.
