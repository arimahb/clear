/**
 * shared.js
 * Loaded by the content scripts, the service worker, and every extension page.
 * Holds the default preferences, Chrome Storage helpers and small utilities.
 */
(function () {
  const CLEAR = (globalThis.CLEAR = globalThis.CLEAR || {});

  /** Default preferences. Every key a page reads must exist here. */
  CLEAR.DEFAULTS = {
    enabled: true,
    // Smart Blur
    smartBlur: true,
    blurMode: 'distractions', // 'all' = blur main content too, 'distractions' = keep main content visible
    blurTypes: {
      images: false,
      videos: true,
      ads: true,
      comments: true,
      related: true,
      sidebars: true,
      popups: true
    },
    revealStyle: 'wipe', // 'wipe' = wipe the frost away with the cursor, 'hover' = clear while hovered
    showLabels: true, // show a short label over each blurred section
    aiLabels: false, // opt-in: send section text to the backend to write richer labels
    // Text
    textMode: 'standard', // 'standard' | 'simplified'
    largerText: false,
    spacing: false,
    font: 'default', // 'default' | 'clear' | 'friendly'
    // Page layout. ads/related/comments: 'default' (follow blur settings) | 'blur' | 'hide'
    layout: {
      clutter: false,
      ads: 'default',
      related: 'default',
      comments: 'default',
      motion: false,
      muteVideos: true, // every video plays muted until you unmute it yourself (media.js)
      simple: false
    },
    // AI text simplification
    ai: {
      enabled: true,
      explainWords: true,
      simplifySentences: true,
      summarize: false,
      bullets: false,
      steps: false,
      provider: 'chrome', // 'chrome' = Google's AI built into Chrome, 'hosted' = online CLEAR assistant, 'local' = your own Flask backend
      level: 'light', // overwritten below to 'moderate'
      format: 'auto'
    },
    backendUrl: 'http://127.0.0.1:5001',
    disabledSites: [],
    onboarded: false,
    schema: 6
  };
  CLEAR.DEFAULTS.ai.level = 'moderate';

  /** Option lists shared by the popup, settings page and on-page panel. */
  CLEAR.OPTIONS = {
    level: [
      ['light', 'Light: explain hard words'],
      ['moderate', 'Moderate: simpler sentences'],
      ['strong', 'Strong: as clear as possible']
    ],
    format: [
      ['auto', 'Match my settings'],
      ['paragraph', 'Short paragraphs'],
      ['bullets', 'Bullet points'],
      ['steps', 'Numbered steps'],
      ['summary', 'Short summary']
    ],
    font: [
      ['default', "Website's own font"],
      ['clear', 'Clear sans-serif (Verdana)'],
      ['friendly', 'Friendly rounded (Comic Sans)']
    ],
    revealStyle: [
      ['wipe', 'Press and drag to wipe the frost away'],
      ['hover', 'Clear it while my cursor is over it']
    ],
    provider: [
      ['chrome', "Google's AI built into Chrome (free, unlimited)"],
      ['hosted', 'CLEAR online assistant (Base44, limited credits)'],
      ['local', 'My own backend (Flask + OpenAI key)']
    ],
    layoutAction: [
      ['default', 'Use my blur settings'],
      ['blur', 'Always blur'],
      ['hide', 'Hide completely']
    ]
  };

  const isObj = (v) => v && typeof v === 'object' && !Array.isArray(v);

  /**
   * Merge `over` onto `base`. Only keys that exist in `base` are accepted,
   * so stale or unknown stored keys are dropped. Arrays are replaced.
   */
  CLEAR.merge = function merge(base, over) {
    const out = {};
    for (const key of Object.keys(base)) {
      const b = base[key];
      const o = isObj(over) ? over[key] : undefined;
      if (isObj(b)) out[key] = merge(b, o);
      else if (Array.isArray(b)) out[key] = Array.isArray(o) ? o.filter((x) => typeof x === 'string') : b.slice();
      else out[key] = o !== undefined && typeof o === typeof b ? o : b;
    }
    return out;
  };

  /** Read a dotted path such as "layout.motion". */
  CLEAR.getPath = (obj, path) => path.split('.').reduce((o, k) => (o == null ? o : o[k]), obj);

  /** Build a nested patch object from a dotted path: ("a.b", 1) -> {a:{b:1}}. */
  CLEAR.pathPatch = (path, value) =>
    path
      .split('.')
      .reverse()
      .reduce((acc, key) => ({ [key]: acc }), value);

  /** Load preferences from chrome.storage.sync, filling gaps with defaults. */
  CLEAR.loadPrefs = async function () {
    const stored = await chrome.storage.sync.get('prefs');
    return CLEAR.merge(CLEAR.DEFAULTS, CLEAR.migrate(stored.prefs));
  };

  /**
   * Upgrade preferences saved by an older version.
   *  v2: video blur and autoplay-stopping became default.
   *  v3: the backend address is 127.0.0.1:5001 (port 5000 clashes with macOS AirPlay;
   *      "localhost" can resolve to IPv6 while the backend listens on IPv4).
   *  v4: AI service set to the hosted CLEAR assistant.
   */
  CLEAR.migrate = function (stored) {
    if (!stored) return stored;
    const v = stored.schema || 1;
    if (v >= 6) return stored;
    let s = { ...stored };
    if (v < 2) {
      s.blurTypes = { ...s.blurTypes, videos: true };
      s.layout = { ...s.layout, muteVideos: true };
    }
    if (v < 3 && /^http:\/\/localhost:500[01]\/?$/.test(s.backendUrl || '')) s.backendUrl = CLEAR.DEFAULTS.backendUrl;
    // v4: the hosted CLEAR assistant is the AI service for everyone.
    if (v < 4) s.ai = { ...s.ai, provider: 'hosted' };
    // v5: muting moved to media.js and covers embedded players; turn it on once.
    if (v < 5) s.layout = { ...s.layout, muteVideos: true };
    // v6: Google's built-in Chrome AI (free, no credits) replaces the hosted assistant as default.
    if (v < 6 && (!s.ai || s.ai.provider !== 'local')) s.ai = { ...s.ai, provider: 'chrome' };
    s.schema = 6;
    return s;
  };

  CLEAR.savePrefs = (prefs) => chrome.storage.sync.set({ prefs });

  /** Merge a partial change into the stored preferences and save. */
  CLEAR.patchPrefs = async function (patch) {
    const current = await CLEAR.loadPrefs();
    const merged = CLEAR.merge(CLEAR.DEFAULTS, deepApply(current, patch));
    await CLEAR.savePrefs(merged);
    return merged;
  };

  /** Recursively copy `patch` values onto a copy of `target`. */
  function deepApply(target, patch) {
    const out = { ...target };
    for (const key of Object.keys(patch)) {
      if (isObj(patch[key]) && isObj(target[key])) out[key] = deepApply(target[key], patch[key]);
      else out[key] = patch[key];
    }
    return out;
  }

  /** Restore defaults. The setup screen is not shown again. */
  CLEAR.resetPrefs = async function () {
    const fresh = JSON.parse(JSON.stringify(CLEAR.DEFAULTS));
    fresh.onboarded = true;
    await CLEAR.savePrefs(fresh);
    return fresh;
  };

  /**
   * Call the Flask backend. Requests go through the service worker so the
   * page's own CSP and CORS rules do not apply and the backend URL stays private.
   * Resolves to {ok:true,data} or {ok:false,error}.
   */
  CLEAR.api = function (path, body) {
    return new Promise((resolve) => {
      const fail = () => resolve({ ok: false, error: 'CLEAR was reloaded. Refresh this page and try again.' });
      try {
        chrome.runtime.sendMessage({ type: 'api', path, body }, (res) => {
          if (chrome.runtime.lastError) return fail();
          resolve(res || { ok: false, error: 'No response from the CLEAR background service.' });
        });
      } catch (err) {
        fail();
      }
    });
  };

  /** Tiny DOM helper: h('div', {class:'x', text:'hi', onclick:fn}, child, child). */
  CLEAR.h = function (tag, attrs, ...kids) {
    const el = document.createElement(tag);
    for (const [k, v] of Object.entries(attrs || {})) {
      if (v == null || v === false) continue;
      if (k === 'class') el.className = v;
      else if (k === 'text') el.textContent = v;
      else if (k.startsWith('on') && typeof v === 'function') el.addEventListener(k.slice(2), v);
      else el.setAttribute(k, v === true ? '' : v);
    }
    for (const kid of kids.flat()) {
      if (kid != null && kid !== false) el.append(kid);
    }
    return el;
  };
})();
