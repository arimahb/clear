/**
 * overlay.js
 * One shadow-DOM host that holds all CLEAR UI drawn on top of a webpage
 * (labels, re-blur button, selection button, result panel, bottom-left dock).
 * The shadow root keeps the page's CSS from restyling our UI.
 */
(function () {
  const CLEAR = (globalThis.CLEAR = globalThis.CLEAR || {});

  // Muted grey and beige palette, matching ui.css.
  const CSS = `
    :host { all: initial; }
    * { box-sizing: border-box; font-family: ui-rounded, "SF Pro Rounded", system-ui, -apple-system, "Segoe UI", Roboto, sans-serif; }
    .layer { position: fixed; inset: 0; pointer-events: none; z-index: 2147483646; }

    /* Frost pane used while wiping. Same blur as .clear-blurred in content.css. */
    .frost { position: fixed; pointer-events: none;
      -webkit-backdrop-filter: blur(14px) saturate(0.7) brightness(1.03); backdrop-filter: blur(14px) saturate(0.7) brightness(1.03);
      background: rgba(246, 242, 235, 0.10); -webkit-mask-repeat: no-repeat; mask-repeat: no-repeat; }
    .frost.melt { transition: opacity .55s ease; opacity: 0; }

    /* Soft ring that follows the cursor over frosted sections. */
    .brush { position: fixed; transform: translate(-50%, -50%); border-radius: 50%; pointer-events: none;
      border: 1.5px solid rgba(255, 255, 255, .85); box-shadow: 0 0 0 1px rgba(95, 90, 82, .18), 0 2px 10px rgba(60, 55, 48, .12);
      background: radial-gradient(circle, rgba(255,255,255,.10), rgba(255,255,255,0) 70%); opacity: .55; transition: opacity .15s; }
    .brush.down { opacity: 1; background: radial-gradient(circle, rgba(255,255,255,.22), rgba(255,255,255,0) 70%); }

    /* Small grey label centred on a frosted section. */
    .badge { position: fixed; transform: translate(-50%, -50%); text-align: center; pointer-events: none;
      background: rgba(250, 248, 243, .72); color: #6b665e; border: 1px solid rgba(255, 255, 255, .75);
      border-radius: 12px; padding: 5px 12px 6px; font-size: 12.5px; line-height: 1.35; letter-spacing: .01em;
      box-shadow: 0 1px 8px rgba(60, 55, 48, .10);
      -webkit-backdrop-filter: blur(6px); backdrop-filter: blur(6px); }

    button { font: inherit; cursor: pointer; pointer-events: auto; }
    button:focus-visible, select:focus-visible, summary:focus-visible, input:focus-visible { outline: 2px solid #a89f92; outline-offset: 2px; }

    .reblur { position: fixed; background: rgba(250, 248, 243, .92); color: #5f5a52; border: 1px solid #e2dbcf; border-radius: 999px;
      padding: 5px 12px; font-size: 12.5px; font-weight: 600; box-shadow: 0 2px 10px rgba(60, 55, 48, .12);
      -webkit-backdrop-filter: blur(6px); backdrop-filter: blur(6px); }
    .reblur:hover, .pill:hover, .selbtn:hover { background: #efe9df; }

    .dock { position: fixed; left: 18px; bottom: 18px; display: flex; flex-direction: column; gap: 8px; align-items: flex-start; }
    .pill { background: rgba(250, 248, 243, .94); color: #5f5a52; border: 1px solid #e2dbcf; border-radius: 999px;
      padding: 8px 16px 8px 14px; font-size: 13px; font-weight: 600; letter-spacing: .01em;
      box-shadow: 0 4px 18px rgba(60, 55, 48, .14); display: inline-flex; align-items: center; gap: 8px;
      -webkit-backdrop-filter: blur(8px); backdrop-filter: blur(8px); }
    .pill::before { content: ""; width: 7px; height: 7px; border-radius: 50%; background: #b5ab9c; }
    .pill:disabled { opacity: .6; cursor: default; }
    .toast { background: rgba(250, 248, 243, .96); color: #4a463f; border: 1px solid #e2dbcf; border-radius: 12px; padding: 8px 12px;
      font-size: 13px; max-width: 320px; box-shadow: 0 4px 18px rgba(60, 55, 48, .12); pointer-events: auto; }

    .selbtn { position: fixed; background: #fbf9f4; color: #5f5a52; border: 1px solid #e2dbcf; border-radius: 999px;
      padding: 6px 13px 6px 11px; font-size: 13px; font-weight: 600; box-shadow: 0 6px 20px rgba(60, 55, 48, .16);
      display: inline-flex; align-items: center; gap: 7px; }
    .selbtn::before { content: ""; width: 6px; height: 6px; border-radius: 50%; background: #b5ab9c; }

    .panel { position: fixed; right: 18px; bottom: 18px; width: min(400px, calc(100vw - 36px)); max-height: 75vh; overflow: auto;
      background: #fbf9f4; color: #3b3833; border: 1px solid #e2dbcf; border-radius: 16px;
      box-shadow: 0 24px 60px -20px rgba(60, 55, 48, .40); pointer-events: auto; font-size: 15.5px; line-height: 1.6; }
    .panel header { display: flex; align-items: center; justify-content: space-between; padding: 10px 14px;
      background: rgba(243, 238, 229, .96); border-bottom: 1px solid #ebe4d8; position: sticky; top: 0;
      -webkit-backdrop-filter: blur(6px); backdrop-filter: blur(6px); }
    .panel header strong { font-size: 11px; letter-spacing: .2em; color: #7d776d; display: inline-flex; align-items: center; gap: 7px; }
    .panel header strong::before { content: ""; width: 7px; height: 7px; border-radius: 50%; background: #b5ab9c; }
    .panel .x { background: none; border: 0; font-size: 20px; line-height: 1; padding: 2px 8px; color: #8a8478; border-radius: 8px; }
    .panel .x:hover { background: #ece6dc; color: #3b3833; }
    .panel .body { padding: 12px 14px 14px; }
    .panel .controls { display: flex; gap: 8px; flex-wrap: wrap; margin-bottom: 10px; }
    .panel label { font-size: 12px; color: #7d776d; display: flex; flex-direction: column; gap: 3px; flex: 1; min-width: 120px; }
    .panel select { font-size: 14px; padding: 6px; border: 1px solid #ddd5c8; border-radius: 8px; background: #fff; color: inherit; }
    .panel p { margin: 0 0 .7em; }
    .panel ul, .panel ol { margin: 0 0 .7em; padding-left: 1.4em; }
    .panel li { margin-bottom: .3em; }
    .panel li::marker { color: #a89f92; }
    .panel h4 { margin: .9em 0 .3em; font-size: 12px; letter-spacing: .12em; text-transform: uppercase; color: #8a8478; }
    .panel dl { margin: 0; font-size: 14px; }
    .panel dt { font-weight: 700; }
    .panel dd { margin: 0 0 .5em; color: #5f5a52; }
    .panel .status { color: #8a8478; font-style: italic; }
    .panel .error { color: #8a3b2e; background: #f6e9e4; border-radius: 10px; padding: 8px 10px; font-size: 14px; }
    .panel details { margin-top: 12px; font-size: 14px; }
    .panel details summary { cursor: pointer; color: #7d776d; }
    .panel details p { white-space: pre-wrap; color: #5f5a52; background: #f4f0e8; border-radius: 10px; padding: 8px 10px; margin-top: 6px; }
    .panel .chips { display: flex; flex-wrap: wrap; gap: 6px; margin-bottom: 12px; }
    .panel .chip { border: 1px solid #e2dbcf; background: #fff; color: #5f5a52; border-radius: 999px; padding: 5px 11px; font-size: 13px; }
    .panel .chip:hover { border-color: #b5ab9c; }
    .panel .chip.active { background: #6f6a62; border-color: #6f6a62; color: #faf8f3; }
    .panel .chat { display: flex; flex-direction: column; gap: 6px; margin-top: 10px; }
    .panel .bubble { padding: 7px 11px; border-radius: 12px; font-size: 14px; max-width: 92%; white-space: pre-wrap; }
    .panel .bubble.me { align-self: flex-end; background: #6f6a62; color: #faf8f3; }
    .panel .bubble.ai { align-self: flex-start; background: #efe9df; }
    .panel .bubble.error { align-self: flex-start; background: #f6e9e4; color: #8a3b2e; }
    .panel .askform { display: flex; gap: 6px; margin-top: 12px; padding-top: 10px; border-top: 1px solid #ebe4d8; }
    .panel .askform input { flex: 1; min-width: 0; border: 1px solid #ddd5c8; border-radius: 999px; padding: 7px 12px; font-size: 14px; color: inherit; background: #fff; }
    .panel .askform button { border: 0; border-radius: 999px; background: #6f6a62; color: #faf8f3; padding: 0 14px; font-size: 13px; font-weight: 600; }
    .panel .askform button:disabled { opacity: .45; cursor: default; }
    .panel .note { font-size: 12.5px; color: #8a8478; }
    .panel .row { display: flex; gap: 8px; margin-top: 10px; }
    .panel .btn { background: #fff; color: #5f5a52; border: 1px solid #ddd5c8; border-radius: 999px; padding: 5px 14px; font-size: 13px; }
    .panel .btn:hover:not(:disabled) { background: #f4f0e8; }
    .panel .btn:disabled { opacity: .5; cursor: default; }

    @media (prefers-reduced-motion: reduce) { .frost.melt { transition: none; } }
  `;

  let host = null;
  let layer = null;
  let dock = null;

  /** Create the host the first time something needs to be drawn. */
  function ensure() {
    if (host && host.isConnected) return;
    host = document.createElement('div');
    host.id = 'clear-overlay-host';
    host.style.cssText = 'all:initial;position:fixed;top:0;left:0;width:0;height:0;z-index:2147483647;';
    const root = host.attachShadow({ mode: 'open' });
    const style = document.createElement('style');
    style.textContent = CSS;
    layer = document.createElement('div');
    layer.className = 'layer';
    dock = document.createElement('div');
    dock.className = 'dock';
    layer.appendChild(dock);
    root.append(style, layer);
    // Typing in our panel must not trigger the page's keyboard shortcuts.
    ['keydown', 'keyup', 'keypress'].forEach((t) => host.addEventListener(t, (ev) => ev.stopPropagation()));
    document.documentElement.appendChild(host);
  }

  CLEAR.overlay = {
    get host() {
      return host;
    },
    layer() {
      ensure();
      return layer;
    },
    dock() {
      ensure();
      return dock;
    },
    remove() {
      if (host) host.remove();
      host = layer = dock = null;
    }
  };
})();
