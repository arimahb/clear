/**
 * formatting.js
 * Text and layout preferences, plus video handling.
 * Formatting is applied as classes on <html>; the matching rules live in content.css.
 */
(function () {
  const CLEAR = (globalThis.CLEAR = globalThis.CLEAR || {});

  const CLASSES = [
    'clear-larger', 'clear-spacing', 'clear-font-clear', 'clear-font-friendly', 'clear-no-motion', 'clear-simple'
  ];
  const BLUR_MUTE = 'data-clear-blur-muted'; // remembers the muted state of videos silenced by a blur
  let listening = false;

  /** Turn formatting classes on or off to match the preferences. */
  function apply(prefs, active) {
    const cl = document.documentElement.classList;
    CLASSES.forEach((c) => cl.remove(c));
    if (!active) return;
    if (prefs.largerText) cl.add('clear-larger');
    if (prefs.spacing) cl.add('clear-spacing');
    if (prefs.font === 'clear') cl.add('clear-font-clear');
    if (prefs.font === 'friendly') cl.add('clear-font-friendly');
    if (prefs.layout.motion) cl.add('clear-no-motion');
    if (prefs.layout.simple) cl.add('clear-simple');
  }

  /** Videos in `root`, including one level of shadow DOM (web-component players). */
  function videosIn(root) {
    if (root.tagName === 'VIDEO') return [root];
    const out = [...root.querySelectorAll('video')];
    if (root.shadowRoot) out.push(...root.shadowRoot.querySelectorAll('video'));
    return out;
  }

  /** True when the video is inside a blurred or hidden CLEAR section, even through shadow roots. */
  function behindBlur(v) {
    for (let n = v; n; ) {
      if (n.closest && n.closest('.clear-blurred,.clear-hidden')) return true;
      const root = n.getRootNode && n.getRootNode();
      n = root && root.host ? root.host : null;
    }
    return false;
  }
  const watched = new WeakSet();

  /** Pause and mute a video. `attr` records the previous muted state so it can be restored. */
  function quiet(v, attr) {
    if (attr && !v.hasAttribute(attr)) v.setAttribute(attr, v.muted ? '1' : '0');
    v.muted = true;
    v.autoplay = false;
    if (!v.paused) v.pause();
  }

  /**
   * Called while a video section is blurred or hidden: pause and mute its
   * videos. Embedded players (iframes) cannot be controlled from here, so for
   * those we only switch off "autoplay=1" in their address.
   */
  function silence(root) {
    for (const v of videosIn(root)) quiet(v, BLUR_MUTE);
    if (root.tagName === 'IFRAME' && /[?&]autoplay=1/.test(root.src) && !root.hasAttribute('data-clear-noauto')) {
      root.setAttribute('data-clear-noauto', '1');
      root.src = root.src.replace(/([?&])autoplay=1/, '$1autoplay=0');
    }
  }

  /** When the section is shown again, restore the sound setting (it stays paused). */
  function unsilence(root) {
    for (const v of videosIn(root)) {
      if (!v.hasAttribute(BLUR_MUTE)) continue;
      v.muted = v.getAttribute(BLUR_MUTE) === '1';
      v.removeAttribute(BLUR_MUTE);
    }
  }

  /**
   * A video behind frost (or hidden) is paused and muted, even if the site
   * tries to play it. General muting of all videos lives in media.js, which
   * also runs inside embedded frames.
   */
  function onPlay(ev) {
    const v = ev.target;
    if (!v || v.tagName !== 'VIDEO' || !CLEAR.state.active) return;
    if (behindBlur(v)) quiet(v, BLUR_MUTE);
  }

  /** "play" events do not leave shadow roots, so videos found there get their own listener. */
  function watchVideo(v) {
    if (!v || v.tagName !== 'VIDEO' || watched.has(v)) return;
    watched.add(v);
    if (v.getRootNode() !== document) v.addEventListener('play', onPlay);
    if (CLEAR.state.active && behindBlur(v)) quiet(v, BLUR_MUTE);
  }

  /** Make sure videos behind frost are quiet (called after each scan). */
  function calmMedia(prefs, active) {
    if (!active) return;
    for (const v of document.querySelectorAll('video')) if (behindBlur(v)) quiet(v, BLUR_MUTE);
  }

  function listen() {
    if (listening) return;
    listening = true;
    document.addEventListener('play', onPlay, true); // media events do not bubble
  }

  function unlisten() {
    listening = false;
    document.removeEventListener('play', onPlay, true);
  }

  CLEAR.formatting = { apply, calmMedia, silence, unsilence, listen, unlisten, watchVideo };
})();
