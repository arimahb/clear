/**
 * popup.js
 * Toolbar popup. Simple switches write straight to chrome.storage (every page
 * picks the change up live). Page-specific actions talk to the content script.
 */
(async function () {
  const $ = (id) => document.getElementById(id);
  let prefs = await CLEAR.loadPrefs();
  let tab = null;
  let host = '';

  // Fill the dropdowns from the shared option lists.
  const fill = (sel, options) => options.forEach(([v, l]) => sel.append(new Option(l, v)));
  fill($('levelSel'), CLEAR.OPTIONS.level);
  fill($('formatSel'), CLEAR.OPTIONS.format);
  fill($('fontSel'), CLEAR.OPTIONS.font);
  fill($('revealSel'), CLEAR.OPTIONS.revealStyle);

  /** Show the stored value in every control tagged with data-pref="path". */
  function syncControls() {
    for (const input of document.querySelectorAll('[data-pref]')) {
      const value = CLEAR.getPath(prefs, input.dataset.pref);
      if (input.type === 'checkbox') input.checked = !!value;
      else input.value = value;
    }
    $('pauseSite').checked = host && prefs.disabledSites.includes(host);
  }

  for (const input of document.querySelectorAll('[data-pref]')) {
    input.addEventListener('change', async () => {
      const value = input.type === 'checkbox' ? input.checked : input.value;
      prefs = await CLEAR.patchPrefs(CLEAR.pathPatch(input.dataset.pref, value));
      refreshPage();
    });
  }

  // ----- Current tab -----
  [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  try {
    const u = new URL(tab.url);
    if (/^https?:$/.test(u.protocol)) host = u.hostname;
  } catch (err) {
    /* no URL available */
  }
  if (host) {
    $('siteName').textContent = host;
    $('siteRow').hidden = false;
  }
  syncControls();

  $('pauseSite').addEventListener('change', async () => {
    const list = new Set(prefs.disabledSites);
    $('pauseSite').checked ? list.add(host) : list.delete(host);
    prefs = await CLEAR.patchPrefs({ disabledSites: [...list] });
    refreshPage();
  });

  // ----- Reveal all / Blur all again -----
  let pageState = null;

  /** Ask the page how many sections are blurred and update the button. */
  async function refreshPage() {
    const btn = $('revealAll');
    const status = $('pageStatus');
    pageState = null;
    if (!host) {
      btn.disabled = true;
      status.textContent = 'CLEAR cannot run on this kind of page.';
      return;
    }
    // Give the content script a moment to react to a changed preference.
    await new Promise((r) => setTimeout(r, 150));
    try {
      pageState = await chrome.tabs.sendMessage(tab.id, { type: 'getState' });
    } catch (err) {
      pageState = null;
    }
    if (!pageState) {
      btn.disabled = true;
      status.textContent = 'Reload this page once so CLEAR can start on it.';
    } else if (!pageState.active) {
      btn.disabled = true;
      status.textContent = prefs.disabledSites.includes(host) ? 'CLEAR is paused on this site.' : 'CLEAR is off.';
    } else if (pageState.blurred > 0) {
      btn.disabled = false;
      btn.textContent = 'Reveal all';
      status.textContent = `${pageState.blurred} blurred section${pageState.blurred === 1 ? '' : 's'} on this page.`;
    } else if (pageState.total > 0) {
      btn.disabled = false;
      btn.textContent = 'Blur all again';
      status.textContent = 'Everything is revealed.';
    } else {
      btn.disabled = true;
      btn.textContent = 'Reveal all';
      status.textContent = 'Nothing is blurred on this page.';
    }
  }

  $('revealAll').addEventListener('click', async () => {
    const type = pageState && pageState.blurred > 0 ? 'revealAll' : 'blurAgain';
    try {
      await chrome.tabs.sendMessage(tab.id, { type });
    } catch (err) {
      /* handled by refresh */
    }
    refreshPage();
  });

  // ----- Footer -----
  $('openSettings').addEventListener('click', () => {
    chrome.runtime.openOptionsPage();
    window.close();
  });

  // Reset needs a second click so it cannot happen by accident.
  let resetTimer = 0;
  $('reset').addEventListener('click', async () => {
    const btn = $('reset');
    if (!btn.classList.contains('confirm')) {
      btn.classList.add('confirm');
      btn.textContent = 'Click again to reset';
      resetTimer = setTimeout(() => {
        btn.classList.remove('confirm');
        btn.textContent = 'Reset preferences';
      }, 4000);
      return;
    }
    clearTimeout(resetTimer);
    btn.classList.remove('confirm');
    btn.textContent = 'Reset preferences';
    prefs = await CLEAR.resetPrefs();
    syncControls();
    refreshPage();
  });

  refreshPage();
})();
