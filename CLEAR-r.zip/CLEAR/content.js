/**
 * content.js
 * Entry point injected into every http(s) page. Loads the preferences,
 * decides whether CLEAR is active on this site, starts/stops the features,
 * watches for dynamically added content, and answers popup messages.
 */
(function () {
  const CLEAR = globalThis.CLEAR;
  if (window.top !== window) return; // top-level pages only
  if (document.contentType && !/html/i.test(document.contentType)) return;

  CLEAR.state = { prefs: CLEAR.merge(CLEAR.DEFAULTS, {}), active: false };

  let observer = null;
  let scanTimer = 0;
  let fullTimer = 0;
  let pending = new Set();

  const isActive = (p) => p.enabled && !p.disabledSites.includes(location.hostname);

  /**
   * Run one feature step without letting its errors stop the others, so a
   * problem in Smart Blur on an unusual page can never break text simplification.
   */
  function safely(name, fn) {
    try {
      fn();
    } catch (err) {
      console.warn(`[CLEAR] ${name} failed:`, err);
    }
  }

  /** Apply the current preferences: start, update or stop the features. */
  function applyPrefs() {
    const was = CLEAR.state.active;
    CLEAR.state.active = isActive(CLEAR.state.prefs);
    safely('formatting', () => CLEAR.formatting.apply(CLEAR.state.prefs, CLEAR.state.active));

    if (!CLEAR.state.active) {
      if (was) stop();
      return;
    }
    if (!was) start();
    safely('simplify', () => CLEAR.simplify.refresh());
    safely('blur', () => CLEAR.blur.refresh());
    safely('media', () => CLEAR.formatting.calmMedia(CLEAR.state.prefs, true));
  }

  function start() {
    observer = new MutationObserver(onMutations);
    observer.observe(document.documentElement, { childList: true, subtree: true });
    safely('simplify', () => CLEAR.simplify.start()); // first, so it works even if blur fails
    safely('media', () => CLEAR.formatting.listen());
    const full = () => scanNow([document.documentElement]);
    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', full, { once: true });
    else full();
    window.addEventListener('load', full, { once: true });
    // Catch sections that appear without new DOM nodes (e.g. a modal shown by toggling a class).
    fullTimer = setInterval(() => {
      if (!document.hidden) scanNow([document.documentElement]);
    }, 5000);
  }

  function stop() {
    if (observer) observer.disconnect();
    observer = null;
    clearTimeout(scanTimer);
    clearInterval(fullTimer);
    pending.clear();
    safely('blur', () => CLEAR.blur.destroy());
    safely('simplify', () => CLEAR.simplify.stop());
    safely('media', () => CLEAR.formatting.unlisten());
    CLEAR.overlay.remove();
  }

  function scanNow(roots) {
    if (!CLEAR.state.active) return;
    safely('blur scan', () => CLEAR.blur.scan(roots));
    safely('media', () => CLEAR.formatting.calmMedia(CLEAR.state.prefs, true));
  }

  /** Collect newly added elements and scan them once things settle (250 ms). */
  function onMutations(mutations) {
    for (const m of mutations) {
      for (const n of m.addedNodes) {
        if (n.nodeType === 1 && n.id !== 'clear-overlay-host') pending.add(n);
      }
    }
    if (!pending.size || scanTimer) return;
    scanTimer = setTimeout(() => {
      scanTimer = 0;
      const roots = pending.size > 60 ? [document.documentElement] : [...pending];
      pending = new Set();
      scanNow(roots);
    }, 250);
  }

  // Preferences changed anywhere (popup, settings page, another tab).
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== 'sync' || !changes.prefs) return;
    CLEAR.state.prefs = CLEAR.merge(CLEAR.DEFAULTS, changes.prefs.newValue);
    applyPrefs();
  });

  // Messages from the popup and the right-click menu.
  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (sender.id !== chrome.runtime.id || !msg) return;
    if (msg.type === 'getState') {
      sendResponse({ active: CLEAR.state.active, hostname: location.hostname, ...CLEAR.blur.stats() });
    } else if (msg.type === 'revealAll') {
      CLEAR.blur.revealAll();
      sendResponse({ ok: true });
    } else if (msg.type === 'blurAgain') {
      CLEAR.blur.blurAgain();
      sendResponse({ ok: true });
    } else if (msg.type === 'simplifySelection') {
      CLEAR.simplify.openPanel(String(msg.text || ''));
    }
  });

  CLEAR.loadPrefs().then((prefs) => {
    CLEAR.state.prefs = prefs;
    applyPrefs();
  });
})();
