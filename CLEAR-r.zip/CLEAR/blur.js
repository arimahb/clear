/**
 * blur.js
 * Smart Blur: tracks page sections, frosts/hides them according to the
 * preferences, lets the user wipe the frost away with the cursor (or clear it
 * on hover), handles re-blur and Reveal all, draws labels, and requests
 * optional AI labels.
 *
 * Resting state: a CSS blur class on each section element (content.css),
 * never on <body>, so navigation, forms and browser controls keep working.
 *
 * Wiping: when the user presses the mouse button on a frosted section, an identical frosted pane
 * (backdrop-filter) is laid over it and the element's own blur is removed.
 * Each movement while the button is held punches a soft round hole in the pane's mask. When most
 * of the section is wiped, the rest of the frost fades away.
 */
(function () {
  const CLEAR = (globalThis.CLEAR = globalThis.CLEAR || {});
  const S = CLEAR.sections;
  const h = CLEAR.h;

  /** el -> { cat, revealed, action, covered, label, aiLabel, aiAsked, badge, wipe } */
  const entries = new Map();
  let revealAllActive = false;
  let hovered = null; // revealed section under the pointer (gets a "Blur again" button)
  let hoverEl = null; // frosted section under the pointer
  let rafId = 0;
  let tick = 0;
  let timer = 0;
  let listening = false;
  let pill = null;
  let reblurBtn = null;
  let brush = null;
  let pressing = null; // frosted section the mouse button was pressed on
  let wiped = false; // something was wiped during the current press
  let suppressClick = false; // swallow the click that follows a wipe

  // Limits. Videos and pop-ups are always tracked, even past the cap.
  const MAX_ENTRIES = 1500;
  const ALWAYS = new Set(['videos', 'popups']);

  // Wipe tuning
  const WIPE_GRID = 16; // coverage is measured on a 16 x 16 grid per section
  const WIPE_DONE = 0.55; // fade the rest once 55% is wiped
  const MAX_STAMPS = 180; // mask layers per section before finishing automatically

  // Media seen on the page, re-checked on scroll for players that start floating.
  const media = new Set();
  let floatTimer = 0;

  // AI label state
  const LABELABLE = new Set(['main', 'comments', 'related', 'sidebars', 'popups', 'ads']);
  const MAX_AI_LABELS = 40;
  const aiQueue = [];
  const aiById = new Map();
  let aiTimer = 0;
  let aiCount = 0;
  let aiNextId = 1;
  let aiFailed = false;

  const prefs = () => CLEAR.state.prefs;
  const wipeMode = () => prefs().revealStyle !== 'hover';

  /**
   * What should happen to a section of this category: 'blur', 'hide' or 'none'.
   * Page-layout choices (hide/blur ads, related, comments) win over Smart Blur.
   */
  function actionFor(cat) {
    const p = prefs();
    const L = p.layout;
    if (cat === 'clutter') return L.clutter || L.simple ? 'hide' : 'none';
    if (L.simple && (cat === 'ads' || cat === 'sidebars')) return 'hide';
    if (cat === 'ads' || cat === 'related' || cat === 'comments') {
      if (L[cat] === 'hide') return 'hide';
      if (L[cat] === 'blur') return 'blur';
    }
    if (!p.smartBlur) return 'none';
    if (cat === 'main') return p.blurMode === 'all' ? 'blur' : 'none';
    return p.blurTypes[cat] ? 'blur' : 'none';
  }

  /**
   * True when a tracked ancestor is already blurred (any category). Only the
   * outermost blurred section gets a blur and a label, so an ad inside a
   * pop-up inside a sidebar is one section, not three.
   */
  function coveredByAncestor(el) {
    for (let n = el.parentElement; n; n = n.parentElement) {
      const a = entries.get(n);
      if (a && actionFor(a.cat) === 'blur') return true;
    }
    return false;
  }

  /** Put the right classes on one section element. */
  function apply(el, e) {
    e.action = actionFor(e.cat);
    e.covered = e.action === 'blur' && coveredByAncestor(el);
    if (e.covered) e.revealed = false;
    const blurred = e.action === 'blur' && !e.revealed && !e.covered;
    const hidden = e.action === 'hide' && !e.revealed;
    if (e.wipe && (!blurred || !wipeMode())) clearWipe(el, e);
    el.classList.toggle('clear-blurred', blurred);
    el.classList.toggle('clear-wiping', blurred && !!e.wipe);
    el.classList.toggle('clear-hidden', hidden);
    // Blurred videos must not keep playing sound behind the blur.
    if (e.cat === 'videos') {
      const quiet = blurred || hidden || (e.covered && !!(el.parentElement && el.parentElement.closest('.clear-blurred')));
      if (quiet) CLEAR.formatting.silence(el);
      else CLEAR.formatting.unsilence(el);
    }
    // Make blurred sections reachable by keyboard.
    if (blurred) {
      if (!el.hasAttribute('tabindex')) {
        el.setAttribute('tabindex', '0');
        el.setAttribute('data-clear-tab', '1');
      }
    } else if (el.hasAttribute('data-clear-tab')) {
      el.removeAttribute('tabindex');
      el.removeAttribute('data-clear-tab');
    }
  }

  function applyAll() {
    for (const [el, e] of entries) apply(el, e);
  }

  // ---------- Discovering sections ----------

  /** Register one element if it is a section. */
  function track(el) {
    if (entries.has(el)) return;
    const cat = S.classify(el);
    if (!cat) {
      // Images and videos have no size until they load; look again then.
      const waits = el.tagName === 'IMG' ? !el.complete : el.tagName === 'VIDEO' && el.readyState < 1;
      if (waits && !el.hasAttribute('data-clear-wait')) {
        el.setAttribute('data-clear-wait', '1');
        el.addEventListener(el.tagName === 'IMG' ? 'load' : 'loadedmetadata', () => {
          el.removeAttribute('data-clear-wait');
          scan([el]);
        }, { once: true });
      }
      return;
    }
    trackAs(el, cat);
  }

  function trackAs(el, cat, label) {
    if (entries.has(el)) return;
    if (entries.size >= MAX_ENTRIES && !ALWAYS.has(cat)) return;
    // A section nested inside one of the same kind is covered by the outer one.
    if (el.parentElement && el.parentElement.closest(`[data-clear-cat="${cat}"]`)) return;
    el.setAttribute('data-clear-cat', cat);
    const e = {
      cat, revealed: revealAllActive, action: 'none', covered: false,
      label: label || S.baseLabel(el, cat), aiLabel: '', aiAsked: false, badge: null, wipe: null
    };
    entries.set(el, e);
    // A floating box may already contain tracked sections; recompute them.
    if (ALWAYS.has(cat)) for (const [child, ce] of entries) if (child !== el && el.contains(child)) apply(child, ce);
    apply(el, e);
    queueAi(el, e);
  }

  /**
   * Pop-up and floating video players: a <video>/<iframe> inside a fixed or
   * sticky box is tracked as one "Pop-up video" section (the whole box), and
   * videos inside web components are tracked through their host element.
   */
  function checkMedia(m) {
    if (!m.isConnected) {
      media.delete(m);
      return;
    }
    if (m.tagName === 'VIDEO') CLEAR.formatting.watchVideo(m);
    if (!S.isVideoPlayer(m)) return;
    const box = S.floatingContainer(m);
    if (box && box !== document.body) {
      if (!entries.has(box)) trackAs(box, 'videos', 'Pop-up video');
      return;
    }
    if (m.getRootNode() !== document) {
      const host = S.lightHost(m);
      if (host && host !== document.body && !entries.has(host)) {
        const r = m.getBoundingClientRect();
        if (r.width >= 80 && r.height >= 60) trackAs(host, 'videos');
      }
    }
  }

  /** Scan the given subtrees (new DOM nodes, or the whole document). */
  function scan(roots) {
    const deep = roots.includes(document.documentElement);
    for (const root of roots) {
      if (!root || root.nodeType !== 1 || !root.isConnected) continue;
      track(root);
      for (const el of root.querySelectorAll(S.SELECTOR)) track(el);
      for (const m of S.mediaIn(root, deep)) {
        media.add(m);
        checkMedia(m);
      }
    }
    if (document.readyState !== 'loading' && ![...entries.values()].some((e) => e.cat === 'main')) {
      const m = S.fallbackMain();
      if (m && !entries.has(m)) trackAs(m, 'main');
    }
    scheduleRender();
  }

  /** Many players switch to floating while you scroll; re-check them shortly after. */
  function onScrollFloat() {
    if (floatTimer) return;
    floatTimer = setTimeout(() => {
      floatTimer = 0;
      for (const m of media) checkMedia(m);
      scheduleRender();
    }, 350);
  }

  // ---------- Reveal / re-blur ----------

  function reveal(el) {
    const e = entries.get(el);
    if (!e) return;
    e.revealed = true;
    apply(el, e);
    scheduleRender();
  }

  function reblur(el) {
    const e = entries.get(el);
    if (!e) return;
    e.revealed = false;
    revealAllActive = false;
    hovered = null;
    apply(el, e);
    scheduleRender();
  }

  function revealAll() {
    revealAllActive = true;
    for (const e of entries.values()) e.revealed = true;
    applyAll();
    scheduleRender();
  }

  function blurAgain() {
    revealAllActive = false;
    hovered = null;
    for (const e of entries.values()) e.revealed = false;
    applyAll();
    scheduleRender();
  }

  function stats() {
    let total = 0, blurred = 0, hidden = 0;
    for (const e of entries.values()) {
      if (e.action === 'none' || e.covered) continue;
      total++;
      if (!e.revealed) e.action === 'blur' ? blurred++ : hidden++;
    }
    return { total, blurred, hidden };
  }

  // ---------- Wiping the frost ----------

  /** Brush size scales with the section: small boxes get a smaller brush. */
  function brushRadius(r) {
    return Math.max(22, Math.min(56, Math.min(r.width, r.height) * 0.16));
  }

  /** Lay a frosted pane over the section and switch off the element's own blur. */
  function startWipe(el, e) {
    const pane = h('div', { class: 'frost' });
    const cs = getComputedStyle(el);
    pane.style.borderRadius = cs.borderRadius;
    CLEAR.overlay.layer().appendChild(pane);
    e.wipe = { pane, stamps: [], grid: new Uint8Array(WIPE_GRID * WIPE_GRID), covered: 0, last: null, dirty: true };
    placePane(el, e); // position before the element's blur is removed, so nothing flashes
    el.classList.add('clear-wiping');
  }

  function placePane(el, e) {
    const r = el.getBoundingClientRect();
    const s = e.wipe.pane.style;
    s.left = r.left + 'px';
    s.top = r.top + 'px';
    s.width = r.width + 'px';
    s.height = r.height + 'px';
    s.display = r.bottom < -50 || r.top > window.innerHeight + 50 ? 'none' : '';
  }

  /** Add one soft hole at (x, y) in section coordinates and update coverage. */
  function stamp(w, x, y, rad, r) {
    w.stamps.push({ x: Math.round(x), y: Math.round(y), rad: Math.round(rad) });
    const cw = r.width / WIPE_GRID;
    const ch = r.height / WIPE_GRID;
    const reach = rad * 0.8;
    const i0 = Math.max(0, Math.floor((x - reach) / cw));
    const i1 = Math.min(WIPE_GRID - 1, Math.floor((x + reach) / cw));
    const j0 = Math.max(0, Math.floor((y - reach) / ch));
    const j1 = Math.min(WIPE_GRID - 1, Math.floor((y + reach) / ch));
    for (let j = j0; j <= j1; j++) {
      for (let i = i0; i <= i1; i++) {
        const k = j * WIPE_GRID + i;
        if (w.grid[k]) continue;
        if (Math.hypot((i + 0.5) * cw - x, (j + 0.5) * ch - y) <= reach) {
          w.grid[k] = 1;
          w.covered++;
        }
      }
    }
  }

  /** Wipe along the path from the previous point to (clientX, clientY). */
  function wipeTo(el, e, clientX, clientY) {
    const w = e.wipe;
    const r = el.getBoundingClientRect();
    const rad = brushRadius(r);
    const x = clientX - r.left;
    const y = clientY - r.top;
    const step = rad * 0.45;
    if (!w.last) {
      stamp(w, x, y, rad, r);
    } else {
      const d = Math.hypot(x - w.last.x, y - w.last.y);
      if (d < step) return;
      const n = Math.min(12, Math.floor(d / step));
      for (let k = 1; k <= n; k++) {
        stamp(w, w.last.x + ((x - w.last.x) * k) / n, w.last.y + ((y - w.last.y) * k) / n, rad, r);
      }
    }
    w.last = { x, y };
    w.dirty = true;
    if (w.covered / (WIPE_GRID * WIPE_GRID) >= WIPE_DONE || w.stamps.length >= MAX_STAMPS) finishWipe(el, e);
    else scheduleRender();
  }

  /** Mask = every stamp's soft hole, intersected. */
  function paintMask(w) {
    const s = w.pane.style;
    const layers = w.stamps.map((p) => `radial-gradient(circle at ${p.x}px ${p.y}px, transparent ${Math.round(p.rad * 0.5)}px, #000 ${p.rad}px)`);
    const value = layers.length ? layers.join(',') : 'none';
    s.webkitMaskImage = value;
    s.maskImage = value;
    s.webkitMaskComposite = 'source-in';
    s.maskComposite = 'intersect';
    w.dirty = false;
  }

  /** Enough is wiped: fade the rest of the frost away and reveal the section. */
  function finishWipe(el, e) {
    const pane = e.wipe.pane;
    e.wipe = null;
    pane.classList.add('melt');
    setTimeout(() => pane.remove(), 600);
    reveal(el);
  }

  /** Remove a wipe without revealing (re-blur, reset, settings change). */
  function clearWipe(el, e) {
    if (!e.wipe) return;
    e.wipe.pane.remove();
    e.wipe = null;
    el.classList.remove('clear-wiping');
  }

  function showBrush(x, y, rad, down) {
    if (!brush || !brush.isConnected) {
      brush = h('div', { class: 'brush' });
      CLEAR.overlay.layer().appendChild(brush);
    }
    const s = brush.style;
    s.display = '';
    s.width = s.height = rad * 2 + 'px';
    s.left = x + 'px';
    s.top = y + 'px';
    brush.classList.toggle('down', !!down);
  }

  function hideBrush() {
    if (brush) brush.style.display = 'none';
  }

  function frostedAt(ev) {
    if (ev.target === CLEAR.overlay.host) return null;
    const el = ev.target && ev.target.closest ? ev.target.closest('.clear-blurred') : null;
    return el && entries.has(el) ? el : null;
  }

  /** Wipe the pointer's path, including the in-between points Chrome coalesced. */
  function wipeEvent(el, ev) {
    const e = entries.get(el);
    if (!e.wipe) startWipe(el, e);
    const points = ev.getCoalescedEvents ? ev.getCoalescedEvents() : [];
    for (const p of points.length ? points : [ev]) {
      if (!e.wipe) break; // finished during this event
      wipeTo(el, e, p.clientX, p.clientY);
    }
    wiped = true;
  }

  /** Pressing the main mouse button on a frosted section starts a wipe. */
  function onDown(ev) {
    if (!wipeMode() || ev.button !== 0 || ev.pointerType === 'touch') return;
    const el = frostedAt(ev);
    if (!el) return;
    ev.preventDefault(); // no text selection or image dragging while wiping
    pressing = el;
    wiped = false;
    const e = entries.get(el);
    if (e.wipe) e.wipe.last = null; // a new stroke, not joined to the previous one
    wipeEvent(el, ev);
    showBrush(ev.clientX, ev.clientY, brushRadius(el.getBoundingClientRect()), true);
  }

  /** Moving shows the brush ring; only moving with the button held wipes. */
  function onMove(ev) {
    const el = frostedAt(ev);
    if (!el || !wipeMode() || ev.pointerType === 'touch') return hideBrush();
    const down = pressing === el && (ev.buttons & 1) === 1;
    showBrush(ev.clientX, ev.clientY, brushRadius(el.getBoundingClientRect()), down);
    if (down) wipeEvent(el, ev);
    else if (pressing === el) {
      const e = entries.get(el);
      if (e && e.wipe) e.wipe.last = null;
    }
  }

  function onUp() {
    if (!pressing) return;
    const e = entries.get(pressing);
    if (e && e.wipe) e.wipe.last = null;
    pressing = null;
    if (wiped) {
      suppressClick = true; // the browser sends a click right after mouseup
      setTimeout(() => (suppressClick = false), 0);
    }
    wiped = false;
    if (brush) brush.classList.remove('down');
  }

  // ---------- Events ----------

  /**
   * Wipe mode: clicks on a frosted section do nothing (only pressing and
   * dragging clears frost), and the click that ends a wipe is swallowed so
   * it never activates a link that was just uncovered.
   * Hover mode: a click on a still-frosted section reveals it; a section under
   * the cursor is already clear, so its clicks go through normally.
   */
  function onClick(ev) {
    if (suppressClick) {
      suppressClick = false;
      ev.preventDefault();
      ev.stopImmediatePropagation();
      return;
    }
    const el = frostedAt(ev);
    if (!el) return;
    if (!wipeMode() && el === hoverEl) return;
    ev.preventDefault();
    ev.stopImmediatePropagation();
    if (!wipeMode()) reveal(el);
  }

  function onKey(ev) {
    if ((ev.key === 'Enter' || ev.key === ' ') && ev.target && ev.target.classList && ev.target.classList.contains('clear-blurred')) {
      ev.preventDefault();
      reveal(ev.target);
    }
  }

  /** Track the section under the pointer (labels hide, Blur again appears). */
  function onOver(ev) {
    if (ev.target === CLEAR.overlay.host) return; // pointer is on our own button
    const blurredUnder = ev.target.closest ? ev.target.closest('.clear-blurred') : null;
    if (blurredUnder !== hoverEl) {
      hoverEl = blurredUnder;
      if (!hoverEl) hideBrush();
      scheduleRender();
    }
    let n = ev.target;
    let found = null;
    while (n && n.nodeType === 1) {
      const e = entries.get(n);
      if (e && e.revealed && e.action === 'blur' && !e.covered) {
        found = n;
        break;
      }
      n = n.parentElement;
    }
    if (found !== hovered) {
      hovered = found;
      scheduleRender();
    }
  }

  function onLeavePage() {
    hoverEl = null;
    hideBrush();
    scheduleRender();
  }

  function onScroll() {
    hideBrush();
    onScrollFloat();
    scheduleRender();
  }

  function listen() {
    if (listening) return;
    listening = true;
    document.addEventListener('click', onClick, true);
    document.addEventListener('auxclick', onClick, true);
    document.addEventListener('keydown', onKey, true);
    document.addEventListener('mouseover', onOver, true);
    document.addEventListener('pointerdown', onDown, true);
    document.addEventListener('pointermove', onMove, { capture: true, passive: true });
    document.addEventListener('pointerup', onUp, true);
    document.addEventListener('pointercancel', onUp, true);
    window.addEventListener('blur', onUp);
    document.documentElement.addEventListener('mouseleave', onLeavePage);
    window.addEventListener('scroll', onScroll, { capture: true, passive: true });
    window.addEventListener('resize', scheduleRender);
    // Slow heartbeat: re-position labels after layout shifts, and re-apply
    // classes if the site's own scripts overwrote them.
    timer = setInterval(() => {
      if (++tick % 5 === 0) applyAll();
      scheduleRender();
    }, 1000);
  }

  function unlisten() {
    if (!listening) return;
    listening = false;
    document.removeEventListener('click', onClick, true);
    document.removeEventListener('auxclick', onClick, true);
    document.removeEventListener('keydown', onKey, true);
    document.removeEventListener('mouseover', onOver, true);
    document.removeEventListener('pointerdown', onDown, true);
    document.removeEventListener('pointermove', onMove, { capture: true });
    document.removeEventListener('pointerup', onUp, true);
    document.removeEventListener('pointercancel', onUp, true);
    window.removeEventListener('blur', onUp);
    document.documentElement.removeEventListener('mouseleave', onLeavePage);
    window.removeEventListener('scroll', onScroll, { capture: true });
    window.removeEventListener('resize', scheduleRender);
    clearInterval(timer);
    clearTimeout(floatTimer);
    floatTimer = 0;
  }

  // ---------- Drawing labels, panes and buttons ----------

  function scheduleRender() {
    if (!rafId) rafId = requestAnimationFrame(render);
  }

  function labelFor(e) {
    if (!prefs().showLabels) return '';
    return e.aiLabel ? `${S.NAMES[e.cat]}: ${e.aiLabel}` : e.label;
  }

  function removeBadge(e) {
    if (e.badge) e.badge.remove();
    e.badge = null;
  }

  /** Position frost panes and labels for every frosted section on screen. */
  function render() {
    rafId = 0;
    if (!CLEAR.state.active) return;
    const vw = window.innerWidth;
    const vh = window.innerHeight;
    let blurredCount = 0;
    let blurTotal = 0;

    for (const [el, e] of entries) {
      if (!el.isConnected) {
        removeBadge(e);
        if (e.wipe) e.wipe.pane.remove();
        entries.delete(el);
        continue;
      }
      if (e.action === 'blur' && !e.covered) blurTotal++;
      if (!el.classList.contains('clear-blurred')) {
        removeBadge(e);
        continue;
      }
      blurredCount++;
      if (e.wipe) {
        placePane(el, e);
        if (e.wipe.dirty) paintMask(e.wipe);
      }
      const r = el.getBoundingClientRect();
      if (r.bottom < 0 || r.top > vh || r.right < 0 || r.left > vw || r.width < 40 || r.height < 24) {
        if (e.badge) e.badge.style.display = 'none';
        continue;
      }
      if (!e.badge || !e.badge.isConnected) {
        e.badge = h('div', { class: 'badge' });
        CLEAR.overlay.layer().appendChild(e.badge);
      }
      const text = labelFor(e);
      if (e.badge.textContent !== text) e.badge.textContent = text;
      const b = e.badge.style;
      // Only on sections with room for it; hidden under the cursor and once wiping has begun.
      const roomy = r.width >= 140 && r.height >= 70;
      const started = e.wipe && e.wipe.stamps.length > 0;
      b.display = text && roomy && el !== hoverEl && !started ? '' : 'none';
      // Centre the label in the part of the section that is on screen.
      const left = Math.max(r.left, 0);
      const right = Math.min(r.right, vw);
      const top = Math.max(r.top, 0);
      const bottom = Math.min(r.bottom, vh);
      b.maxWidth = Math.min(Math.max(right - left - 24, 100), 340) + 'px';
      b.left = (left + right) / 2 + 'px';
      b.top = (top + bottom) / 2 + 'px';
    }

    renderReblur(vw, vh);
    renderPill(blurredCount, blurTotal);
  }

  /** "Blur again" button for the revealed section under the pointer. */
  function renderReblur(vw, vh) {
    const e = hovered && entries.get(hovered);
    if (!e || !hovered.isConnected || !e.revealed || e.action !== 'blur') {
      if (reblurBtn) reblurBtn.remove();
      reblurBtn = null;
      return;
    }
    const r = hovered.getBoundingClientRect();
    if (r.width < 40 || r.height < 24 || r.bottom < 0 || r.top > vh) {
      if (reblurBtn) reblurBtn.style.display = 'none';
      return;
    }
    if (!reblurBtn || !reblurBtn.isConnected) {
      reblurBtn = h('button', { class: 'reblur', type: 'button', text: 'Frost again' });
      reblurBtn.addEventListener('click', () => hovered && reblur(hovered));
      CLEAR.overlay.layer().appendChild(reblurBtn);
    }
    reblurBtn.style.display = '';
    reblurBtn.style.left = Math.max(8, Math.min(r.right - 112, vw - 120)) + 'px';
    reblurBtn.style.top = Math.max(8, Math.min(Math.max(r.top + 10, 8), r.bottom - 40)) + 'px';
  }

  /** Bottom-left button: "Reveal all (n)" or "Frost all again". */
  function renderPill(blurredCount, blurTotal) {
    if (blurTotal === 0) {
      if (pill) pill.remove();
      pill = null;
      return;
    }
    if (!pill || !pill.isConnected) {
      pill = h('button', { class: 'pill', type: 'button' });
      pill.addEventListener('click', () => (stats().blurred > 0 ? revealAll() : blurAgain()));
      CLEAR.overlay.dock().prepend(pill);
    }
    const text = blurredCount > 0 ? `Reveal all (${blurredCount})` : 'Frost all again';
    if (pill.textContent !== text) pill.textContent = text;
  }

  // ---------- AI context labels (opt-in) ----------

  function aiAllowed() {
    const p = prefs();
    // Never send text from pages that contain a password field.
    // Not with the hosted assistant: each label would use a Base44 credit.
    return p.aiLabels && p.showLabels && p.ai.provider !== 'hosted' && !aiFailed && !document.querySelector('input[type="password"]');
  }

  function queueAi(el, e) {
    if (!aiAllowed() || e.aiAsked || !LABELABLE.has(e.cat) || aiCount >= MAX_AI_LABELS || e.action !== 'blur' || e.covered) return;
    const text = (el.innerText || '').replace(/\s+/g, ' ').trim();
    if (text.length < 30) return;
    e.aiAsked = true;
    aiCount++;
    const id = aiNextId++;
    aiById.set(id, e);
    aiQueue.push({ id, category: e.cat, text: text.slice(0, 700) });
    clearTimeout(aiTimer);
    aiTimer = setTimeout(flushAi, 800);
  }

  const LABEL_QUESTION =
    'In 4 to 12 words, say what this part of a webpage is about, using only the text given. ' +
    'Do not repeat what type of section it is and do not add an introduction. ' +
    'If the text does not make it clear, answer exactly: unclear';

  /** Ask the AI service for labels. Resolves to {ok,labels:{id:description}} or {ok:false,error}. */
  async function fetchLabels(items) {
    if (prefs().ai.provider === 'local') {
      const res = await CLEAR.api('labels', { items });
      return res.ok ? { ok: true, labels: (res.data && res.data.labels) || {} } : res;
    }
    const labels = {};
    if (prefs().ai.provider === 'chrome') {
      // Built-in AI: one at a time, on this computer.
      for (const it of items) {
        const res = await CLEAR.chromeAI.run({ mode: 'ask', text: it.text, question: LABEL_QUESTION });
        if (!res.ok) return res;
        const d = res.data.result.replace(/^["'\s]+|["'.\s]+$/g, '');
        if (d && !/^unclear\b/i.test(d) && d.length <= 100) labels[it.id] = d;
      }
      return { ok: true, labels };
    }
    for (let i = 0; i < items.length; i += 3) {
      const group = items.slice(i, i + 3);
      const answers = await Promise.all(group.map((it) => CLEAR.api('clarify', { mode: 'ask', text: it.text, question: LABEL_QUESTION })));
      for (let j = 0; j < group.length; j++) {
        if (!answers[j].ok) return answers[j];
        const d = answers[j].data.result.replace(/^["'\s]+|["'.\s]+$/g, '');
        if (d && !/^unclear\b/i.test(d) && d.length <= 100) labels[group[j].id] = d;
      }
    }
    return { ok: true, labels };
  }

  async function flushAi() {
    while (aiQueue.length) {
      const items = aiQueue.splice(0, 8);
      const res = await fetchLabels(items);
      if (!res.ok) {
        aiFailed = true; // stop retrying until preferences change
        console.warn('[CLEAR] AI labels unavailable:', res.error);
        return;
      }
      const labels = res.labels;
      for (const id of Object.keys(labels)) {
        const e = aiById.get(Number(id));
        const d = String(labels[id] || '').trim();
        if (e && d) e.aiLabel = d.slice(0, 120);
      }
      scheduleRender();
    }
  }

  // ---------- Lifecycle ----------

  /** Re-evaluate every section after preferences changed. */
  function refresh() {
    aiFailed = false;
    listen();
    document.documentElement.classList.toggle('clear-reveal-hover', !wipeMode());
    for (const [el, e] of entries) {
      apply(el, e);
      queueAi(el, e);
    }
    scheduleRender();
  }

  /** Remove every CLEAR change from the page. */
  function destroy() {
    unlisten();
    document.documentElement.classList.remove('clear-reveal-hover');
    for (const [el, e] of entries) {
      if (e.wipe) e.wipe.pane.remove();
      if (e.cat === 'videos') CLEAR.formatting.unsilence(el);
      el.classList.remove('clear-blurred', 'clear-hidden', 'clear-wiping');
      el.removeAttribute('data-clear-cat');
      if (el.hasAttribute('data-clear-tab')) {
        el.removeAttribute('tabindex');
        el.removeAttribute('data-clear-tab');
      }
    }
    entries.clear();
    media.clear();
    aiQueue.length = 0;
    aiById.clear();
    aiCount = 0;
    revealAllActive = false;
    hovered = hoverEl = pill = reblurBtn = brush = pressing = null;
    wiped = suppressClick = false;
  }

  CLEAR.blur = { scan, refresh, destroy, revealAll, blurAgain, stats, applyAll };
})();
