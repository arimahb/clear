/**
 * onboarding.js
 * First-run setup wizard (opened automatically on install). Every choice is
 * saved immediately to chrome.storage.sync, so nothing is lost if the tab is
 * closed early.
 */
(async function () {
  const $ = (id) => document.getElementById(id);
  const h = CLEAR.h;
  const prefs = await CLEAR.loadPrefs();

  const form = CLEAR.form.create(prefs, async (patch) => {
    await CLEAR.patchPrefs(patch);
    const s = $('saved');
    s.classList.add('show');
    setTimeout(() => s.classList.remove('show'), 1200);
  });

  const done = h('section', { class: 'panel-card done' },
    h('h2', { text: 'You\u2019re all set' }),
    h('p', { text: 'CLEAR now applies your choices to every website you open. Pages that are already open need a reload.' }),
    h('p', { class: 'hint', text: 'Use the CLEAR icon in the toolbar to switch features on or off, pause CLEAR on one site, or reveal blurred sections. Highlight text on any page to simplify it.' }),
    h('p', { class: 'hint', text: 'Highlighting text uses Google\u2019s free AI built into Chrome. Chrome downloads it once the first time; if your computer can\u2019t run it, CLEAR uses the online assistant.' }),
    h('p', {}, h('a', { href: 'settings.html', text: 'Open all settings' }))
  );

  const steps = [form.sections.blur, form.sections.text, form.sections.layout, form.sections.ai, done];
  let index = 0;

  function show() {
    $('stepHost').replaceChildren(steps[index]);
    $('steps').replaceChildren(...steps.map((_, i) => h('span', { class: i <= index ? 'on' : '' })));
    const last = index === steps.length - 1;
    $('back').hidden = index === 0 || last;
    $('next').textContent = last ? 'Close this tab' : index === steps.length - 2 ? 'Finish' : 'Next';
    $('progress').textContent = last ? '' : `Step ${index + 1} of ${steps.length - 1}`;
    window.scrollTo(0, 0);
    $('next').focus();
  }

  $('back').addEventListener('click', () => {
    index = Math.max(0, index - 1);
    show();
  });
  $('next').addEventListener('click', async () => {
    if (index === steps.length - 1) return window.close();
    if (index === steps.length - 2) await CLEAR.patchPrefs({ onboarded: true });
    index++;
    show();
  });

  show();
})();
