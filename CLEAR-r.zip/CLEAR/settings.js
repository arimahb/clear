/**
 * settings.js
 * Full settings page: all preference sections, paused sites, backend address,
 * and reset. Changes are saved immediately.
 */
(async function () {
  const $ = (id) => document.getElementById(id);
  const h = CLEAR.h;
  let prefs = await CLEAR.loadPrefs();

  function flashSaved() {
    const s = $('saved');
    s.classList.add('show');
    setTimeout(() => s.classList.remove('show'), 1200);
  }

  const form = CLEAR.form.create(prefs, async (patch) => {
    prefs = await CLEAR.patchPrefs(patch);
    flashSaved();
  });
  $('formHost').append(form.sections.blur, form.sections.text, form.sections.layout, form.sections.ai);

  // ----- Paused sites -----
  function renderSites() {
    const list = $('sites');
    if (!prefs.disabledSites.length) {
      list.replaceChildren(h('li', { class: 'hint', text: 'No paused sites.' }));
      return;
    }
    list.replaceChildren(...prefs.disabledSites.map((site) => {
      const btn = h('button', { class: 'btn', type: 'button', text: 'Resume', 'aria-label': `Resume CLEAR on ${site}` });
      btn.addEventListener('click', async () => {
        prefs = await CLEAR.patchPrefs({ disabledSites: prefs.disabledSites.filter((s) => s !== site) });
        renderSites();
        flashSaved();
      });
      return h('li', {}, h('span', { text: site }), btn);
    }));
  }

  // ----- Backend address -----
  $('backendUrl').value = prefs.backendUrl;

  function status(id, msg, ok) {
    const el = $(id);
    el.textContent = msg;
    el.className = 'status-line ' + (ok ? 'ok' : 'bad');
  }

  /** Returns a clean http(s) URL string or null. */
  function validUrl(value) {
    try {
      const u = new URL(value.trim());
      return /^https?:$/.test(u.protocol) ? u.origin + u.pathname.replace(/\/+$/, '') : null;
    } catch (err) {
      return null;
    }
  }

  $('saveUrl').addEventListener('click', async () => {
    const url = validUrl($('backendUrl').value);
    if (!url) return status('urlStatus', 'Enter a full address such as http://127.0.0.1:5001', false);
    prefs = await CLEAR.patchPrefs({ backendUrl: url });
    $('backendUrl').value = url;
    status('urlStatus', 'Saved.', true);
  });

  $('testUrl').addEventListener('click', async () => {
    const url = validUrl($('backendUrl').value);
    if (!url) return status('urlStatus', 'Enter a full address such as http://127.0.0.1:5001', false);
    prefs = await CLEAR.patchPrefs({ backendUrl: url });
    status('urlStatus', 'Testing…', true);
    const res = await CLEAR.api('health');
    if (!res.ok) return status('urlStatus', res.error, false);
    const d = res.data || {};
    status('urlStatus', d.openai_configured ? `Connected. Model: ${d.model}.` : 'Connected, but OPENAI_API_KEY is not set on the backend.', !!d.openai_configured);
  });

  // ----- Start over -----
  $('setup').addEventListener('click', () => (location.href = 'onboarding.html'));
  let confirming = false;
  $('reset').addEventListener('click', async () => {
    const btn = $('reset');
    if (!confirming) {
      confirming = true;
      btn.textContent = 'Click again to confirm';
      setTimeout(() => {
        confirming = false;
        btn.textContent = 'Reset all preferences';
      }, 4000);
      return;
    }
    confirming = false;
    btn.textContent = 'Reset all preferences';
    prefs = await CLEAR.resetPrefs();
    form.refresh(prefs);
    $('backendUrl').value = prefs.backendUrl;
    renderSites();
    status('resetStatus', 'Preferences were reset to the defaults.', true);
  });

  // Keep the page in sync when the popup changes something.
  chrome.storage.onChanged.addListener(async (changes, area) => {
    if (area !== 'sync' || !changes.prefs) return;
    prefs = CLEAR.merge(CLEAR.DEFAULTS, changes.prefs.newValue);
    form.refresh(prefs);
    renderSites();
  });

  renderSites();
})();
