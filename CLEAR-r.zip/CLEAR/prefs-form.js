/**
 * prefs-form.js
 * Builds the preference sections (blur, text, layout, AI) used by both the
 * onboarding wizard and the settings page, so the two always match.
 *
 *   const form = CLEAR.form.create(prefs, (patch) => save(patch));
 *   form.sections.blur   -> HTMLElement
 *   form.refresh(prefs)  -> update controls after storage changes
 */
(function () {
  const CLEAR = (globalThis.CLEAR = globalThis.CLEAR || {});
  const h = CLEAR.h;

  const ALL_TYPES = { images: true, videos: true, ads: true, comments: true, related: true, sidebars: true, popups: true };

  function create(initial, onPatch) {
    let prefs = initial;
    const bindings = []; // { sync: () => void }

    /** Apply a change locally and tell the page to persist it. */
    function commit(patch) {
      prefs = CLEAR.merge(prefs, mergePatch(prefs, patch));
      onPatch(patch);
      refresh(prefs);
    }

    function mergePatch(base, patch) {
      const out = { ...base };
      for (const k of Object.keys(patch)) {
        out[k] = patch[k] && typeof patch[k] === 'object' && !Array.isArray(patch[k]) ? { ...base[k], ...patch[k] } : patch[k];
      }
      return out;
    }

    // ----- Field builders -----

    function check(path, label, hint) {
      const input = h('input', { type: 'checkbox' });
      input.addEventListener('change', () => commit(CLEAR.pathPatch(path, input.checked)));
      bindings.push({ sync: () => (input.checked = !!CLEAR.getPath(prefs, path)), input });
      return h('label', { class: 'opt' }, input,
        h('span', {}, h('span', { class: 'opt-label', text: label }), hint ? h('span', { class: 'opt-hint', text: hint }) : null));
    }

    function select(path, label, options) {
      const sel = h('select', {}, options.map(([v, l]) => h('option', { value: v, text: l })));
      sel.addEventListener('change', () => commit(CLEAR.pathPatch(path, sel.value)));
      bindings.push({ sync: () => (sel.value = CLEAR.getPath(prefs, path)), input: sel });
      return h('label', { class: 'field' }, h('span', { text: label }), sel);
    }

    /** Radio group whose value is computed by `get` and stored by `set`. */
    function radios(name, options, get, set) {
      const wrap = h('div', { class: 'radios', role: 'radiogroup' });
      const inputs = options.map(([value, label, hint]) => {
        const input = h('input', { type: 'radio', name, value });
        input.addEventListener('change', () => input.checked && set(value));
        wrap.append(h('label', { class: 'opt' }, input,
          h('span', {}, h('span', { class: 'opt-label', text: label }), hint ? h('span', { class: 'opt-hint', text: hint }) : null)));
        return input;
      });
      bindings.push({ sync: () => inputs.forEach((i) => (i.checked = i.value === get())) });
      return wrap;
    }

    /** Shows whether Google's built-in AI works here, with a button to download it. */
    function chromeAiStatus() {
      const line = h('p', { class: 'status-line', role: 'status' });
      const btn = h('button', { class: 'btn', type: 'button', text: 'Set up Google\u2019s AI now' });
      btn.hidden = true;
      const box = h('div', { class: 'inline ai-status' }, line, btn);
      const MSG = {
        available: ['Google\u2019s built-in AI is ready on this computer.', true],
        downloadable: ['Google\u2019s built-in AI works here. Chrome downloads it once (about 2\u20134 GB); it starts the first time you simplify, or press the button.', true],
        downloading: ['Chrome is downloading Google\u2019s built-in AI\u2026', true],
        unavailable: ['This computer can\u2019t run Google\u2019s built-in AI (it needs about 22 GB free disk space and 16 GB RAM or a 4 GB graphics card). CLEAR will use the online assistant.', false],
        unsupported: ['This Chrome has no built-in AI. Update Chrome to the latest version. Until then CLEAR uses the online assistant.', false]
      };
      async function check() {
        if (!CLEAR.chromeAI) return;
        const s = await CLEAR.chromeAI.status();
        const [msg, ok] = MSG[s] || MSG.unavailable;
        line.textContent = msg;
        line.className = 'status-line ' + (ok ? 'ok' : 'bad');
        btn.hidden = s !== 'downloadable';
      }
      btn.addEventListener('click', async () => {
        btn.disabled = true;
        line.textContent = 'Starting the download\u2026';
        const res = await CLEAR.chromeAI.run({ mode: 'plain', text: 'Hello.' }, (m) => (line.textContent = m));
        btn.disabled = false;
        if (!res.ok) {
          line.textContent = res.error;
          line.className = 'status-line bad';
        } else check();
      });
      bindings.push({ sync: () => (box.hidden = prefs.ai.provider !== 'chrome') });
      check();
      return box;
    }

    const section = (id, title, intro, ...kids) =>
      h('section', { class: 'sect', id: `sect-${id}` }, h('h2', { text: title }), intro ? h('p', { class: 'hint', text: intro }) : null, ...kids);

    // ----- Sections -----

    const blurChoice = radios(
      'blurChoice',
      [
        ['all', 'Blur all webpage content', 'Every section is frosted until you wipe it clear (press and drag). Navigation, links and forms outside sections stay usable.'],
        ['distractions', 'Keep main content visible, blur distractions', 'Ads, comments, recommendations, sidebars and pop-ups are frosted until you wipe them clear.'],
        ['none', 'Do not blur anything', 'You can still turn Smart Blur on later.']
      ],
      () => (prefs.smartBlur ? prefs.blurMode : 'none'),
      (v) => {
        if (v === 'none') commit({ smartBlur: false });
        else commit({ smartBlur: true, blurMode: v, ...(v === 'all' ? { blurTypes: ALL_TYPES } : {}) });
      }
    );

    const typesBox = h('fieldset', { class: 'group' },
      h('legend', { text: 'Which kinds of content can be blurred' }),
      check('blurTypes.ads', 'Advertisements and sponsored content'),
      check('blurTypes.related', 'Recommended and related content'),
      check('blurTypes.comments', 'Comment sections'),
      check('blurTypes.sidebars', 'Sidebars'),
      check('blurTypes.popups', 'Pop-ups, banners and promotions'),
      check('blurTypes.images', 'Images'),
      check('blurTypes.videos', 'Videos')
    );
    const revealBox = h('fieldset', { class: 'group' },
      h('legend', { text: 'How to reveal a section' }),
      select('revealStyle', 'Reveal style', CLEAR.OPTIONS.revealStyle),
      h('p', { class: 'hint', text: 'Wipe: hold the mouse button down and drag across a section. Keyboard: Tab to it and press Enter. \u201CReveal all\u201D clears everything.' })
    );
    const labelsBox = h('fieldset', { class: 'group' },
      h('legend', { text: 'Labels on blurred sections' }),
      check('showLabels', 'Show a short label', 'Built from facts on the page, such as an image\u2019s alt text or a heading.'),
      check('aiLabels', 'Describe sections with AI (optional)',
        'Works with Google\u2019s built-in AI (free, on your computer) or your own backend; not with the online assistant, where each label would use up credits. Never used on pages with a password field.')
    );
    bindings.push({
      sync: () => {
        typesBox.disabled = !prefs.smartBlur;
        revealBox.disabled = !prefs.smartBlur;
        labelsBox.disabled = !prefs.smartBlur;
      }
    });

    const blur = section('blur', 'Blurring', 'Choose how much of a page is frosted. Press and drag across a frosted section to wipe it clear.', blurChoice, revealBox, typesBox, labelsBox);

    const text = section('text', 'Text', 'Pick as many as you like.',
      h('fieldset', { class: 'group' },
        h('legend', { text: 'Wording' }),
        radios('textMode', [
          ['standard', 'Standard text', 'Leave the page\u2019s wording as it is.'],
          ['simplified', 'Simplified text', 'Adds a \u201CSimplify page text\u201D button that rewrites the first paragraphs of the main content with AI. You can switch back to the original.']
        ], () => prefs.textMode, (v) => commit({ textMode: v }))),
      h('fieldset', { class: 'group' },
        h('legend', { text: 'Appearance' }),
        check('largerText', 'Larger text'),
        check('spacing', 'More space between lines and paragraphs'),
        select('font', 'Easy-to-read font', CLEAR.OPTIONS.font))
    );

    const layout = section('layout', 'Page layout', 'Make busy pages calmer.',
      h('fieldset', { class: 'group' },
        h('legend', { text: 'Clutter' }),
        check('layout.clutter', 'Reduce visual clutter', 'Hides share bars, chat widgets and \u201Cback to top\u201D buttons.'),
        check('layout.simple', 'Use a cleaner, simplified layout', 'Calm background, narrower reading column, and hides ads and sidebars.'),
        check('layout.motion', 'Reduce distracting animations', 'Slows CSS animations. Animated GIFs cannot be stopped.'),
        check('layout.muteVideos', 'Mute videos', 'Every video plays muted, including embedded players and video ads. Unmute any video with its own sound button and CLEAR leaves it alone. Videos behind frost are also paused.')),
      h('fieldset', { class: 'group' },
        h('legend', { text: 'Specific content' }),
        select('layout.ads', 'Advertisements', CLEAR.OPTIONS.layoutAction),
        select('layout.related', 'Recommended content', CLEAR.OPTIONS.layoutAction),
        select('layout.comments', 'Comment sections', CLEAR.OPTIONS.layoutAction))
    );

    const ai = section('ai', 'AI help', 'Used when you highlight text and choose \u201CSimplify with CLEAR\u201D.',
      check('ai.enabled', 'Turn on AI text simplification'),
      select('ai.provider', 'AI service', CLEAR.OPTIONS.provider),
      h('p', { class: 'hint', text: 'Google\u2019s built-in AI (Gemini Nano) runs inside Chrome on your computer: free, no account, no limits, and your text never leaves your computer. It needs a recent Chrome and a fairly powerful computer; if yours can\u2019t run it, CLEAR uses the online assistant instead.' }),
      chromeAiStatus(),
      h('fieldset', { class: 'group' },
        h('legend', { text: 'What should the AI do?' }),
        check('ai.explainWords', 'Explain unfamiliar words'),
        check('ai.simplifySentences', 'Simplify complicated sentences'),
        check('ai.summarize', 'Summarize long paragraphs'),
        check('ai.bullets', 'Turn complicated information into bullet points'),
        check('ai.steps', 'Break instructions into smaller steps')),
      h('fieldset', { class: 'group' },
        h('legend', { text: 'Style' }),
        select('ai.level', 'Simplification level', CLEAR.OPTIONS.level),
        select('ai.format', 'Output format', CLEAR.OPTIONS.format))
    );

    /** Update every control from `p`. */
    function refresh(p) {
      prefs = p;
      for (const b of bindings) b.sync();
    }
    refresh(prefs);

    return { sections: { blur, text, layout, ai }, refresh };
  }

  CLEAR.form = { create };
})();
