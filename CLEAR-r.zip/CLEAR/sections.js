/**
 * sections.js
 * Decides which parts of a webpage count as a "section" (main content, ad,
 * comments, ...) using tag names, ARIA roles and class/id names. Pure
 * detection: nothing here changes the page.
 */
(function () {
  const CLEAR = (globalThis.CLEAR = globalThis.CLEAR || {});

  const NAMES = {
    main: 'Main content',
    ads: 'Advertisement',
    images: 'Image',
    videos: 'Video',
    comments: 'Comments',
    related: 'Related content',
    sidebars: 'Sidebar',
    popups: 'Pop-up',
    clutter: 'Extra widget'
  };

  /** Everything worth testing. Kept broad; classify() does the real filtering. */
  const SELECTOR =
    'main,article,aside,img,picture,video,iframe,embed,dialog,ins,[role],[aria-modal],[id],[class],[data-ad-slot],[data-ad-client]';

  // Whole class/id tokens (not substrings), so "header" never matches "ad".
  const AD_TOKENS = new Set([
    'ad', 'ads', 'advert', 'advertisement', 'advertising', 'adslot', 'ad-slot', 'ad-container',
    'ad-banner', 'ad-wrapper', 'ad-unit', 'ad-box', 'adbox', 'adsbygoogle', 'sponsored',
    'sponsored-content', 'sponsor', 'promoted', 'banner-ad', 'dfp-ad', 'google-ad', 'google-ads'
  ]);
  const AD_PREFIX = /^(google_ads|div-gpt-ad|ad-slot-)/;
  const COMMENTS_RE = /^(comments?-?(section|area|list|wrapper|container|block|thread|box)|comments|commentlist|comment-respond|disqus|disqus_thread|fb-comments)$/;
  const RELATED_RE = /^(related|recommend|suggested|trending|more-stor|more-from|you-may|youmay|taboola|outbrain|read-next|also-read)/;
  const POPUP_RE = /^(modal|popup|pop-up|overlay|newsletter|newsletter-signup|newsletter-popup|cookie-banner|cookie-consent|cookie-notice|cookie-bar|gdpr|subscribe-modal|paywall|interstitial|lightbox)$|^(modal|popup)[-_]/;
  const SIDEBAR_RE = /^(sidebar|side-bar|widget-area|right-rail|left-rail)$|^sidebar[-_]/;
  const CLUTTER_RE = /^(social-?share|share-?(buttons|bar|tools)|sharedaddy|addtoany|chat-?widget|intercom|drift|back-?to-?top|scroll-?to-?top)/;

  const AD_FRAME_RE = /(doubleclick|googlesyndication|adservice|amazon-adsystem|adnxs|criteo|pubmatic|rubiconproject|taboola|outbrain)/i;
  // Includes the players news and shopping sites use for pop-up / floating videos.
  const VIDEO_FRAME_RE = /(youtube\.com|youtube-nocookie\.com|youtu\.be|vimeo\.com|dailymotion\.com|twitch\.tv|wistia|brightcove|jwplayer|jwplatform|connatix|primis|anyclip|ex\.co|vidazoo|aniview|springserve|teads|minute\.ly|brid\.tv|glomex|sendtonews|kaltura|ooyala|vidible|playbuzz|\/embed\/)/i;

  function tokensOf(el) {
    const cls = el.getAttribute('class') || '';
    const out = cls ? cls.toLowerCase().split(/\s+/) : [];
    if (el.id) out.push(String(el.id).toLowerCase());
    return out;
  }

  /** Cheap, layout-free guess based on tag, role and names. */
  function quickCategory(el) {
    const tag = el.tagName;
    const role = el.getAttribute('role');

    if (tag === 'IMG') return el.parentElement && el.parentElement.tagName === 'PICTURE' ? null : 'images';
    if (tag === 'PICTURE') return 'images';
    if (tag === 'VIDEO') return 'videos';
    if (tag === 'IFRAME' || tag === 'EMBED') {
      const src = el.getAttribute('src') || '';
      if (AD_FRAME_RE.test(src)) return 'ads';
      if (VIDEO_FRAME_RE.test(src)) return 'videos';
      // Unknown players usually still ask for full screen.
      if (el.hasAttribute('allowfullscreen') || /\bfullscreen\b/.test(el.getAttribute('allow') || '')) return 'videos';
    }
    if (tag === 'DIALOG' || role === 'dialog' || role === 'alertdialog' || el.getAttribute('aria-modal') === 'true') return 'popups';
    if (el.hasAttribute('data-ad-slot') || el.hasAttribute('data-ad-client')) return 'ads';

    for (const t of tokensOf(el)) {
      if (AD_TOKENS.has(t) || AD_PREFIX.test(t)) return 'ads';
      if (COMMENTS_RE.test(t)) return 'comments';
      if (RELATED_RE.test(t)) return 'related';
      if (POPUP_RE.test(t)) return 'popups';
      if (SIDEBAR_RE.test(t)) return 'sidebars';
      if (CLUTTER_RE.test(t)) return 'clutter';
    }

    if (tag === 'ASIDE' || role === 'complementary') return 'sidebars';
    if (tag === 'MAIN' || role === 'main' || tag === 'ARTICLE') return 'main';
    return null;
  }

  /**
   * Returns the category of `el`, or null when it is not a section worth
   * handling. Layout is measured only after a cheap name match succeeds.
   */
  function classify(el) {
    if (el === document.body || el === document.documentElement || el.id === 'clear-overlay-host') return null;
    const cat = quickCategory(el);
    if (!cat) return null;

    // Never touch site navigation or search.
    if (el.closest('nav,[role="navigation"],[role="search"]')) return null;
    // Individual comment/related/sidebar cards are covered by their parent section.
    if (cat === 'main' && el.closest('[data-clear-cat="comments"],[data-clear-cat="related"],[data-clear-cat="sidebars"]')) return null;
    // A wrapper that holds the page's main content is not a distraction section.
    if (!['main', 'images', 'videos', 'popups'].includes(cat) && el.querySelector('main,[role="main"],h1')) return null;

    const r = el.getBoundingClientRect();
    if (cat === 'images') return r.width >= 80 && r.height >= 80 ? cat : null;
    if (cat === 'videos') return r.width >= 80 && r.height >= 60 ? cat : null;
    if (r.width < 60 || r.height < 30) return null;

    // Class-named pop-ups only count when they float above the page.
    if (cat === 'popups' && !el.matches('dialog,[role="dialog"],[role="alertdialog"],[aria-modal="true"]')) {
      if (getComputedStyle(el).position !== 'fixed') return null;
    }
    return cat;
  }

  /**
   * Fallback for pages without <main>/<article>: pick the element that
   * directly holds the most paragraph text. Returns null if nothing clear.
   */
  function fallbackMain() {
    const totals = new Map();
    for (const p of document.querySelectorAll('p')) {
      const len = (p.textContent || '').trim().length;
      if (len < 80 || p.closest('nav,aside,footer,header,[data-clear-cat]')) continue;
      totals.set(p.parentElement, (totals.get(p.parentElement) || 0) + len);
    }
    let best = null;
    let max = 0;
    for (const [el, len] of totals) {
      if (len > max) {
        max = len;
        best = el;
      }
    }
    return max >= 300 && best && best !== document.body ? best : null;
  }

  /** Element that contains `node` in the main document (climbs out of shadow roots). */
  function lightHost(node) {
    let n = node;
    while (n && n.getRootNode && n.getRootNode() !== document) {
      const root = n.getRootNode();
      n = root && root.host;
    }
    return n || null;
  }

  /** Parent element, stepping out of a shadow root to its host. */
  function parentOf(n) {
    if (n.parentElement) return n.parentElement;
    const root = n.getRootNode && n.getRootNode();
    return root && root.host ? root.host : null;
  }

  /**
   * If `media` (a <video> or a video-player <iframe>) sits in a small box that
   * floats over the page (position: fixed), as pop-up and "picture in picture"
   * players do, return that box in the main document. Otherwise null.
   * The box must be mostly video, so fixed headers and side panels never count.
   */
  function floatingContainer(media) {
    const vw = window.innerWidth;
    const vh = window.innerHeight;
    const mr = media.getBoundingClientRect();
    if (mr.width < 160 || mr.height < 90) return null; // hidden or tiny player
    let n = media;
    for (let depth = 0; n && n !== document.body && n !== document.documentElement && depth < 10; depth++) {
      if (getComputedStyle(n).position === 'fixed') {
        const r = n.getBoundingClientRect();
        const small = r.width <= vw * 0.6 && r.height <= vh * 0.7;
        const mostlyVideo = r.width * r.height <= mr.width * mr.height * 2.5;
        return small && mostlyVideo ? lightHost(n) : null;
      }
      n = parentOf(n);
    }
    return null;
  }

  /**
   * All <video> and <iframe> elements under `root`. With `deep`, also looks
   * inside open shadow roots (web-component players), which querySelectorAll
   * cannot see.
   */
  function mediaIn(root, deep) {
    const out = [];
    if (root.matches && root.matches('video,iframe')) out.push(root);
    out.push(...root.querySelectorAll('video,iframe'));
    if (deep) {
      const walk = (scope, level) => {
        if (level > 3) return;
        for (const el of scope.querySelectorAll('*')) {
          if (!el.shadowRoot) continue;
          out.push(...el.shadowRoot.querySelectorAll('video,iframe'));
          walk(el.shadowRoot, level + 1);
        }
      };
      walk(root, 0);
    }
    return out;
  }

  const clip = (s, n) => {
    s = (s || '').replace(/\s+/g, ' ').trim();
    return s.length > n ? s.slice(0, n - 1) + '…' : s;
  };

  /**
   * Label built only from facts on the page (alt text, titles, counts).
   * Nothing is guessed. The AI label, when enabled, replaces this.
   */
  function baseLabel(el, cat) {
    const name = NAMES[cat] || 'Section';
    if (cat === 'main') {
      const heading = el.querySelector('h1,h2');
      const title = clip(heading ? heading.textContent : document.title, 70);
      return title ? `${name}: ${title}` : name;
    }
    if (cat === 'images') {
      const alt = clip(el.getAttribute('alt') || (el.querySelector('img') || {}).alt, 70);
      return alt ? `${name}: ${alt}` : name;
    }
    if (cat === 'videos') {
      const title = clip(el.getAttribute('title'), 70);
      return title ? `${name}: ${title}` : name;
    }
    if (cat === 'comments') {
      const n = el.querySelectorAll('.comment,li[id^="comment"],article[id^="comment"],[itemprop="comment"]').length;
      return n ? `${name}: ${n} shown` : name;
    }
    if (cat === 'related' || cat === 'sidebars') {
      const n = el.querySelectorAll('a[href]').length;
      return n ? `${name}: ${n} link${n === 1 ? '' : 's'}` : name;
    }
    return name;
  }

    /** True for <video> and for iframes that look like video players (not ads). */
  function isVideoPlayer(m) {
    return m.tagName === 'VIDEO' || (m.tagName === 'IFRAME' && quickCategory(m) === 'videos');
  }

  CLEAR.sections = { NAMES, SELECTOR, classify, fallbackMain, baseLabel, floatingContainer, mediaIn, lightHost, isVideoPlayer };
})();
