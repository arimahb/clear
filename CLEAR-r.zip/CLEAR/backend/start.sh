#!/usr/bin/env bash
# Sets up and starts the CLEAR backend (Mac / Linux).
cd "$(dirname "$0")" || exit 1
[ -d .venv ] || python3 -m venv .venv || exit 1
source .venv/bin/activate
pip install -q -r requirements.txt || exit 1
if [ ! -f .env ]; then
  cp .env.example .env
  echo "Created backend/.env. Open it, paste your OPENAI_API_KEY after the = sign, save, then run this again."
  exit 1
fi
python app.py
