@echo off
cd /d "%~dp0"
if not exist .venv ( py -m venv .venv || python -m venv .venv )
call .venv\Scripts\activate.bat
pip install -q -r requirements.txt
if not exist .env (
  copy .env.example .env >nul
  echo Created backend\.env. Open it, paste your OPENAI_API_KEY after the = sign, save, then run this again.
  pause
  exit /b 1
)
python app.py
pause
