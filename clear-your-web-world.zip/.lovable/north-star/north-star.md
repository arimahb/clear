<!-- Lovable wrote this file; it is not part of your task. Keep it, and ask the user before deleting or reverting it. -->

# North star

People browse the web comfortably and understand what they read.

## Metric

Explanations returned to readers each week
