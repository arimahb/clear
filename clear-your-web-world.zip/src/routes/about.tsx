import { createFileRoute, Link } from "@tanstack/react-router";
import { Button } from "@/components/ui/button";
import { PageHero, SiteShell } from "@/components/clear/SiteChrome";

export const Route = createFileRoute("/about")({
  head: () => ({
    meta: [
      { title: "About — CLEAR" },
      { name: "description", content: "Why CLEAR exists: a browser companion that adapts the internet to the individual." },
      { property: "og:title", content: "About CLEAR" },
      { property: "og:description", content: "Our mission: clarity, comfort and control for everyone online." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: AboutPage,
});

const PRINCIPLES = [
  ["Clarity", "Plain language, predictable layouts, and no surprises."],
  ["Comfort", "Soft visuals and calm motion, with you deciding what's too much."],
  ["Control", "Every setting is yours to change, and nothing happens without you choosing it."],
  ["Honesty", "CLEAR keeps the original meaning, never invents information, and flags what is unclear."],
];

function AboutPage() {
  return (
    <SiteShell>
      <PageHero eyebrow="About" title="Like stepping into a quiet room.">
        CLEAR started with a simple idea: the internet should adapt to you, not the other way round. It's for anyone who wants more control over their screen and an easier way to understand what they read.
      </PageHero>
      <div className="mx-auto max-w-5xl space-y-8 px-6 pb-24">
        <section className="glass rounded-[2rem] p-8 md:p-12">
          <h2 className="font-display text-2xl font-semibold text-primary">Two problems, two features</h2>
          <div className="mt-6 grid gap-8 md:grid-cols-2">
            <div>
              <h3 className="font-semibold text-primary">Pages you can't control: Customize</h3>
              <p className="mt-2 text-muted-foreground">Ads, autoplay, movement and clutter get in the way. CLEAR lets you decide exactly what to blur, hide or calm.</p>
            </div>
            <div>
              <h3 className="font-semibold text-primary">Text that's hard to follow: Simplify</h3>
              <p className="mt-2 text-muted-foreground">Jargon and dense writing slow everyone down. CLEAR explains it the way you learn best, without changing the meaning.</p>
            </div>
          </div>
        </section>
        <section className="grid gap-5 md:grid-cols-2">
          {PRINCIPLES.map(([t, d]) => (
            <div key={t} className="glass rounded-3xl p-7">
              <h3 className="font-display text-xl font-semibold text-primary">{t}</h3>
              <p className="mt-2 text-muted-foreground">{d}</p>
            </div>
          ))}
        </section>
        <section className="glass rounded-[2rem] p-8 text-center md:p-12">
          <p className="text-muted-foreground">CLEAR is a hackathon prototype built by a small team. The website and demo dashboard are here today; the Chrome extension is an early prototype that isn't on the Chrome Web Store yet.</p>
          <Button asChild className="mt-6 rounded-full px-6"><Link to="/download">Try CLEAR</Link></Button>
        </section>
      </div>
    </SiteShell>
  );
}
