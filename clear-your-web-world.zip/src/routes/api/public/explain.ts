import { createFileRoute } from "@tanstack/react-router";

import { explainRequestSchema } from "@/lib/explain";

// Public on purpose: the CLEAR browser extension calls this from any webpage.
// It is read-only, validates and bounds input, and returns no private data.
const CORS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type",
  "Access-Control-Expose-Headers": "Server-Timing, X-Lovable-AIG-Run-ID",
  "Access-Control-Max-Age": "86400",
};

function json(body: unknown, status = 200, extra: Record<string, string> = {}) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { "Content-Type": "application/json", ...CORS, ...extra },
  });
}

export const Route = createFileRoute("/api/public/explain")({
  server: {
    handlers: {
      OPTIONS: async () => new Response(null, { status: 204, headers: CORS }),
      GET: async () => json({ ok: true, service: "clear-explain" }),
      POST: async ({ request }) => {
        let body: unknown;
        try {
          body = await request.json();
        } catch {
          return json({ error: "Invalid request body." }, 400);
        }
        const parsed = explainRequestSchema.safeParse(body);
        if (!parsed.success) {
          return json({ error: "Please select between 2 and 4000 characters of text." }, 400);
        }
        const { runExplain, streamExplain, ExplainError } = await import("@/lib/ai/explain.server");
        const wantsStream = !!(body && typeof body === "object" && (body as { stream?: unknown }).stream === true);
        try {
          if (wantsStream) {
            const { stream, ttft, runId } = await streamExplain(parsed.data, request.signal);
            return new Response(stream, {
              status: 200,
              headers: {
                "Content-Type": "text/plain; charset=utf-8",
                "Cache-Control": "no-store",
                "Server-Timing": `ai-first-token;dur=${ttft}`,
                ...CORS,
                ...(runId ? { "X-Lovable-AIG-Run-ID": runId } : {}),
              },
            });
          }
          const { result, runId, ms } = await runExplain(parsed.data, request.signal);
          return json(result, 200, { "Server-Timing": `ai;dur=${ms}`, ...(runId ? { "X-Lovable-AIG-Run-ID": runId } : {}) });
        } catch (error) {
          if (error instanceof ExplainError) return json({ error: error.message }, error.status);
          return json({ error: "Something went wrong." }, 500);
        }
      },
    },
  },
});
