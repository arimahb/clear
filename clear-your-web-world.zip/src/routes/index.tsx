import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowRight, Check, SlidersHorizontal, Sparkles } from "lucide-react";

import { Button } from "@/components/ui/button";
import { FEATURES } from "@/components/clear/features";
import { HeroMockup } from "@/components/clear/HeroMockup";
import { SiteShell } from "@/components/clear/SiteChrome";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "CLEAR — The internet, your way" },
      { name: "description", content: "A browser companion that adapts the internet to you: customize how pages look and simplify what they say." },
      { property: "og:title", content: "CLEAR — The internet, your way" },
      { property: "og:description", content: "Customize your digital environment and understand information in a way that works for you." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Index,
});

function Index() {
  return (
    <SiteShell>
      <section className="mx-auto grid max-w-6xl items-center gap-14 px-6 pb-24 pt-16 lg:grid-cols-[1.05fr_1fr] lg:pt-24">
        <div>
          <p className="glass mb-6 inline-flex rounded-full px-4 py-1.5 text-sm text-muted-foreground">A browser companion that adapts the internet to you</p>
          <h1 className="font-display text-5xl font-semibold leading-[1.05] text-primary md:text-7xl">The internet, your way.</h1>
          <p className="mt-6 max-w-xl text-lg text-muted-foreground">
            Take control of your digital environment and understand information in a way that works for you. CLEAR makes the internet more customizable, accessible, and easier to navigate.
          </p>
          <div className="mt-9 flex flex-wrap gap-3">
            <Button asChild size="lg" className="rounded-full px-7 shadow-float">
              <Link to="/download">Get CLEAR for Chrome</Link>
            </Button>
            <Button asChild size="lg" variant="outline" className="glass rounded-full px-7">
              <Link to="/features">Explore Features</Link>
            </Button>
          </div>
        </div>
        <HeroMockup />
      </section>

      <section className="mx-auto max-w-6xl px-6 py-20">
        <div className="mx-auto max-w-2xl text-center">
          <h2 className="font-display text-3xl font-semibold text-primary md:text-5xl">Two things. Done really well.</h2>
          <p className="mt-5 text-lg text-muted-foreground">Everything in CLEAR lives inside two simple buttons: Customize and Simplify.</p>
        </div>
        <div className="mt-14 grid gap-6 md:grid-cols-2">
          <div className="glass relative overflow-hidden rounded-[2rem] p-9">
            <div className="absolute -right-10 -top-10 h-40 w-40 rounded-full bg-mist-4/60 blur-2xl" />
            <span className="flex h-12 w-12 items-center justify-center rounded-2xl bg-mist-3 text-primary"><SlidersHorizontal /></span>
            <p className="mt-6 text-sm font-semibold uppercase tracking-[0.2em] text-muted-foreground">01 · Customize</p>
            <h3 className="mt-2 font-display text-2xl font-semibold text-primary">Your Internet, Your Rules.</h3>
            <p className="mt-3 text-muted-foreground">Control how webpages look, move, and present information.</p>
          </div>
          <div className="relative overflow-hidden rounded-[2rem] bg-primary p-9 text-primary-foreground shadow-float">
            <div className="absolute -bottom-12 -right-6 h-48 w-48 rounded-[2.5rem] bg-mist-1/10 blur-sm" />
            <span className="flex h-12 w-12 items-center justify-center rounded-2xl bg-mist-1/15"><Sparkles /></span>
            <p className="mt-6 text-sm font-semibold uppercase tracking-[0.2em] opacity-70">02 · Simplify</p>
            <h3 className="mt-2 font-display text-2xl font-semibold">Understand Information Your Way.</h3>
            <p className="mt-3 opacity-85">Turn complicated information into clear explanations that match the way you prefer to learn.</p>
          </div>
        </div>
      </section>

      <section className="mx-auto max-w-6xl px-6 py-20">
        <h2 className="max-w-3xl font-display text-3xl font-semibold text-primary md:text-5xl">What lives inside each one.</h2>
        <div className="mt-12 grid gap-5 md:grid-cols-2">
          {FEATURES.map((f) => (
            <Link key={f.key} to="/features" hash={f.key} className="glass group flex flex-col rounded-3xl p-6 transition hover:-translate-y-1 hover:shadow-float">
              <span className="flex h-11 w-11 items-center justify-center rounded-2xl bg-mist-3 text-primary"><f.icon className="h-5 w-5" /></span>
              <p className="mt-5 text-sm font-semibold uppercase tracking-[0.2em] text-muted-foreground">{f.num} · {f.name}</p>
              <h3 className="mt-1 font-display text-xl font-semibold text-primary">{f.title}</h3>
              <ul className="mt-4 flex-1 space-y-2 text-sm text-muted-foreground">
                {f.items.map((i) => (
                  <li key={i} className="flex gap-2"><Check className="mt-0.5 h-4 w-4 shrink-0 text-primary/60" />{i}</li>
                ))}
              </ul>
              <span className="mt-5 flex items-center gap-1 text-sm font-semibold text-primary">Learn more <ArrowRight className="h-4 w-4 transition group-hover:translate-x-1" /></span>
            </Link>
          ))}
        </div>
      </section>

      <section id="how" className="mx-auto max-w-6xl scroll-mt-28 px-6 py-20">
        <h2 className="text-center font-display text-3xl font-semibold text-primary md:text-5xl">Getting started is simple.</h2>
        <ol className="mt-14 grid gap-6 md:grid-cols-3">
          {[
            ["Download CLEAR", "Add CLEAR to Google Chrome."],
            ["Make it yours", "Pick what to blur, hide or calm, and how you like things explained."],
            ["Browse with more clarity", "Customize any page and simplify any text as you go."],
          ].map(([t, d], i) => (
            <li key={t} className="glass rounded-3xl p-7">
              <span className="font-display text-5xl font-semibold text-mist-5">0{i + 1}</span>
              <h3 className="mt-4 font-display text-xl font-semibold text-primary">{t}</h3>
              <p className="mt-2 text-muted-foreground">{d}</p>
            </li>
          ))}
        </ol>
      </section>

      <section className="px-6 pb-24 pt-10">
        <div className="glass-strong relative mx-auto max-w-5xl overflow-hidden rounded-[2.5rem] px-8 py-16 text-center">
          <div className="absolute -left-16 top-0 h-56 w-56 rounded-full bg-mist-4/60 blur-3xl" />
          <div className="absolute -right-10 bottom-0 h-56 w-72 rounded-[3rem] bg-mist-3/70 blur-2xl" />
          <h2 className="relative font-display text-3xl font-semibold text-primary md:text-5xl">The internet, your way, starts here.</h2>
          <p className="relative mx-auto mt-5 max-w-xl text-lg text-muted-foreground">Customize what you see. Simplify what you read.</p>
          <Button asChild size="lg" className="relative mt-8 rounded-full px-8 shadow-float">
            <Link to="/download">Get CLEAR for Chrome</Link>
          </Button>
        </div>
      </section>
    </SiteShell>
  );
}
