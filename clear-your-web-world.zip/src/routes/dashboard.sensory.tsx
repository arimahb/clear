import { createFileRoute } from "@tanstack/react-router";
import { Move, Palette, PanelsTopLeft, Play, RotateCcw, Save } from "lucide-react";
import { useEffect, useState } from "react";
import { toast } from "sonner";

import { Button } from "@/components/ui/button";
import { Slider } from "@/components/ui/slider";
import { DashHeader, Panel, ToggleRow } from "@/components/clear/dash";
import { DEFAULT_SENSORY, getPrefs, setPrefs, usePrefs, type SensoryPrefs } from "@/lib/prefs";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/dashboard/sensory")({
  head: () => ({
    meta: [
      { title: "Colors & Motion — CLEAR Customize" },
      { name: "description", content: "Choose how the internet looks and behaves: colours, brightness, motion and layout." },
      { property: "og:title", content: "CLEAR colors and motion" },
      { property: "og:description", content: "Make your browsing environment yours." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: SensoryPage,
});

function Preview({ s }: { s: SensoryPrefs }) {
  const filter = [s.brightness !== 100 && `brightness(${s.brightness / 100})`, s.softContrast && "contrast(.85)", s.reduceColors && "saturate(.45)"].filter(Boolean).join(" ") || undefined;
  const still = s.reduceAnimations || s.reduceMovement;
  return (
    <div className="overflow-hidden rounded-2xl border border-mist-4 bg-mist-1" style={{ filter }}>
      <div className="flex items-center gap-1.5 border-b border-mist-4 px-3 py-2 text-xs text-muted-foreground">
        <span className="h-2 w-2 rounded-full bg-mist-5" /><span className="h-2 w-2 rounded-full bg-mist-4" /> sample-site.example
      </div>
      <div className={cn("grid gap-3 p-4", !s.simplifyLayout && "grid-cols-[1fr_90px]")}>
        <div className={cn(s.extraSpacing ? "space-y-4" : "space-y-2", s.readableText && "text-base leading-relaxed")}>
          {!s.reduceClutter && <div className={cn("rounded-lg bg-destructive/80 p-2 text-center text-xs font-bold text-destructive-foreground", !still && "animate-pulse")}>SALE! 70% OFF TODAY ONLY</div>}
          <div className="relative flex h-24 items-center justify-center overflow-hidden rounded-lg bg-gradient-to-r from-chart-3 via-destructive/60 to-chart-1">
            <span className={cn("text-3xl", !s.pauseVideos && "animate-bounce")}>🎬</span>
            <span className="absolute bottom-1 right-2 flex items-center gap-1 rounded bg-mist-1/80 px-1.5 text-[10px]">
              <Play className="h-2.5 w-2.5" /> {s.pauseVideos ? "Paused" : "Autoplaying"}
            </span>
          </div>
          <p className={cn("text-sm", s.readableText && "text-base")}>Sample article text shows how reading feels with your settings.</p>
        </div>
        {!s.simplifyLayout && (
          <div className="space-y-2">
            {!s.reduceClutter && <div className={cn("h-16 rounded-lg bg-chart-2", !still && "animate-pulse")} />}
            <div className={cn("h-10 rounded-lg bg-mist-3", !s.disableTransitions && "transition hover:scale-105")} />
          </div>
        )}
      </div>
    </div>
  );
}

function SensoryPage() {
  const saved = usePrefs().sensory;
  const [s, setS] = useState<SensoryPrefs>(saved);
  useEffect(() => setS(getPrefs().sensory), []);
  const dirty = JSON.stringify(s) !== JSON.stringify(saved);
  const set = <K extends keyof SensoryPrefs>(k: K, v: SensoryPrefs[K]) => setS((x) => ({ ...x, [k]: v }));

  const save = () => {
    setPrefs((p) => ({ ...p, sensory: s }));
    toast.success("Color and motion settings saved.");
  };
  const reset = () => {
    setS(DEFAULT_SENSORY);
    setPrefs((p) => ({ ...p, sensory: DEFAULT_SENSORY }));
    toast("Settings reset to defaults.");
  };

  return (
    <div>
      <DashHeader title="Make your browsing environment yours." sub="Choose how you want the internet to look and behave.">
        <div className="flex gap-2">
          <Button variant="outline" className="rounded-full bg-mist-1/60" onClick={reset}><RotateCcw /> Reset to defaults</Button>
          <Button className="rounded-full" onClick={save} disabled={!dirty}><Save /> {dirty ? "Save preferences" : "Saved"}</Button>
        </div>
      </DashHeader>
      <div className="grid gap-6 xl:grid-cols-[1fr_340px]">
        <div className="space-y-6">
          <Panel title="Visual Comfort" icon={<Palette className="h-5 w-5" />}>
            <div className="space-y-3">
              <ToggleRow label="Reduce intense colors" checked={s.reduceColors} onChange={(v) => set("reduceColors", v)} />
              <ToggleRow label="Soften high-contrast elements" checked={s.softContrast} onChange={(v) => set("softContrast", v)} />
              <div className="rounded-2xl bg-mist-1/60 px-4 py-4">
                <div className="mb-3 flex justify-between"><span className="font-medium">Visual brightness</span><span className="text-sm text-muted-foreground">{s.brightness}%</span></div>
                <Slider aria-label="Visual brightness" min={80} max={110} step={1} value={[s.brightness]} onValueChange={([v]) => set("brightness", v!)} />
              </div>
              <div className="rounded-2xl bg-mist-1/60 px-4 py-4">
                <div className="mb-3 flex justify-between"><span className="font-medium">Interface blue tone</span><span className="text-sm text-muted-foreground">{s.blueTone < 235 ? "Teal-blue" : s.blueTone > 250 ? "Periwinkle" : "Misty blue"}</span></div>
                <Slider aria-label="Interface blue tone" min={215} max={265} step={1} value={[s.blueTone]} onValueChange={([v]) => set("blueTone", v!)} />
              </div>
            </div>
          </Panel>
          <Panel title="Motion and Animation" icon={<Move className="h-5 w-5" />}>
            <div className="space-y-3">
              <ToggleRow label="Reduce animations" checked={s.reduceAnimations} onChange={(v) => set("reduceAnimations", v)} />
              <ToggleRow label="Pause autoplaying videos" checked={s.pauseVideos} onChange={(v) => set("pauseVideos", v)} />
              <ToggleRow label="Disable unnecessary transitions" checked={s.disableTransitions} onChange={(v) => set("disableTransitions", v)} />
              <ToggleRow label="Reduce distracting movement" hint="Stops the drifting background too." checked={s.reduceMovement} onChange={(v) => set("reduceMovement", v)} />
            </div>
          </Panel>
          <Panel title="Page Layout" icon={<PanelsTopLeft className="h-5 w-5" />}>
            <div className="space-y-3">
              <ToggleRow label="Simplify webpage layouts" checked={s.simplifyLayout} onChange={(v) => set("simplifyLayout", v)} />
              <ToggleRow label="Reduce visual clutter" checked={s.reduceClutter} onChange={(v) => set("reduceClutter", v)} />
              <ToggleRow label="Increase spacing between content" checked={s.extraSpacing} onChange={(v) => set("extraSpacing", v)} />
              <ToggleRow label="Make text easier to read" checked={s.readableText} onChange={(v) => set("readableText", v)} />
            </div>
          </Panel>
        </div>
        <div className="xl:sticky xl:top-10 xl:self-start">
          <Panel title="Live preview">
            <Preview s={s} />
            <p className="mt-4 text-sm text-muted-foreground">Saved settings also apply to this CLEAR app straight away. On other websites, the CLEAR extension does the same.</p>
          </Panel>
        </div>
      </div>
    </div>
  );
}
