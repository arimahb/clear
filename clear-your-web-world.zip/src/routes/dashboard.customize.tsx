import { createFileRoute, Link } from "@tanstack/react-router";
import { BookOpen, EyeOff, Eye, MousePointerClick, Pause, Pin, RotateCcw, Trash2, X } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";

import { Button } from "@/components/ui/button";
import { Panel, ToggleRow, DashHeader } from "@/components/clear/dash";
import { CUSTOMIZE_ITEMS } from "@/components/clear/customize";
import { countEnabled, DEFAULT_CUSTOMIZE, setPrefs, usePrefs, type CustomAction } from "@/lib/prefs";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/dashboard/customize")({
  head: () => ({
    meta: [
      { title: "Customize — Your Internet, Your Rules | CLEAR" },
      { name: "description", content: "Choose exactly which webpage elements CLEAR blurs, hides or calms, and click any element to customize it." },
      { property: "og:title", content: "CLEAR Customize" },
      { property: "og:description", content: "Your internet, your rules." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: CustomizePage,
});

type El = { id: string; label: string; kind: "ad" | "video" | "image" | "anim" | "popup" | "text" };
const ELEMENTS: El[] = [
  { id: "banner", label: "Flashing banner ad", kind: "ad" },
  { id: "hero", label: "Large header image", kind: "image" },
  { id: "video", label: "Autoplaying video", kind: "video" },
  { id: "ticker", label: "Scrolling news ticker", kind: "anim" },
  { id: "side", label: "Sidebar ad", kind: "ad" },
  { id: "popup", label: "Newsletter pop-up", kind: "popup" },
];
const ACTIONS: { v: CustomAction; label: string; icon: typeof Eye }[] = [
  { v: "blur", label: "Blur this", icon: Eye },
  { v: "hide", label: "Hide this", icon: EyeOff },
  { v: "still", label: "Reduce its movement", icon: Pause },
];

function CustomizePage() {
  const p = usePrefs();
  const c = p.customize;
  const [picking, setPicking] = useState(false);
  const [picked, setPicked] = useState<El | null>(null);
  const [local, setLocal] = useState<Record<string, CustomAction>>({});
  const [reading, setReading] = useState(false);
  const on = countEnabled(c);

  const ruleFor = (e: El): CustomAction | undefined => local[e.id] ?? p.rules.find((r) => r.id === e.id)?.action;
  const stateOf = (e: El): CustomAction | undefined => {
    const r = ruleFor(e);
    if (r) return r;
    if (e.kind === "ad" && c.ads) return "blur";
    if (e.kind === "popup" && c.popups) return "hide";
    if (e.kind === "image" && c.images) return "blur";
    if ((e.kind === "video" && c.autoplay) || (e.kind === "anim" && c.animations)) return "still";
    return undefined;
  };
  const apply = (a: CustomAction) => {
    if (!picked) return;
    setLocal((l) => ({ ...l, [picked.id]: a }));
    toast.success(`${ACTIONS.find((x) => x.v === a)!.label.replace(" this", "")}: ${picked.label.toLowerCase()}`);
    setPicked(null);
    setPicking(false);
  };
  const always = () => {
    if (!picked) return;
    const a = local[picked.id] ?? "blur";
    setPrefs((s) => ({ ...s, rules: [...s.rules.filter((r) => r.id !== picked.id), { id: picked.id, label: picked.label, action: a }] }));
    setLocal((l) => ({ ...l, [picked.id]: a }));
    toast.success(`Saved: always ${a === "still" ? "calm" : a} "${picked.label}"`);
    setPicked(null);
    setPicking(false);
  };

  const box = (e: El, className: string, children: React.ReactNode) => {
    const st = stateOf(e);
    if (st === "hide" || (reading && e.kind !== "text")) return null;
    return (
      <button
        type="button"
        disabled={!picking}
        onClick={() => setPicked(e)}
        aria-label={picking ? `Select ${e.label}` : e.label}
        className={cn("relative block w-full overflow-hidden rounded-xl text-left transition", className, picking && "cursor-crosshair outline-dashed outline-2 outline-offset-2 outline-primary/60 hover:outline-primary", picked?.id === e.id && "outline-solid outline-primary")}
      >
        <div className={cn(st === "blur" && "blur-md", st !== "still" && (e.kind === "anim" || e.kind === "ad") && "animate-pulse")}>{children}</div>
        {st && <span className="absolute right-2 top-2 rounded-full bg-mist-1/90 px-2 py-0.5 text-[10px] font-semibold text-primary">{st === "still" ? "calmed" : st === "blur" ? "blurred" : ""}</span>}
      </button>
    );
  };

  return (
    <div>
      <DashHeader title="Your Internet, Your Rules." sub="Take control of how webpages look, behave, and present information. Customize your browsing environment based on what works best for you." />

      <div className="grid gap-6 xl:grid-cols-[1fr_1.15fr]">
        <Panel title="Your CLEAR Preferences">
          <div className="mb-4 flex items-center justify-between">
            <p className="text-sm font-semibold text-primary" aria-live="polite">{on} of {CUSTOMIZE_ITEMS.length} enabled</p>
            <Button variant="ghost" size="sm" className="rounded-full" onClick={() => { setPrefs((s) => ({ ...s, customize: DEFAULT_CUSTOMIZE, rules: [] })); setLocal({}); toast("Customize settings reset."); }}>
              <RotateCcw /> Reset
            </Button>
          </div>
          <div className="space-y-2">
            {CUSTOMIZE_ITEMS.map((it) => (
              <ToggleRow key={it.key} label={it.label} hint={it.hint} checked={c[it.key]} onChange={(v) => setPrefs((s) => ({ ...s, customize: { ...s.customize, [it.key]: v } }))} />
            ))}
          </div>
          {p.rules.length > 0 && (
            <div className="mt-6">
              <h3 className="mb-2 text-sm font-semibold text-primary">Saved element rules</h3>
              <ul className="space-y-2">
                {p.rules.map((r) => (
                  <li key={r.id} className="flex items-center justify-between rounded-xl bg-mist-2/70 px-3 py-2 text-sm">
                    <span>Always {r.action === "still" ? "calm" : r.action}: <b>{r.label}</b></span>
                    <button type="button" aria-label={`Remove rule for ${r.label}`} onClick={() => { setPrefs((s) => ({ ...s, rules: s.rules.filter((x) => x.id !== r.id) })); setLocal(({ [r.id]: _, ...rest }) => rest); }} className="rounded-full p-1 hover:bg-mist-3"><Trash2 className="h-4 w-4" /></button>
                  </li>
                ))}
              </ul>
            </div>
          )}
          <div className="mt-6 rounded-2xl bg-mist-2/70 p-4 text-sm">
            <p className="font-semibold text-primary">Visual adjustments</p>
            <p className="mt-1 text-muted-foreground">Font size, text spacing, contrast, colors and background.</p>
            <div className="mt-3 flex flex-wrap gap-2">
              <Button asChild size="sm" variant="outline" className="rounded-full bg-mist-1/60"><Link to="/dashboard/sensory">Colors & motion</Link></Button>
              <Button asChild size="sm" variant="outline" className="rounded-full bg-mist-1/60"><Link to="/dashboard/preferences">Text & background</Link></Button>
            </div>
          </div>
        </Panel>

        <Panel title="Click-to-Customize" icon={<MousePointerClick className="h-5 w-5" />}>
          <p className="text-muted-foreground">CLEAR's signature feature: pick any single element on a page and decide what happens to it. Try it on this sample page.</p>
          <div className="mt-4 flex flex-wrap gap-2">
            <Button className="rounded-full" variant={picking ? "secondary" : "default"} onClick={() => { setPicking(!picking); setPicked(null); }}>
              <MousePointerClick /> {picking ? "Stop selecting" : "Start selecting"}
            </Button>
            <Button variant="outline" className="rounded-full bg-mist-1/60" aria-pressed={reading} onClick={() => setReading(!reading)}><BookOpen /> Reading mode {reading ? "on" : "off"}</Button>
            {Object.keys(local).length > 0 && <Button variant="ghost" className="rounded-full" onClick={() => setLocal({})}>Undo page changes</Button>}
          </div>
          {picking && !picked && <p className="mt-3 text-sm font-medium text-primary" role="status">Click any element in the sample page below.</p>}

          {picked && (
            <div className="glass-strong mt-4 rounded-2xl p-4" role="dialog" aria-label={`Customize ${picked.label}`}>
              <div className="flex items-center justify-between"><p className="font-semibold text-primary">{picked.label}</p><button type="button" aria-label="Close" onClick={() => setPicked(null)}><X className="h-4 w-4" /></button></div>
              <div className="mt-3 grid gap-2 sm:grid-cols-2">
                {ACTIONS.map((a) => <Button key={a.v} variant="outline" className="justify-start rounded-xl bg-mist-1/70" onClick={() => apply(a.v)}><a.icon /> {a.label}</Button>)}
                <Button className="justify-start rounded-xl" onClick={always}><Pin /> Always apply this preference</Button>
              </div>
            </div>
          )}

          <div className={cn("mt-5 rounded-2xl border border-mist-4 p-4", c.backgrounds ? "bg-mist-1" : "bg-gradient-to-br from-mist-3 via-mist-1 to-mist-4")} aria-label="Sample webpage">
            <p className="mb-2 text-xs font-semibold text-muted-foreground">Sample page · example.news</p>
            <div className="space-y-3">
              {box(ELEMENTS[0]!, "", <div className="rounded-xl bg-destructive/80 p-3 text-center text-sm font-bold text-primary-foreground">🎉 SALE! 70% OFF — CLICK NOW!</div>)}
              {box(ELEMENTS[1]!, "", <div className="h-24 rounded-xl bg-gradient-to-r from-mist-5 to-primary" />)}
              <div className="grid gap-3 sm:grid-cols-[1fr_8rem]">
                <div className="space-y-3">
                  <article className={cn("rounded-xl bg-mist-1/80 p-3", reading && "p-5 text-lg leading-relaxed")}>
                    <h4 className="font-display font-semibold text-primary">City opens new riverside park</h4>
                    <p className="mt-1 text-sm text-muted-foreground">The park includes walking paths, quiet areas and a community garden. It opens to the public on Saturday morning.</p>
                  </article>
                  {box(ELEMENTS[2]!, "", <div className="flex h-20 items-center justify-center rounded-xl bg-primary/90 text-sm text-primary-foreground">{stateOf(ELEMENTS[2]!) === "still" ? "⏸ Video paused" : "▶ Video playing with sound"}</div>)}
                  {box(ELEMENTS[3]!, "", <div className="overflow-hidden rounded-xl bg-mist-3 py-2 text-xs"><span className={cn("inline-block whitespace-nowrap", stateOf(ELEMENTS[3]!) !== "still" && "animate-pulse")}>BREAKING • Markets move • Weather alert • Sports scores •</span></div>)}
                </div>
                {box(ELEMENTS[4]!, "", <div className="flex h-full min-h-24 items-center justify-center rounded-xl bg-accent p-2 text-center text-xs font-semibold">Buy shoes!!</div>)}
              </div>
              {box(ELEMENTS[5]!, "", <div className="rounded-xl border border-mist-5 bg-mist-1 p-3 text-sm shadow-float">📬 Subscribe to our newsletter! <span className="underline">No thanks</span></div>)}
            </div>
          </div>
          <p className="mt-3 text-xs text-muted-foreground">Prototype demo on a sample page. In the Chrome extension, the same picker works on real websites.</p>
        </Panel>
      </div>
    </div>
  );
}
