import { createFileRoute } from "@tanstack/react-router";
import { Eye, MessageSquareText, RotateCcw, Save, UserRound, Volume2 } from "lucide-react";
import { useEffect, useState } from "react";
import { toast } from "sonner";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Slider } from "@/components/ui/slider";
import { DashHeader, Panel, Segmented, ToggleRow } from "@/components/clear/dash";
import { DEFAULT_PREFS, getPrefs, initials, setPrefs, usePrefs, type Prefs } from "@/lib/prefs";

export const Route = createFileRoute("/dashboard/preferences")({
  head: () => ({
    meta: [
      { title: "My Preferences — CLEAR" },
      { name: "description", content: "Edit your name, how CLEAR explains things, how it looks, and how it talks to you." },
      { property: "og:title", content: "CLEAR — My Preferences" },
      { property: "og:description", content: "Make CLEAR yours." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: PreferencesPage,
});

function Field({ label, value, children }: { label: string; value?: string | undefined; children: React.ReactNode }) {
  return (
    <div className="rounded-2xl bg-mist-1/60 px-4 py-4">
      <div className="mb-3 flex justify-between gap-2"><span className="font-medium">{label}</span>{value && <span className="text-sm text-muted-foreground">{value}</span>}</div>
      {children}
    </div>
  );
}

function PreferencesPage() {
  const saved = usePrefs();
  const [d, setD] = useState<Prefs>(saved);
  useEffect(() => setD(getPrefs()), []);
  const dirty = JSON.stringify(d) !== JSON.stringify(saved);
  const up = <K extends keyof Prefs>(k: K, v: Prefs[K]) => setD((x) => ({ ...x, [k]: v }));
  const comm = (k: keyof Prefs["comm"], v: boolean) => setD((x) => ({ ...x, comm: { ...x.comm, [k]: v } }));
  const vis = <K extends keyof Prefs["visual"]>(k: K, v: Prefs["visual"][K]) => setD((x) => ({ ...x, visual: { ...x.visual, [k]: v } }));
  const voice = <K extends keyof Prefs["voice"]>(k: K, v: Prefs["voice"][K]) => setD((x) => ({ ...x, voice: { ...x.voice, [k]: v } }));

  const save = () => {
    setPrefs({ ...d, name: d.name.trim() });
    toast.success("Your preferences are saved.");
  };
  const reset = () => {
    const next = { ...DEFAULT_PREFS, name: d.name, onboarded: true };
    setD(next);
    setPrefs(next);
    toast("Preferences reset. Your name was kept.");
  };

  return (
    <div>
      <DashHeader title="Make CLEAR yours." sub="Your experience should work the way you want it to.">
        <div className="flex gap-2">
          <Button variant="outline" className="rounded-full bg-mist-1/60" onClick={reset}><RotateCcw /> Reset Preferences</Button>
          <Button className="rounded-full" onClick={save} disabled={!dirty}><Save /> {dirty ? "Save Changes" : "Saved"}</Button>
        </div>
      </DashHeader>
      <div className="grid gap-6 lg:grid-cols-2">
        <Panel title="Profile" icon={<UserRound className="h-5 w-5" />}>
          <div className="flex items-center gap-5">
            <span className="flex h-20 w-20 shrink-0 items-center justify-center rounded-full bg-primary font-display text-2xl font-semibold text-primary-foreground shadow-float">{initials(d.name)}</span>
            <div className="flex-1">
              <label htmlFor="dn" className="text-sm text-muted-foreground">Display name</label>
              <Input id="dn" value={d.name} maxLength={40} onChange={(e) => up("name", e.target.value)} placeholder="Your name" className="mt-1 h-11 rounded-xl bg-mist-1/80" />
            </div>
          </div>
          <div className="mt-5 space-y-3">
            <Field label="Interface appearance">
              <Segmented label="Interface appearance" value={d.appearance} onChange={(v) => up("appearance", v)} options={[{ v: "misty", label: "Misty" }, { v: "deeper", label: "Deeper blue" }]} />
            </Field>
            <Field label="Interface tone">
              <Segmented label="Interface tone" value={d.tone} onChange={(v) => up("tone", v)} options={[{ v: "gentle", label: "Gentle" }, { v: "neutral", label: "Neutral" }, { v: "direct", label: "Direct" }]} />
            </Field>
          </div>
        </Panel>

        <Panel title="Communication Preferences" icon={<MessageSquareText className="h-5 w-5" />}>
          <div className="space-y-3">
            <Field label="Explanation style">
              <Segmented label="Explanation style" value={d.explanationStyle} onChange={(v) => up("explanationStyle", v)} options={[{ v: "direct", label: "Direct and simple" }, { v: "detailed", label: "More detailed" }]} />
            </Field>
            <ToggleRow label="Literal language" checked={d.comm.literal} onChange={(v) => comm("literal", v)} />
            <ToggleRow label="Shorter responses" checked={d.comm.shorter} onChange={(v) => comm("shorter", v)} />
            <ToggleRow label="Multiple possible interpretations" checked={d.comm.multiple} onChange={(v) => comm("multiple", v)} />
            <ToggleRow label="More context and examples" checked={d.comm.examples} onChange={(v) => comm("examples", v)} />
          </div>
        </Panel>

        <Panel title="Visual Preferences" icon={<Eye className="h-5 w-5" />}>
          <div className="space-y-3">
            <Field label="Blue color intensity" value={`${d.visual.blueIntensity}%`}>
              <Slider aria-label="Blue color intensity" min={40} max={160} step={5} value={[d.visual.blueIntensity]} onValueChange={([v]) => vis("blueIntensity", v!)} />
            </Field>
            <Field label="Background appearance">
              <Segmented label="Background appearance" value={d.visual.background} onChange={(v) => vis("background", v)} options={[{ v: "fog", label: "Foggy window" }, { v: "soft", label: "Soft mist" }, { v: "plain", label: "Plain" }]} />
            </Field>
            <Field label="Font size" value={`${d.visual.fontSize}px`}>
              <Slider aria-label="Font size" min={14} max={22} step={1} value={[d.visual.fontSize]} onValueChange={([v]) => vis("fontSize", v!)} />
            </Field>
            <Field label="Text spacing" value={["Normal", "Relaxed", "Roomy", "Extra roomy"][d.visual.textSpacing]}>
              <Slider aria-label="Text spacing" min={0} max={3} step={1} value={[d.visual.textSpacing]} onValueChange={([v]) => vis("textSpacing", v!)} />
            </Field>
            <Field label="Card appearance">
              <Segmented label="Card appearance" value={d.visual.cards} onChange={(v) => vis("cards", v)} options={[{ v: "glass", label: "Frosted glass" }, { v: "solid", label: "Solid" }]} />
            </Field>
            <ToggleRow label="Reduce animations" checked={d.sensory.reduceAnimations} onChange={(v) => setD((x) => ({ ...x, sensory: { ...x.sensory, reduceAnimations: v } }))} />
          </div>
        </Panel>

        <Panel title="Voice Preferences" icon={<Volume2 className="h-5 w-5" />}>
          <div className="space-y-3">
            <ToggleRow label="Voice assistance" checked={d.voice.enabled} onChange={(v) => voice("enabled", v)} />
            <ToggleRow label="Read responses aloud" checked={d.voice.readAloud} onChange={(v) => voice("readAloud", v)} />
            <Field label="Speech rate" value={`${d.voice.rate.toFixed(2)}×`}>
              <Slider aria-label="Speech rate" min={0.6} max={1.4} step={0.05} value={[d.voice.rate]} onValueChange={([v]) => voice("rate", v!)} />
            </Field>
            <Field label="I prefer">
              <Segmented label="Interaction mode" value={d.voice.mode} onChange={(v) => setD((x) => ({ ...x, assistMode: v === "voice" ? "voice" : "visual", voice: { ...x.voice, mode: v } }))} options={[{ v: "voice", label: "Voice interaction" }, { v: "text", label: "Text interaction" }]} />
            </Field>
          </div>
        </Panel>
      </div>
      {dirty && (
        <div className="glass-strong sticky bottom-4 mt-6 flex items-center justify-between gap-4 rounded-2xl px-5 py-3">
          <span className="text-sm">You have unsaved changes.</span>
          <Button className="rounded-full" onClick={save}><Save /> Save Changes</Button>
        </div>
      )}
    </div>
  );
}
