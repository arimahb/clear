import { createFileRoute } from "@tanstack/react-router";
import { Loader2, Sparkles, Volume2 } from "lucide-react";
import { useState } from "react";

import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { DashHeader, Panel, ToggleRow } from "@/components/clear/dash";
import { streamExplanation } from "@/lib/explain-stream";
import type { ExplainResult } from "@/lib/explain";
import { setPrefs, usePrefs, type Prefs } from "@/lib/prefs";
import { EXAMPLE_RESULTS, EXAMPLE_TEXT, STYLES, type SimplifyResult } from "@/lib/simplify";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/dashboard/simplify")({
  head: () => ({
    meta: [
      { title: "Simplify — Understand Information Your Way | CLEAR" },
      { name: "description", content: "Paste text and choose how CLEAR explains it: simpler language, steps, an example, a summary or more detail." },
      { property: "og:title", content: "CLEAR Simplify" },
      { property: "og:description", content: "Understand information your way." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: SimplifyPage,
});

const UNDERSTANDING: { k: Exclude<keyof Prefs["simplify"], "style">; label: string }[] = [
  { k: "simple", label: "Simple language instead of technical terms" },
  { k: "numbered", label: "Numbered steps instead of paragraphs" },
  { k: "examples", label: "Practical examples" },
  { k: "concise", label: "Concise explanations" },
  { k: "context", label: "Additional context" },
  { k: "detailed", label: "Detailed explanations" },
];

function SimplifyPage() {
  const p = usePrefs();
  const style = p.simplify.style;
  const [text, setText] = useState(EXAMPLE_TEXT);
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState("");
  const [res, setRes] = useState<{ r: SimplifyResult; label: string; sample: boolean } | null>(null);
  const label = STYLES.find((s) => s.v === style)!.label;

  const run = async () => {
    setErr("");
    if (text.trim().length < 2) return setErr("Paste or type some text first.");
    setBusy(true);
    const { style: _s, ...flags } = p.simplify;
    const prefs = Object.entries(flags).filter(([, on]) => on).map(([k]) => k);
    const toResult = (r: ExplainResult): SimplifyResult => ({ explanation: r.explanation, terms: r.keyTerms, notes: r.ambiguity });
    const out = await streamExplanation("/api/public/explain", { text: text.trim(), style, prefs }, (r) => {
      if (r.explanation) setRes({ r: toResult(r), label, sample: false });
    })
      .then((r) => ({ ok: true as const, data: toResult(r) }))
      .catch((e: Error) => ({ ok: false as const, error: e.message || "Couldn't reach CLEAR. Please try again." }));
    setBusy(false);
    if (out.ok) setRes({ r: out.data, label, sample: false });
    else if (text.trim() === EXAMPLE_TEXT) {
      setRes({ r: EXAMPLE_RESULTS[style], label, sample: true });
      setErr(`${out.error} Showing a pre-written example instead.`);
    } else setErr(out.error);
  };
  const speak = (t: string) => {
    if (!("speechSynthesis" in window)) return setErr("Read aloud isn't supported in this browser.");
    speechSynthesis.cancel();
    const u = new SpeechSynthesisUtterance(t);
    u.rate = p.voice.rate;
    speechSynthesis.speak(u);
  };

  return (
    <div>
      <DashHeader title="Understand Information Your Way." sub="Make complicated information easier to understand without losing its meaning. CLEAR adapts explanations to the way you prefer to learn." />
      <div className="grid gap-6 xl:grid-cols-[1.3fr_1fr]">
        <div className="space-y-6">
          <Panel title="Explain with CLEAR" icon={<Sparkles className="h-5 w-5" />}>
            <p className="mb-3 text-sm text-muted-foreground">In the extension you highlight text, right-click and choose <b>Explain with CLEAR</b>. Here, paste or type it.</p>
            <label htmlFor="src" className="sr-only">Text to explain</label>
            <Textarea id="src" value={text} onChange={(e) => setText(e.target.value)} maxLength={4000} className="min-h-28 rounded-2xl bg-mist-1/70" />
            <h3 className="mt-6 font-display text-lg font-semibold text-primary">How would you like CLEAR to explain this?</h3>
            <div role="radiogroup" aria-label="Explanation style" className="mt-3 grid gap-2 sm:grid-cols-2 lg:grid-cols-3">
              {STYLES.map((s, i) => (
                <button key={s.v} type="button" role="radio" aria-checked={style === s.v} onClick={() => setPrefs((x) => ({ ...x, simplify: { ...x.simplify, style: s.v } }))}
                  className={cn("rounded-2xl border p-3 text-left transition", style === s.v ? "border-primary bg-mist-3 shadow-soft" : "border-mist-4 bg-mist-1/60 hover:bg-mist-2")}>
                  <span className="block text-sm font-semibold text-primary">{i + 1}. {s.label}</span>
                  <span className="text-xs text-muted-foreground">{s.hint}</span>
                </button>
              ))}
            </div>
            <div className="mt-5 flex flex-wrap gap-2">
              <Button onClick={run} disabled={busy} className="rounded-full px-6">{busy && <Loader2 className="animate-spin" />} Explain with CLEAR</Button>
              {text !== EXAMPLE_TEXT && <Button variant="ghost" className="rounded-full" onClick={() => setText(EXAMPLE_TEXT)}>Use the example sentence</Button>}
            </div>
            {err && <p role="alert" className="mt-3 text-sm text-destructive">{err}</p>}
          </Panel>

          {res && (
            <Panel title={`${res.label}`}>
              <div aria-live="polite" className="space-y-4">
                {res.sample && <p className="inline-flex items-center gap-1.5 rounded-full bg-mist-4/70 px-3 py-1 text-xs font-semibold text-primary"><Sparkles className="h-3 w-3" /> Pre-written example, not a live AI response</p>}
                <p className="whitespace-pre-line rounded-2xl bg-mist-2/70 p-4 text-lg">{res.r.explanation}</p>
                {res.r.terms.length > 0 && (
                  <div><h3 className="mb-2 text-sm font-semibold text-primary">Important terms kept</h3>
                    <dl className="space-y-1 text-sm">{res.r.terms.map((t) => <div key={t.term}><dt className="inline font-semibold">{t.term}</dt>: <dd className="inline text-muted-foreground">{t.meaning}</dd></div>)}</dl></div>
                )}
                {res.r.notes.length > 0 && (
                  <div className="rounded-2xl bg-mist-3/70 p-4 text-sm"><h3 className="mb-1 font-semibold text-primary">Worth knowing</h3><ul className="list-disc pl-5">{res.r.notes.map((n) => <li key={n}>{n}</li>)}</ul></div>
                )}
                <Button variant="outline" size="sm" className="rounded-full bg-mist-1/60" onClick={() => speak(res.r.explanation)}><Volume2 /> Read aloud</Button>
              </div>
            </Panel>
          )}
        </div>

        <div className="space-y-6">
          <Panel title="Personal understanding preferences">
            <p className="mb-4 text-sm text-muted-foreground">Saved automatically and used for every explanation.</p>
            <div className="space-y-2">
              {UNDERSTANDING.map((u) => <ToggleRow key={u.k} label={u.label} checked={p.simplify[u.k]} onChange={(v) => setPrefs((x) => ({ ...x, simplify: { ...x.simplify, [u.k]: v } }))} />)}
            </div>
          </Panel>
          <Panel title="Same text, five ways">
            <p className="mb-3 text-sm text-muted-foreground">Pre-written examples for: “{EXAMPLE_TEXT}”</p>
            <ul className="space-y-2 text-sm">
              {STYLES.map((s) => <li key={s.v} className="rounded-2xl bg-mist-1/70 p-3"><b className="block text-primary">{s.label}</b><span className="whitespace-pre-line">{EXAMPLE_RESULTS[s.v].explanation}</span></li>)}
            </ul>
          </Panel>
          <Panel title="Meaning comes first">
            <ul className="list-disc space-y-1 pl-5 text-sm text-muted-foreground">
              <li>Keeps important terminology and explains it.</li><li>Explains hard ideas instead of removing them.</li><li>Separates facts from interpretations.</li><li>Never invents information.</li><li>Flags ambiguous wording.</li>
            </ul>
          </Panel>
        </div>
      </div>
    </div>
  );
}
