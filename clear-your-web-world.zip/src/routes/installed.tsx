import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowRight, Check, Download, SlidersHorizontal, Sparkles } from "lucide-react";
import { useEffect, useState } from "react";

import { Button } from "@/components/ui/button";
import { SiteShell } from "@/components/clear/SiteChrome";
import { usePrefs } from "@/lib/prefs";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/installed")({
  head: () => ({
    meta: [
      { title: "You've downloaded CLEAR — Next steps" },
      { name: "description", content: "Finish installing the CLEAR prototype in Chrome, then open your personal CLEAR dashboard." },
      { property: "og:title", content: "CLEAR downloaded" },
      { property: "og:description", content: "Finish setup and open your CLEAR space." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Installed,
});

const STEPS = ["Unzip clear-extension.zip", "Open chrome://extensions", "Turn on Developer mode", "Click Load unpacked and choose the folder", "Pin CLEAR from the puzzle-piece menu"];
const KEY = "clear:install-steps";

function Installed() {
  const p = usePrefs();
  const [done, setDone] = useState<boolean[]>(STEPS.map(() => false));
  useEffect(() => {
    try { const s = JSON.parse(localStorage.getItem(KEY) ?? "null"); if (Array.isArray(s)) setDone(STEPS.map((_, i) => Boolean(s[i]))); } catch { /* ignore */ }
  }, []);
  const toggle = (i: number) => setDone((d) => { const n = d.map((v, j) => (j === i ? !v : v)); localStorage.setItem(KEY, JSON.stringify(n)); return n; });
  const count = done.filter(Boolean).length;

  return (
    <SiteShell>
      <section className="mx-auto max-w-3xl px-6 pb-10 pt-20 text-center">
        <span className="mx-auto flex h-14 w-14 items-center justify-center rounded-full bg-primary text-primary-foreground shadow-float"><Check /></span>
        <h1 className="mt-6 font-display text-4xl font-semibold text-primary md:text-6xl">CLEAR is downloading.</h1>
        <p className="mt-5 text-lg text-muted-foreground">Finish these quick steps in Chrome, then head into your CLEAR space. If the download didn't start, <a href="/clear-extension.zip?v=0.6.0" download className="font-semibold text-primary underline underline-offset-4">download it again</a>.</p>
      </section>
      <div className="mx-auto grid max-w-6xl gap-6 px-6 pb-24 lg:grid-cols-[1fr_1.1fr]">
        <section className="glass-strong rounded-[2rem] p-8">
          <div className="flex items-center justify-between"><h2 className="font-display text-2xl font-semibold text-primary">Install checklist</h2><span className="text-sm font-semibold text-muted-foreground">{count}/{STEPS.length}</span></div>
          <ul className="mt-6 space-y-2">
            {STEPS.map((s, i) => (
              <li key={s}>
                <button type="button" role="checkbox" aria-checked={done[i]} onClick={() => toggle(i)} className={cn("flex w-full items-center gap-3 rounded-2xl px-4 py-3 text-left transition", done[i] ? "bg-mist-3" : "bg-mist-1/70 hover:bg-mist-2")}>
                  <span className={cn("flex h-6 w-6 shrink-0 items-center justify-center rounded-full border-2 border-primary", done[i] && "bg-primary text-primary-foreground")}>{done[i] && <Check className="h-4 w-4" />}</span>
                  <span className={cn(done[i] && "text-muted-foreground line-through")}>{s}</span>
                </button>
              </li>
            ))}
          </ul>
          <Button asChild variant="ghost" className="mt-4 rounded-full"><a href="/clear-extension.zip?v=0.6.0" download><Download /> Download again</a></Button>
        </section>
        <section className="glass flex flex-col rounded-[2rem] p-8">
          <p className="text-sm font-semibold uppercase tracking-[0.2em] text-muted-foreground">Your dashboard</p>
          <h2 className="mt-3 font-display text-3xl font-semibold text-primary">Make CLEAR yours.</h2>
          <p className="mt-3 text-muted-foreground">Your dashboard is where you set up the two things CLEAR does.</p>
          <div className="mt-6 grid flex-1 gap-3 sm:grid-cols-2">
            <div className="rounded-2xl bg-mist-2/70 p-5"><SlidersHorizontal className="text-primary" /><h3 className="mt-3 font-semibold text-primary">Customize</h3><p className="text-sm text-muted-foreground">Choose what to blur, hide or calm.</p></div>
            <div className="rounded-2xl bg-mist-2/70 p-5"><Sparkles className="text-primary" /><h3 className="mt-3 font-semibold text-primary">Simplify</h3><p className="text-sm text-muted-foreground">Pick how text gets explained to you.</p></div>
          </div>
          <Button asChild size="lg" className="mt-8 self-start rounded-full px-7 shadow-float">
            {p.onboarded ? <Link to="/dashboard">Open my dashboard <ArrowRight /></Link> : <Link to="/onboarding">Set up my dashboard <ArrowRight /></Link>}
          </Button>
        </section>
      </div>
    </SiteShell>
  );
}
