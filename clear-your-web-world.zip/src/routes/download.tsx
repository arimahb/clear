import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { ArrowRight, Download, Info } from "lucide-react";

import { Button } from "@/components/ui/button";
import { LogoMark } from "@/components/clear/Logo";
import { SiteShell } from "@/components/clear/SiteChrome";

export const Route = createFileRoute("/download")({
  head: () => ({
    meta: [
      { title: "Get CLEAR — Download and start" },
      { name: "description", content: "Install the CLEAR prototype extension for Chrome, or explore the CLEAR demo dashboard right away." },
      { property: "og:title", content: "Get CLEAR for Chrome" },
      { property: "og:description", content: "Your clearer browsing experience starts here." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: DownloadPage,
});

const STEPS = [
  "Download the prototype file and unzip it.",
  "Open chrome://extensions in a new tab.",
  "Turn on Developer mode (top right).",
  "Click Load unpacked and choose the unzipped folder.",
  "Pin CLEAR from the puzzle-piece menu.",
];

function DownloadPage() {
  const navigate = useNavigate();
  return (
    <SiteShell>
      <section className="mx-auto max-w-3xl px-6 pb-10 pt-20 text-center">
        <h1 className="font-display text-4xl font-semibold leading-tight text-primary md:text-6xl">Your clearer browsing experience starts here.</h1>
        <p className="mt-6 text-lg text-muted-foreground">Customize how webpages look and behave, and simplify information so it makes sense to you.</p>
      </section>
      <div className="mx-auto grid max-w-6xl gap-6 px-6 pb-24 lg:grid-cols-[1.1fr_1fr]">
        <section className="glass-strong rounded-[2rem] p-8 md:p-10">
          <div className="flex items-center gap-4">
            <span className="flex h-16 w-16 items-center justify-center rounded-2xl bg-mist-2 shadow-soft"><LogoMark className="h-11 w-11" /></span>
            <div>
              <h2 className="font-display text-2xl font-semibold text-primary">CLEAR for Chrome</h2>
              <p className="text-sm text-muted-foreground">Works on Chrome, Edge, Brave and Arc</p>
            </div>
          </div>
          <p className="mt-6 text-muted-foreground">Choose exactly what to blur, hide or calm on any page, and highlight text to have it explained your way.</p>
          <div className="mt-6 flex items-start gap-3 rounded-2xl bg-mist-3/70 p-4 text-sm">
            <Info className="mt-0.5 h-4 w-4 shrink-0 text-primary" />
            <p>CLEAR isn't on the Chrome Web Store yet. For now you can install the <b>prototype</b> by hand in about a minute.</p>
          </div>
          <Button asChild size="lg" className="mt-6 rounded-full px-7 shadow-float">
            <a href="/clear-extension.zip?v=0.6.0" download="clear-extension.zip" onClick={() => setTimeout(() => navigate({ to: "/installed" }), 400)}><Download /> Add to Chrome (prototype .zip)</a>
          </Button>
          <ol className="mt-8 space-y-3">
            {STEPS.map((s, i) => (
              <li key={s} className="flex gap-3">
                <span className="flex h-7 w-7 shrink-0 items-center justify-center rounded-full bg-primary text-sm font-semibold text-primary-foreground">{i + 1}</span>
                <span className="pt-0.5">{s}</span>
              </li>
            ))}
          </ol>
        </section>
        <section className="glass flex flex-col justify-between rounded-[2rem] p-8 md:p-10">
          <div>
            <p className="text-sm font-semibold uppercase tracking-[0.2em] text-muted-foreground">Hackathon demo</p>
            <h2 className="mt-3 font-display text-3xl font-semibold text-primary">Explore CLEAR without installing anything.</h2>
            <p className="mt-4 text-muted-foreground">Set up your space in a few short questions, then try Customize and Simplify in your personal dashboard.</p>
          </div>
          <div className="mt-8 flex flex-wrap gap-3">
            <Button asChild size="lg" className="rounded-full px-7"><Link to="/onboarding">Explore the CLEAR Demo <ArrowRight /></Link></Button>
          </div>
        </section>
      </div>
    </SiteShell>
  );
}
