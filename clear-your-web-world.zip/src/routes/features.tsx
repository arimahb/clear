import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowRight, Check } from "lucide-react";

import { Button } from "@/components/ui/button";
import { FEATURES } from "@/components/clear/features";
import { EXAMPLE_RESULTS, EXAMPLE_TEXT } from "@/lib/simplify";
import { PageHero, SiteShell } from "@/components/clear/SiteChrome";

export const Route = createFileRoute("/features")({
  head: () => ({
    meta: [
      { title: "Features — CLEAR" },
      { name: "description", content: "CLEAR has two features: Customize how webpages look and behave, and Simplify information so you understand it your way." },
      { property: "og:title", content: "CLEAR features" },
      { property: "og:description", content: "Customize your digital environment. Simplify information your way." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: FeaturesPage,
});

const DEMOS: Record<string, React.ReactNode> = {
  customize: (
    <div className="space-y-2 text-sm">
      {["Advertisements", "Autoplaying videos", "Moving animations", "Pop-ups"].map((l, i) => (
        <div key={l} className="flex items-center justify-between rounded-xl bg-mist-1/80 px-4 py-3">
          {l}<span className={`h-5 w-9 rounded-full ${i !== 2 ? "bg-primary" : "bg-mist-4"}`} />
        </div>
      ))}
      <div className="rounded-xl bg-mist-3/80 p-3 text-xs"><b className="text-primary">Clicked an element:</b> Blur this · Hide this · Reduce its movement · Always apply</div>
    </div>
  ),
  simplify: (
    <div className="space-y-3 text-sm">
      <p className="rounded-2xl bg-mist-1/80 p-4">“{EXAMPLE_TEXT}”</p>
      <p className="whitespace-pre-line rounded-2xl bg-mist-3/80 p-4"><b className="block text-primary">Step-by-Step</b>{EXAMPLE_RESULTS.steps.explanation}</p>
    </div>
  ),
};

function FeaturesPage() {
  return (
    <SiteShell>
      <PageHero eyebrow="Features" title="Two features. Endless ways to make them yours.">
        Customize controls your digital environment. Simplify helps you understand information your way.
      </PageHero>
      <div className="mx-auto max-w-6xl space-y-8 px-6 pb-24">
        {FEATURES.map((f, i) => (
          <section key={f.key} id={f.key} className="glass grid scroll-mt-28 items-center gap-8 rounded-[2rem] p-8 md:grid-cols-2 md:p-12">
            <div className={i % 2 ? "md:order-2" : ""}>
              <span className="flex h-12 w-12 items-center justify-center rounded-2xl bg-mist-3 text-primary"><f.icon /></span>
              <p className="mt-5 text-sm font-semibold uppercase tracking-[0.2em] text-muted-foreground">{f.num} · {f.name}</p>
              <h2 className="mt-1 font-display text-3xl font-semibold text-primary">{f.title}</h2>
              <p className="mt-2 text-lg text-muted-foreground">{f.blurb}</p>
              <ul className="mt-5 space-y-2">
                {f.items.map((it) => <li key={it} className="flex gap-2"><Check className="mt-1 h-4 w-4 shrink-0 text-primary/60" />{it}</li>)}
              </ul>
              <Button asChild variant="outline" className="mt-6 rounded-full bg-mist-1/60">
                <Link to={f.to}>Try it in the demo <ArrowRight /></Link>
              </Button>
            </div>
            <div className="rounded-3xl bg-mist-2/70 p-6" aria-hidden>{DEMOS[f.key]}</div>
          </section>
        ))}
      </div>
    </SiteShell>
  );
}
