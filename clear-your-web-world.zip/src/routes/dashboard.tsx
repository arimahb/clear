import { createFileRoute, Link, Outlet } from "@tanstack/react-router";
import { Home, Menu, Settings2, SlidersHorizontal, Sparkles } from "lucide-react";
import { useState } from "react";

import { Button } from "@/components/ui/button";
import { Sheet, SheetContent, SheetTitle, SheetTrigger } from "@/components/ui/sheet";
import { Logo } from "@/components/clear/Logo";
import { initials, usePrefs } from "@/lib/prefs";

export const Route = createFileRoute("/dashboard")({
  component: DashboardLayout,
});

const ITEMS = [
  { to: "/dashboard" as const, label: "Home", icon: Home, exact: true },
  { to: "/dashboard/customize" as const, label: "Customize", icon: SlidersHorizontal },
  { to: "/dashboard/simplify" as const, label: "Simplify", icon: Sparkles },
  { to: "/dashboard/preferences" as const, label: "My Preferences", icon: Settings2 },
];

function NavList({ onNavigate }: { onNavigate?: () => void }) {
  return (
    <nav aria-label="Dashboard" className="flex flex-col gap-1">
      {ITEMS.map((i) => (
        <Link
          key={i.to}
          to={i.to}
          onClick={onNavigate}
          activeOptions={{ exact: i.exact ?? false }}
          className="flex items-center gap-3 rounded-2xl px-4 py-3 text-muted-foreground transition hover:bg-mist-2 hover:text-primary"
          activeProps={{ className: "bg-mist-3 !text-primary font-semibold shadow-soft", "aria-current": "page" }}
        >
          <i.icon className="h-5 w-5" /> {i.label}
        </Link>
      ))}
    </nav>
  );
}

function Profile() {
  const { name } = usePrefs();
  return (
    <Link to="/dashboard/preferences" className="flex items-center gap-3 rounded-2xl bg-mist-2/70 p-3 hover:bg-mist-3">
      <span className="flex h-10 w-10 items-center justify-center rounded-full bg-primary font-semibold text-primary-foreground">{initials(name)}</span>
      <span className="min-w-0">
        <span className="block truncate font-semibold text-primary">{name.trim() || "Your space"}</span>
        <span className="text-xs text-muted-foreground">Edit preferences</span>
      </span>
    </Link>
  );
}

function DashboardLayout() {
  const [open, setOpen] = useState(false);
  return (
    <div className="min-h-screen font-sans lg:flex">
      <aside className="glass sticky top-4 m-4 hidden h-[calc(100vh-2rem)] w-72 shrink-0 flex-col justify-between rounded-[2rem] p-5 lg:flex">
        <div>
          <div className="mb-8 px-2 pt-1"><Logo /></div>
          <NavList />
        </div>
        <Profile />
      </aside>
      <div className="glass sticky top-0 z-30 flex items-center justify-between px-4 py-3 lg:hidden">
        <Logo />
        <Sheet open={open} onOpenChange={setOpen}>
          <SheetTrigger asChild>
            <Button variant="ghost" size="icon" aria-label="Open dashboard menu"><Menu /></Button>
          </SheetTrigger>
          <SheetContent side="left" className="glass-strong flex flex-col justify-between">
            <div>
              <SheetTitle className="sr-only">Dashboard menu</SheetTitle>
              <div className="mb-6 mt-2"><Logo /></div>
              <NavList onNavigate={() => setOpen(false)} />
            </div>
            <Profile />
          </SheetContent>
        </Sheet>
      </div>
      <main className="min-w-0 flex-1 px-4 py-8 md:px-8 lg:py-10 lg:pr-10">
        <div className="mx-auto max-w-6xl">
          <Outlet />
        </div>
      </main>
    </div>
  );
}
