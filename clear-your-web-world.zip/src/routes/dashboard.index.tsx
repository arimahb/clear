import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowDown, ArrowRight, Settings, SlidersHorizontal, Sparkles } from "lucide-react";

import { Button } from "@/components/ui/button";
import { CUSTOMIZE_ITEMS } from "@/components/clear/customize";
import { EXAMPLE_RESULTS, EXAMPLE_TEXT, STYLES } from "@/lib/simplify";
import { countEnabled, greeting, usePrefs } from "@/lib/prefs";

export const Route = createFileRoute("/dashboard/")({
  head: () => ({
    meta: [
      { title: "Your CLEAR space — Dashboard" },
      { name: "description", content: "Your personal CLEAR dashboard: Customize how pages look and Simplify what they say." },
      { property: "og:title", content: "Your CLEAR space" },
      { property: "og:description", content: "Make the internet work the way you do." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: DashboardHome,
});

function DashboardHome() {
  const p = usePrefs();
  const on = countEnabled(p.customize);
  const style = STYLES.find((s) => s.v === p.simplify.style)!;
  return (
    <div>
      <header className="glass-strong relative mb-8 overflow-hidden rounded-[2rem] p-8 md:p-10">
        <div className="absolute -right-10 -top-16 h-56 w-72 rounded-[3rem] bg-mist-3/80 blur-2xl" />
        <div className="relative flex items-start justify-between gap-4">
          <div>
            <h1 className="font-display text-4xl font-semibold text-primary md:text-6xl">{greeting(p.name)}</h1>
            <p className="mt-4 max-w-xl text-lg text-muted-foreground">Welcome to your CLEAR space. Make the internet work the way you do.</p>
          </div>
          <Button asChild variant="ghost" size="icon" className="shrink-0 rounded-full bg-mist-1/70" aria-label="My Preferences">
            <Link to="/dashboard/preferences"><Settings /></Link>
          </Button>
        </div>
      </header>

      <div className="grid gap-6 lg:grid-cols-2">
        <section className="glass flex flex-col rounded-[2rem] p-8">
          <p className="text-sm font-semibold uppercase tracking-[0.2em] text-muted-foreground">01 · Customize</p>
          <div className="mt-3 flex items-center gap-3">
            <span className="flex h-12 w-12 items-center justify-center rounded-2xl bg-mist-3 text-primary"><SlidersHorizontal /></span>
            <h2 className="font-display text-3xl font-semibold text-primary">Customize</h2>
          </div>
          <p className="mt-3 text-muted-foreground">Take control of your browsing environment.</p>
          <p className="mt-6 text-sm font-semibold text-primary">{on} of {CUSTOMIZE_ITEMS.length} preferences on</p>
          <ul className="mt-3 flex flex-1 flex-wrap content-start gap-2">
            {CUSTOMIZE_ITEMS.map((c) => (
              <li key={c.key} className={`rounded-full px-3 py-1.5 text-sm ${p.customize[c.key] ? "bg-primary text-primary-foreground" : "bg-mist-2 text-muted-foreground"}`}>{c.label}</li>
            ))}
          </ul>
          {p.rules.length > 0 && <p className="mt-4 text-sm text-muted-foreground">Plus {p.rules.length} saved element rule{p.rules.length > 1 ? "s" : ""}.</p>}
          <Button asChild size="lg" className="mt-8 self-start rounded-full px-7"><Link to="/dashboard/customize">Open Customize <ArrowRight /></Link></Button>
        </section>

        <section className="relative flex flex-col overflow-hidden rounded-[2rem] bg-primary p-8 text-primary-foreground shadow-float">
          <p className="text-sm font-semibold uppercase tracking-[0.2em] opacity-70">02 · Simplify</p>
          <div className="mt-3 flex items-center gap-3">
            <span className="flex h-12 w-12 items-center justify-center rounded-2xl bg-mist-1/15"><Sparkles /></span>
            <h2 className="font-display text-3xl font-semibold">Simplify</h2>
          </div>
          <p className="mt-3 opacity-85">Make complicated information easier to understand.</p>
          <div className="mt-6 flex-1 space-y-2 text-sm">
            <p className="rounded-2xl bg-mist-1/10 p-4 opacity-90">“{EXAMPLE_TEXT}”</p>
            <ArrowDown className="mx-auto h-4 w-4 opacity-70" />
            <p className="rounded-2xl bg-mist-1/20 p-4 whitespace-pre-line"><b className="block pb-1 text-xs uppercase tracking-wider opacity-70">{style.label} · example</b>{EXAMPLE_RESULTS[style.v].explanation}</p>
          </div>
          <Button asChild size="lg" variant="secondary" className="mt-8 self-start rounded-full px-7"><Link to="/dashboard/simplify">Open Simplify <ArrowRight /></Link></Button>
        </section>
      </div>
    </div>
  );
}
