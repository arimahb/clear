import { createFileRoute } from "@tanstack/react-router";
import { PageHero, SiteShell } from "@/components/clear/SiteChrome";

export const Route = createFileRoute("/privacy")({
  head: () => ({
    meta: [
      { title: "Privacy — CLEAR" },
      { name: "description", content: "How the CLEAR prototype handles your preferences and the text you ask it to explain." },
      { property: "og:title", content: "CLEAR privacy" },
      { property: "og:description", content: "Your preferences stay in your browser. Text you explain is sent only when you ask." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: () => (
    <SiteShell>
      <PageHero eyebrow="Privacy" title="Your space stays yours." />
      <div className="glass mx-auto mb-24 max-w-3xl space-y-5 rounded-[2rem] p-8 md:p-12">
        <p><b className="text-primary">Preferences:</b> your name and settings are saved only in this browser. There are no accounts.</p>
        <p><b className="text-primary">Explanations and CLEAR Voice:</b> when you press Explain or send a question, that text is sent to an AI service to create the answer. It isn't stored by CLEAR.</p>
        <p><b className="text-primary">Page Forecast:</b> when you scan an address, CLEAR fetches that public page once to count what's on it.</p>
        <p className="text-sm text-muted-foreground">This is a prototype privacy summary, not a legal policy.</p>
      </div>
    </SiteShell>
  ),
});
