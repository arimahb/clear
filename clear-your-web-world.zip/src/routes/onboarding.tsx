import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { ArrowLeft, ArrowRight } from "lucide-react";
import { useEffect, useState } from "react";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Logo } from "@/components/clear/Logo";
import { DEFAULT_PREFS, getPrefs, setPrefs, type SimplifyStyle } from "@/lib/prefs";
import { STYLES } from "@/lib/simplify";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/onboarding")({
  head: () => ({
    meta: [
      { title: "Welcome to CLEAR — Set up your space" },
      { name: "description", content: "A few quick, optional questions to personalise your CLEAR experience." },
      { property: "og:title", content: "Set up CLEAR" },
      { property: "og:description", content: "Personalise how CLEAR customizes pages and explains things." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Onboarding,
});

function Choice<T extends string>({ value, onChange, options }: { value: T; onChange: (v: T) => void; options: { v: T; label: string; hint: string }[] }) {
  return (
    <div className="grid gap-3" role="radiogroup">
      {options.map((o) => (
        <button
          key={o.v}
          type="button"
          role="radio"
          aria-checked={value === o.v}
          onClick={() => onChange(o.v)}
          className={cn("rounded-2xl border p-4 text-left transition", value === o.v ? "border-primary bg-mist-3 shadow-soft" : "border-mist-4 bg-mist-1/60 hover:bg-mist-2")}
        >
          <span className="block font-semibold text-primary">{o.label}</span>
          <span className="text-sm text-muted-foreground">{o.hint}</span>
        </button>
      ))}
    </div>
  );
}

function Onboarding() {
  const navigate = useNavigate();
  const [step, setStep] = useState(0);
  const [name, setName] = useState("");
  useEffect(() => setName(getPrefs().name), []);
  const [style, setStyle] = useState<SimplifyStyle>("simpler");
  const [visual, setVisual] = useState<"calm" | "standard">("calm");
  const [length, setLength] = useState<"concise" | "detailed">("concise");
  const [format, setFormat] = useState<"examples" | "steps">("steps");

  const finish = () => {
    const calm = visual === "calm";
    setPrefs((p) => ({
      ...p,
      name: name.trim(),
      explanationStyle: length === "concise" ? "direct" : "detailed",
      simplify: { ...p.simplify, style, concise: length === "concise", detailed: length === "detailed", examples: format === "examples", numbered: format === "steps" },
      customize: { ...p.customize, ads: calm, autoplay: calm, animations: calm, popups: calm },
      sensory: { ...p.sensory, reduceAnimations: calm },
      onboarded: true,
    }));
    navigate({ to: "/dashboard" });
  };
  const skip = () => {
    setPrefs((p) => ({ ...DEFAULT_PREFS, name: p.name, onboarded: true }));
    navigate({ to: "/dashboard" });
  };

  const steps = [
    {
      title: "What should CLEAR call you?",
      body: (
        <div>
          <label htmlFor="name" className="text-sm text-muted-foreground">Display name (optional)</label>
          <Input id="name" value={name} onChange={(e) => setName(e.target.value)} maxLength={40} placeholder="Your name" className="mt-2 h-12 rounded-xl bg-mist-1/80 text-lg" autoFocus />
        </div>
      ),
    },
    {
      title: "How do you like things explained?",
      body: <Choice value={style} onChange={setStyle} options={STYLES.map((x) => ({ v: x.v, label: x.label, hint: x.hint }))} />,
    },
    {
      title: "Which visual settings suit you?",
      body: <Choice value={visual} onChange={setVisual} options={[{ v: "calm", label: "Fewer distractions", hint: "Calm ads, autoplay, pop-ups and movement." }, { v: "standard", label: "Keep pages as they are", hint: "Turn things on later in Customize." }]} />,
    },
    {
      title: "Concise or detailed explanations?",
      body: <Choice value={length} onChange={setLength} options={[{ v: "concise", label: "Concise", hint: "Just the key points." }, { v: "detailed", label: "Detailed", hint: "More context and background." }]} />,
    },
    {
      title: "Examples or step-by-step?",
      body: <Choice value={format} onChange={setFormat} options={[{ v: "steps", label: "Step-by-step", hint: "Numbered steps I can follow." }, { v: "examples", label: "Examples", hint: "Practical, real-life examples." }]} />,
    },
  ];
  const last = step === steps.length - 1;

  return (
    <div className="flex min-h-screen flex-col items-center px-4 py-8 font-sans">
      <Logo />
      <main className="glass-strong mt-10 w-full max-w-lg rounded-[2rem] p-8 md:p-10">
        <p className="text-sm text-muted-foreground">Step {step + 1} of {steps.length}</p>
        <div className="mt-3 flex gap-1.5" aria-hidden>
          {steps.map((_, i) => <span key={i} className={cn("h-1.5 flex-1 rounded-full", i <= step ? "bg-primary" : "bg-mist-4")} />)}
        </div>
        <h1 className="mt-8 font-display text-3xl font-semibold text-primary">{steps[step]!.title}</h1>
        <div className="mt-6">{steps[step]!.body}</div>
        <div className="mt-8 flex items-center justify-between gap-3">
          {step > 0 ? (
            <Button variant="ghost" onClick={() => setStep(step - 1)}><ArrowLeft /> Back</Button>
          ) : (
            <Button variant="ghost" asChild><Link to="/download"><ArrowLeft /> Back</Link></Button>
          )}
          <Button className="rounded-full px-6" onClick={() => (last ? finish() : setStep(step + 1))}>
            {last ? "Enter my CLEAR space" : "Continue"} <ArrowRight />
          </Button>
        </div>
      </main>
      <button type="button" onClick={skip} className="mt-6 text-sm text-muted-foreground underline underline-offset-4 hover:text-primary">
        Skip and use default settings
      </button>
    </div>
  );
}
