import { z } from "zod";

export const EXPLAIN_STYLES = ["simpler", "steps", "example", "summary", "detail"] as const;
export type ExplainStyle = (typeof EXPLAIN_STYLES)[number];

export const UNDERSTANDING_PREFS = ["simple", "numbered", "examples", "concise", "context", "detailed"] as const;
export type UnderstandingPref = (typeof UNDERSTANDING_PREFS)[number];

export const MAX_SELECTION_CHARS = 4000;
export const MAX_CONTEXT_CHARS = 1500;

export const explainRequestSchema = z.object({
  text: z.string().trim().min(2).max(MAX_SELECTION_CHARS),
  style: z.enum(EXPLAIN_STYLES).default("simpler"),
  prefs: z.array(z.enum(UNDERSTANDING_PREFS)).max(UNDERSTANDING_PREFS.length).default([]),
  context: z.string().max(MAX_CONTEXT_CHARS).optional(),
  pageTitle: z.string().max(300).optional(),
});
export type ExplainRequest = z.infer<typeof explainRequestSchema>;

export type ExplainResult = {
  explanation: string;
  keyTerms: { term: string; meaning: string }[];
  says: string;
  implies: string;
  ambiguity: string[];
};

const STYLE_GUIDE: Record<ExplainStyle, string> = {
  simpler: "Rewrite the meaning in plain, everyday language (about a 12-year-old reading level). Keep it to a short paragraph.",
  steps: "Break the meaning into a numbered list of short, ordered steps (1., 2., 3.). One idea per step.",
  example: "Explain it through one concrete, real-life example the reader can picture, then one sentence linking the example back to the text.",
  summary: "Give a one or two sentence summary of the core point. Nothing more.",
  detail: "Explain it thoroughly: what each part means, why it matters, and how the parts connect. Use short paragraphs.",
};

const PREF_GUIDE: Record<UnderstandingPref, string> = {
  simple: "Prefer simple words over technical terminology.",
  numbered: "Prefer numbered steps over paragraphs where it fits.",
  examples: "Include a short practical example where it helps.",
  concise: "Keep everything as concise as possible.",
  context: "Start with one sentence of background context before explaining.",
  detailed: "Lean towards a fuller explanation with more depth.",
};

export const EXPLAIN_INSTRUCTIONS = `You are CLEAR. Explain highlighted web text in the requested style.
Rules: keep key terms and explain them; never drop difficult ideas; separate what the text SAYS from what it IMPLIES; flag ambiguity, never invent facts; no opinions, no markdown.
Reply in exactly this format:
EXPLANATION:
<explanation in the requested style>
KEY TERMS:
- <term> :: <plain meaning> (0-3 terms)
SAYS:
<1-2 sentences>
IMPLIES:
<1-2 sentences, or "Nothing beyond what it says.">
AMBIGUITY:
- <unclear point, or "- None">`;

export function buildExplainPrompt(req: ExplainRequest): string {
  const prefs = req.prefs.map((p) => `- ${PREF_GUIDE[p]}`).join("\n");
  return [
    `Explanation style: ${STYLE_GUIDE[req.style]}`,
    prefs ? `Reader preferences:\n${prefs}` : "",
    req.pageTitle ? `Page title: ${req.pageTitle}` : "",
    req.context ? `Context only (do not explain):\n"""${req.context}"""` : "",
    `Text to explain:\n"""${req.text}"""`,
  ]
    .filter(Boolean)
    .join("\n\n");
}

const LABELS = ["EXPLANATION", "KEY TERMS", "SAYS", "IMPLIES", "AMBIGUITY"] as const;

export function parseExplainOutput(raw: string): ExplainResult {
  const sections: Record<string, string> = {};
  const pattern = new RegExp(`^\\s*(${LABELS.join("|")})\\s*:\\s*`, "gim");
  const marks: { label: string; start: number; end: number }[] = [];
  let m: RegExpExecArray | null;
  while ((m = pattern.exec(raw))) {
    marks.push({ label: (m[1] ?? "").toUpperCase(), start: m.index, end: m.index + m[0].length });
  }
  if (marks.length === 0) {
    return { explanation: raw.trim(), keyTerms: [], says: "", implies: "", ambiguity: [] };
  }
  marks.forEach((mark, i) => {
    const next = marks[i + 1]?.start ?? raw.length;
    sections[mark.label] = raw.slice(mark.end, next).trim();
  });
  const bullets = (s = "") =>
    s
      .split("\n")
      .map((l) => l.replace(/^\s*[-*•]\s*/, "").trim())
      .filter(Boolean);
  const keyTerms = bullets(sections["KEY TERMS"])
    .map((l) => {
      const [term, ...rest] = l.split(/\s*(?:::|—|–| - |:)\s*/);
      return { term: (term ?? "").trim(), meaning: rest.join(" ").trim() };
    })
    .filter((t) => t.term && t.meaning);
  const ambiguity = bullets(sections["AMBIGUITY"]).filter((l) => !/^none\.?$/i.test(l));
  return {
    explanation: sections["EXPLANATION"] ?? "",
    keyTerms,
    says: sections["SAYS"] ?? "",
    implies: sections["IMPLIES"] ?? "",
    ambiguity,
  };
}
