import type { Prefs, SimplifyStyle } from "./prefs";

export type SimplifyResult = { explanation: string; terms: { term: string; meaning: string }[]; notes: string[] };

export const STYLES: { v: SimplifyStyle; label: string; hint: string }[] = [
  { v: "simpler", label: "Simpler Language", hint: "Replace complicated terminology with easier words." },
  { v: "steps", label: "Step-by-Step", hint: "Break it into clear, numbered steps." },
  { v: "example", label: "Real-Life Example", hint: "Use a practical example to explain it." },
  { v: "summary", label: "Short Summary", hint: "Only the most important information." },
  { v: "detail", label: "Explain in Detail", hint: "A thorough explanation with extra context." },
];

const STYLE_GUIDE: Record<SimplifyStyle, string> = {
  simpler: "Rewrite it in plain, everyday language. Replace jargon with simpler words.",
  steps: "Explain it as a short numbered list of steps (one per line, starting '1.', '2.', ...).",
  example: "Explain it with one practical, real-life example, then one sentence linking back to the original.",
  summary: "Give only the most important point in one or two short sentences.",
  detail: "Give a thorough explanation with helpful background and context, in short paragraphs.",
};

export function simplifyInstructions(style: SimplifyStyle, p: Omit<Prefs["simplify"], "style">) {
  const extra = [
    p.simple && "Prefer simple words over technical terminology.",
    p.numbered && "Prefer numbered steps over paragraphs where it fits.",
    p.examples && "Include a practical example where it helps.",
    p.concise && "Keep it concise.",
    p.context && "Add brief context when it helps understanding.",
    p.detailed && "Lean towards a fuller explanation.",
  ].filter(Boolean).join(" ");
  return `You are CLEAR, an assistant that makes information easier to understand without changing its meaning.
${STYLE_GUIDE[style]} ${extra}
Rules: preserve the meaning and important terminology; explain difficult concepts rather than removing them; distinguish facts from interpretations; never invent information; flag ambiguous wording.
Return ONLY JSON: {"explanation": string, "terms": [{"term": string, "meaning": string}], "notes": string[]}
- terms: 0-3 important words from the original that were kept, with a plain meaning.
- notes: 0-2 notes about ambiguous wording or missing information. Empty if none.`;
}

export function parseSimplify(raw: string): SimplifyResult {
  try {
    const o = JSON.parse(raw.match(/\{[\s\S]*\}/)?.[0] ?? "");
    return {
      explanation: String(o.explanation ?? ""),
      terms: Array.isArray(o.terms) ? o.terms.map((t: { term?: unknown; meaning?: unknown }) => ({ term: String(t.term ?? ""), meaning: String(t.meaning ?? "") })).filter((t: { term: string }) => t.term) : [],
      notes: Array.isArray(o.notes) ? o.notes.map(String).filter(Boolean) : [],
    };
  } catch {
    return { explanation: raw, terms: [], notes: [] };
  }
}

export const EXAMPLE_TEXT = "The deadline is contingent upon the successful completion of the preliminary assessment.";

/** Clearly labelled, pre-written examples for the sample sentence. */
export const EXAMPLE_RESULTS: Record<SimplifyStyle, SimplifyResult> = {
  simpler: {
    explanation: "You can only meet the deadline once the first check has been finished and passed.",
    terms: [{ term: "contingent upon", meaning: "depends on" }, { term: "preliminary assessment", meaning: "the first check or review" }],
    notes: [],
  },
  steps: {
    explanation: "1. Complete the preliminary assessment.\n2. Make sure you meet its requirements.\n3. Only then can you meet the deadline.",
    terms: [{ term: "preliminary assessment", meaning: "the first check or review" }],
    notes: [],
  },
  example: {
    explanation: "It's like a driving test: you can't book the road test until you've passed the written test. Here, the deadline only applies once the first assessment is done.",
    terms: [{ term: "contingent upon", meaning: "depends on" }],
    notes: [],
  },
  summary: { explanation: "Finish the first assessment before the deadline matters.", terms: [], notes: [] },
  detail: {
    explanation: "There is a first step, called the preliminary assessment, that has to be completed successfully.\n\nThe deadline depends on that step. Until the assessment is done, the deadline may not apply yet, or may move.",
    terms: [{ term: "contingent upon", meaning: "depends on" }, { term: "preliminary assessment", meaning: "the first check or review" }],
    notes: ["The text doesn't say what happens if the assessment is not passed, or what the deadline date is."],
  },
};
