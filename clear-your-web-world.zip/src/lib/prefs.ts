import { useSyncExternalStore } from "react";

export type ExplanationStyle = "direct" | "detailed";
export type AssistMode = "visual" | "voice";
export type Tone = "gentle" | "neutral" | "direct";

export type SimplifyStyle = "simpler" | "steps" | "example" | "summary" | "detail";
export type CustomizeKey = "ads" | "autoplay" | "animations" | "images" | "popups" | "backgrounds";
export type CustomAction = "blur" | "hide" | "still";
export type CustomRule = { id: string; label: string; action: CustomAction };

export type SensoryPrefs = {
  reduceColors: boolean;
  softContrast: boolean;
  brightness: number; // percent, 80-110
  blueTone: number; // hue, 215-265
  reduceAnimations: boolean;
  pauseVideos: boolean;
  disableTransitions: boolean;
  reduceMovement: boolean;
  simplifyLayout: boolean;
  reduceClutter: boolean;
  extraSpacing: boolean;
  readableText: boolean;
};

export type Prefs = {
  name: string;
  onboarded: boolean;
  explanationStyle: ExplanationStyle;
  assistMode: AssistMode;
  tone: Tone;
  appearance: "misty" | "deeper";
  comm: { literal: boolean; shorter: boolean; multiple: boolean; examples: boolean };
  sensory: SensoryPrefs;
  visual: {
    blueIntensity: number; // percent, 40-160
    background: "fog" | "soft" | "plain";
    fontSize: number; // px, 14-22
    textSpacing: number; // 0-3
    cards: "glass" | "solid";
  };
  voice: { enabled: boolean; readAloud: boolean; rate: number; mode: "voice" | "text" };
  customize: Record<CustomizeKey, boolean>;
  rules: CustomRule[];
  simplify: { style: SimplifyStyle; simple: boolean; numbered: boolean; examples: boolean; concise: boolean; context: boolean; detailed: boolean };
};

export const DEFAULT_CUSTOMIZE: Record<CustomizeKey, boolean> = { ads: true, autoplay: true, animations: false, images: false, popups: true, backgrounds: false };
export const DEFAULT_SIMPLIFY: Prefs["simplify"] = { style: "simpler", simple: true, numbered: false, examples: false, concise: false, context: true, detailed: false };

export function countEnabled(c: Record<string, boolean>) {
  return Object.values(c).filter(Boolean).length;
}

export const DEFAULT_SENSORY: SensoryPrefs = {
  reduceColors: false,
  softContrast: false,
  brightness: 100,
  blueTone: 242,
  reduceAnimations: false,
  pauseVideos: true,
  disableTransitions: false,
  reduceMovement: false,
  simplifyLayout: false,
  reduceClutter: false,
  extraSpacing: false,
  readableText: false,
};

export const DEFAULT_PREFS: Prefs = {
  name: "",
  onboarded: false,
  explanationStyle: "direct",
  assistMode: "visual",
  tone: "gentle",
  appearance: "misty",
  comm: { literal: true, shorter: false, multiple: true, examples: false },
  sensory: DEFAULT_SENSORY,
  visual: { blueIntensity: 100, background: "fog", fontSize: 16, textSpacing: 0, cards: "glass" },
  voice: { enabled: true, readAloud: false, rate: 1, mode: "text" },
  customize: DEFAULT_CUSTOMIZE,
  rules: [],
  simplify: DEFAULT_SIMPLIFY,
};

const KEY = "clear:prefs:v1";

/** Merge stored (possibly partial or outdated) data over defaults, one level deep for groups. */
export function mergePrefs(stored: unknown): Prefs {
  if (!stored || typeof stored !== "object") return DEFAULT_PREFS;
  const s = stored as Partial<Prefs>;
  return {
    ...DEFAULT_PREFS,
    ...s,
    comm: { ...DEFAULT_PREFS.comm, ...(s.comm ?? {}) },
    sensory: { ...DEFAULT_PREFS.sensory, ...(s.sensory ?? {}) },
    visual: { ...DEFAULT_PREFS.visual, ...(s.visual ?? {}) },
    voice: { ...DEFAULT_PREFS.voice, ...(s.voice ?? {}) },
    customize: { ...DEFAULT_CUSTOMIZE, ...(s.customize ?? {}) },
    rules: Array.isArray(s.rules) ? s.rules : [],
    simplify: { ...DEFAULT_SIMPLIFY, ...(s.simplify ?? {}) },
  };
}

export function greeting(name: string) {
  const n = name.trim();
  return n ? `Hello, ${n}.` : "Hello there.";
}

export function initials(name: string) {
  const parts = name.trim().split(/\s+/).filter(Boolean);
  if (!parts.length) return "C";
  return parts.slice(0, 2).map((p) => p[0]!.toUpperCase()).join("");
}

let state: Prefs = DEFAULT_PREFS;
let loaded = false;
const listeners = new Set<() => void>();

function load() {
  if (loaded || typeof window === "undefined") return;
  loaded = true;
  try {
    state = mergePrefs(JSON.parse(window.localStorage.getItem(KEY) ?? "null"));
  } catch {
    state = DEFAULT_PREFS;
  }
}

export function getPrefs() {
  load();
  return state;
}

export function setPrefs(update: Partial<Prefs> | ((p: Prefs) => Prefs)) {
  load();
  state = typeof update === "function" ? update(state) : mergePrefs({ ...state, ...update });
  try {
    window.localStorage.setItem(KEY, JSON.stringify(state));
  } catch {
    /* storage unavailable: keep in memory */
  }
  listeners.forEach((l) => l());
}

function subscribe(l: () => void) {
  listeners.add(l);
  const onStorage = (e: StorageEvent) => {
    if (e.key === KEY) {
      loaded = false;
      load();
      l();
    }
  };
  window.addEventListener("storage", onStorage);
  return () => {
    listeners.delete(l);
    window.removeEventListener("storage", onStorage);
  };
}

/** Saved preferences. Server render and first paint use defaults, then the saved values. */
export function usePrefs(): Prefs {
  return useSyncExternalStore(subscribe, getPrefs, () => DEFAULT_PREFS);
}

/** Apply visual and motion preferences to the whole page. */
export function applyPrefsToDocument(p: Prefs) {
  const root = document.documentElement;
  const s = p.sensory;
  const filters: string[] = [];
  if (s.brightness !== 100) filters.push(`brightness(${s.brightness / 100})`);
  if (s.softContrast) filters.push("contrast(0.92)");
  if (s.reduceColors) filters.push("saturate(0.6)");
  root.style.setProperty("--user-filter", filters.length ? filters.join(" ") : "none");
  root.style.setProperty("--hue", String(s.blueTone));
  const ck = (p.visual.blueIntensity / 100) * (p.appearance === "deeper" ? 1.35 : 1);
  root.style.setProperty("--ck", String(ck));
  const size = p.visual.fontSize + (s.readableText ? 1 : 0);
  root.style.setProperty("--user-font-size", `${size}px`);
  const spacing = p.visual.textSpacing + (s.extraSpacing ? 1 : 0);
  root.style.setProperty("--user-line", String(1.6 + spacing * 0.12 + (s.readableText ? 0.1 : 0)));
  root.style.setProperty("--user-letter", `${spacing * 0.012}em`);
  root.style.setProperty("--user-word", `${spacing * 0.05}em`);
  root.setAttribute("data-anim", s.reduceAnimations ? "off" : "on");
  root.setAttribute("data-transitions", s.disableTransitions ? "off" : "on");
  root.setAttribute("data-movement", s.reduceMovement ? "reduce" : "normal");
  root.setAttribute("data-cards", p.visual.cards);
}
