import { createOpenAI } from "@ai-sdk/openai";
import { streamText } from "ai";

import { createLovableAiGatewayRunIdFetch } from "./run-id.server";
import { buildExplainPrompt, EXPLAIN_INSTRUCTIONS, parseExplainOutput, type ExplainRequest } from "../explain";

const GATEWAY_URL = "https://ai.gateway.lovable.dev/v1";
// Fast tier with reasoning off: measured ~0.5s to first words vs ~1.2-3s with default reasoning.
const MODEL = "openai/gpt-6-luna";

export class ExplainError extends Error {
  constructor(
    message: string,
    public status: number,
  ) {
    super(message);
  }
}

function friendly(error: unknown) {
  const err = error as { statusCode?: number; message?: string } | undefined;
  const status = err?.statusCode ?? 502;
  console.error("explain failed", err?.message ?? err);
  const message =
    status === 402
      ? "AI credits have run out for this workspace."
      : status === 429
        ? "Too many requests right now. Please wait a moment and try again."
        : status === 403
          ? "AI access is currently blocked for this app."
          : "CLEAR couldn't produce an explanation. Please try again.";
  return new ExplainError(message, status);
}

function start(req: ExplainRequest, signal?: AbortSignal) {
  const apiKey = process.env["LOVABLE_API_KEY"];
  if (!apiKey) throw new ExplainError("AI is not configured for this app yet.", 500);
  const runIdFetch = createLovableAiGatewayRunIdFetch();
  const provider = createOpenAI({
    baseURL: GATEWAY_URL,
    apiKey,
    headers: { "Lovable-API-Key": apiKey, "X-Lovable-AIG-SDK": "vercel-ai-sdk" },
    fetch: runIdFetch.fetch,
  });
  const state: { failure?: unknown } = {};
  const result = streamText({
    model: provider.responses(MODEL),
    instructions: EXPLAIN_INSTRUCTIONS,
    prompt: buildExplainPrompt(req),
    ...(signal ? { abortSignal: signal } : {}),
    onError: ({ error }) => {
      state.failure = error;
    },
    providerOptions: { openai: { forceReasoning: true, reasoningEffort: "none", store: false } },
  });
  return { result, state, runIdFetch };
}

/** Streams raw model text; resolves only once the first words arrive so errors can still use real HTTP statuses. */
export async function streamExplain(req: ExplainRequest, signal?: AbortSignal) {
  const t0 = Date.now();
  const { result, state, runIdFetch } = start(req, signal);
  const it = result.textStream[Symbol.asyncIterator]();
  let first: IteratorResult<string>;
  try {
    do first = await it.next();
    while (!first.done && !first.value);
  } catch (e) {
    throw friendly(e);
  }
  if (first.done) throw friendly(state.failure);
  const ttft = Date.now() - t0;
  const enc = new TextEncoder();
  const stream = new ReadableStream<Uint8Array>({
    start(c) {
      c.enqueue(enc.encode(first.value as string));
    },
    async pull(c) {
      try {
        const n = await it.next();
        if (n.done) {
          if (state.failure) c.enqueue(enc.encode(`\n\u0000ERROR:${friendly(state.failure).message}`));
          console.log(`explain timing ttft=${ttft}ms total=${Date.now() - t0}ms len=${req.text.length}`);
          c.close();
        } else c.enqueue(enc.encode(n.value));
      } catch (e) {
        c.enqueue(enc.encode(`\n\u0000ERROR:${friendly(e).message}`));
        c.close();
      }
    },
    cancel() {
      void it.return?.();
    },
  });
  return { stream, ttft, runId: runIdFetch.getRunId() };
}

export async function runExplain(req: ExplainRequest, signal?: AbortSignal) {
  const t0 = Date.now();
  const { result, state, runIdFetch } = start(req, signal);
  let text = "";
  try {
    text = await result.text;
  } catch (error) {
    state.failure ??= error;
  }
  if (state.failure || !text.trim()) throw friendly(state.failure);
  return { result: parseExplainOutput(text), runId: runIdFetch.getRunId(), ms: Date.now() - t0 };
}
