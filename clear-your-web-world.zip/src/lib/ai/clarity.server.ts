import { createOpenAI } from "@ai-sdk/openai";
import { generateText } from "ai";

import { createLovableAiGatewayRunIdFetch } from "./run-id.server";

const MODEL = "openai/gpt-6-astra";

export class AiError extends Error {}

function provider() {
  const apiKey = process.env["LOVABLE_API_KEY"];
  if (!apiKey) throw new AiError("CLEAR's AI isn't set up for this app yet.");
  return createOpenAI({
    baseURL: "https://ai.gateway.lovable.dev/v1",
    apiKey,
    headers: { "Lovable-API-Key": apiKey, "X-Lovable-AIG-SDK": "vercel-ai-sdk" },
    fetch: createLovableAiGatewayRunIdFetch().fetch,
  });
}

function friendly(error: unknown): never {
  const status = (error as { statusCode?: number })?.statusCode;
  console.error("ai failed", (error as Error)?.message ?? error);
  if (error instanceof AiError) throw error;
  throw new AiError(
    status === 402
      ? "AI credits have run out for this workspace."
      : status === 429
        ? "CLEAR is getting a lot of requests. Please wait a moment and try again."
        : "CLEAR couldn't answer just now. Please try again.",
  );
}

export async function generate(instructions: string, prompt: string) {
  try {
    const { text } = await generateText({
      model: provider().responses(MODEL),
      instructions,
      prompt,
      providerOptions: { openai: { reasoningEffort: "low", store: false } },
    });
    if (!text.trim()) throw new AiError("CLEAR couldn't answer just now. Please try again.");
    return text.trim();
  } catch (e) {
    friendly(e);
  }
}
