import { describe, expect, it } from "vitest";
import { analyzeHtml, normalizeUrl } from "./forecast";

describe("analyzeHtml", () => {
  it("counts videos, autoplay and images present in the page", () => {
    const html = `<title>T</title><video autoplay></video><iframe src="https://youtube.com/embed/x"></iframe><img src=a.gif><img src=b.png><h2>A</h2><h2>B</h2><p>${"word ".repeat(460)}</p>`;
    const f = analyzeHtml(html, "https://x.com");
    expect(f.videos).toBe(2);
    expect(f.autoplay).toBe(1);
    expect(f.images).toBe(2);
    expect(f.animations).toBe(1);
    expect(f.sections).toBe(2);
    expect(f.readingMinutes).toBe(2);
    expect(f.source).toBe("scan");
  });
});

describe("normalizeUrl", () => {
  it("adds https to bare addresses", () => {
    expect(normalizeUrl("example.com")?.href).toBe("https://example.com/");
  });
  it("refuses private and local addresses", () => {
    expect(normalizeUrl("http://localhost:8080")).toBeNull();
    expect(normalizeUrl("http://192.168.1.4")).toBeNull();
    expect(normalizeUrl("ftp://example.com")).toBeNull();
  });
});
