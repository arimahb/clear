import { describe, expect, it } from "vitest";
import { DEFAULT_PREFS, greeting, mergePrefs } from "./prefs";

describe("greeting", () => {
  it("uses the saved display name", () => {
    expect(greeting("Ashley")).toBe("Hello, Ashley.");
  });
  it("says 'Hello there.' when no name has been given", () => {
    expect(greeting("")).toBe("Hello there.");
    expect(greeting("   ")).toBe("Hello there.");
  });
});

describe("mergePrefs", () => {
  it("keeps saved values and fills in missing ones with defaults", () => {
    const p = mergePrefs({ name: "Sam", sensory: { reduceAnimations: true } });
    expect(p.name).toBe("Sam");
    expect(p.sensory.reduceAnimations).toBe(true);
    expect(p.sensory.brightness).toBe(DEFAULT_PREFS.sensory.brightness);
    expect(p.voice.rate).toBe(1);
  });
  it("falls back to defaults for unreadable data", () => {
    expect(mergePrefs(null)).toEqual(DEFAULT_PREFS);
  });
});

import { countEnabled, DEFAULT_CUSTOMIZE } from "./prefs";
describe("customize prefs", () => {
  it("counts enabled preferences", () => {
    expect(countEnabled({ a: true, b: false, c: true })).toBe(2);
  });
  it("fills new customize and simplify defaults for old saved data", () => {
    const p = mergePrefs({ name: "Sam" });
    expect(p.customize).toEqual(DEFAULT_CUSTOMIZE);
    expect(p.simplify.style).toBe("simpler");
    expect(p.rules).toEqual([]);
  });
});
