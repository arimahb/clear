export type Level = "Low" | "Medium" | "High";

export type Forecast = {
  source: "sample" | "scan";
  title: string;
  url: string;
  readingMinutes: number;
  words: number;
  videos: number;
  autoplay: number;
  animations: number;
  images: number;
  sections: number;
  textAmount: Level;
  complexity: number; // 0-100
  complexityLevel: Level;
  distractions: string[];
  summary: string;
};

const count = (html: string, re: RegExp) => (html.match(re) ?? []).length;
const level = (n: number, mid: number, high: number): Level => (n >= high ? "High" : n >= mid ? "Medium" : "Low");

/** Build a forecast from facts counted on a page. */
export function buildForecast(
  f: Pick<Forecast, "title" | "url" | "words" | "videos" | "autoplay" | "animations" | "images" | "sections"> & {
    popups: number;
    ads: number;
  },
  source: Forecast["source"],
): Forecast {
  const readingMinutes = Math.max(1, Math.round(f.words / 230));
  const complexity = Math.min(
    100,
    Math.round(f.videos * 8 + f.autoplay * 12 + f.animations * 5 + f.images * 1.2 + f.sections * 2 + f.popups * 10 + f.ads * 6 + f.words / 150),
  );
  const distractions: string[] = [];
  if (f.autoplay) distractions.push(`${f.autoplay} video${f.autoplay > 1 ? "s" : ""} may play on their own`);
  if (f.animations) distractions.push(`${f.animations} moving element${f.animations > 1 ? "s" : ""} (animations or GIFs)`);
  if (f.popups) distractions.push("Pop-ups or sign-up boxes may appear");
  if (f.ads) distractions.push("Advertising spaces on the page");
  if (f.images > 25) distractions.push("Many images");
  const complexityLevel = level(complexity, 35, 65);
  const textAmount = level(f.words, 600, 1800);
  const summary =
    `Expect about ${readingMinutes} minute${readingMinutes > 1 ? "s" : ""} of reading across ${f.sections || 1} section${f.sections === 1 ? "" : "s"}. ` +
    (complexityLevel === "Low"
      ? "This page looks calm and fairly simple."
      : complexityLevel === "Medium"
        ? "This page has a moderate amount going on."
        : "This page looks busy. You may want Sensory Settings on before opening it.");
  return { ...f, source, readingMinutes, complexity, complexityLevel, textAmount, distractions, summary };
}

/** Count what's in a page's HTML. Only counts things present in the markup itself. */
export function analyzeHtml(html: string, url: string): Forecast {
  const title = (html.match(/<title[^>]*>([^<]*)<\/title>/i)?.[1] ?? url).trim().slice(0, 140);
  const body = html
    .replace(/<script[\s\S]*?<\/script>/gi, " ")
    .replace(/<style[\s\S]*?<\/style>/gi, " ")
    .replace(/<noscript[\s\S]*?<\/noscript>/gi, " ")
    .replace(/<[^>]+>/g, " ")
    .replace(/&[a-z#0-9]+;/gi, " ");
  const words = body.split(/\s+/).filter((w) => /[a-z0-9]/i.test(w)).length;
  const videos = count(html, /<video\b/gi) + count(html, /<iframe[^>]+(youtube|vimeo|player|video)/gi);
  const autoplay = count(html, /<(video|iframe)[^>]*autoplay/gi);
  const animations = count(html, /\.gif\b/gi) + count(html, /<marquee\b/gi) + count(html, /@keyframes\b/gi) + count(html, /lottie/gi);
  const images = count(html, /<img\b/gi);
  const sections = Math.max(count(html, /<h2\b/gi), count(html, /<section\b/gi));
  const popups = Math.min(3, count(html, /class="[^"]*(modal|popup|newsletter|overlay)[^"]*"/gi));
  const ads = Math.min(5, count(html, /(googlesyndication|doubleclick|adsbygoogle|class="[^"]*\bad-(slot|unit|banner))/gi));
  return buildForecast({ title, url, words, videos, autoplay, animations, images, sections, popups, ads }, "scan");
}

export const SAMPLE_FORECASTS: Forecast[] = [
  buildForecast({ title: "Sample: Busy news homepage", url: "news.example", words: 2400, videos: 6, autoplay: 2, animations: 5, images: 48, sections: 12, popups: 1, ads: 4 }, "sample"),
  buildForecast({ title: "Sample: Recipe blog post", url: "recipes.example", words: 1500, videos: 1, autoplay: 1, animations: 2, images: 14, sections: 7, popups: 1, ads: 3 }, "sample"),
  buildForecast({ title: "Sample: Encyclopedia article", url: "wiki.example", words: 3200, videos: 0, autoplay: 0, animations: 0, images: 6, sections: 9, popups: 0, ads: 0 }, "sample"),
];

const PRIVATE_HOST = /^(localhost|0\.0\.0\.0|127\.|10\.|192\.168\.|169\.254\.|172\.(1[6-9]|2\d|3[01])\.|\[?::1\]?$|\[?f[cd])|\.(local|internal|localhost)$/i;

/** Normalise a typed address and reject anything that isn't a public web page. */
export function normalizeUrl(input: string): URL | null {
  let raw = input.trim();
  if (!raw) return null;
  if (!/^https?:\/\//i.test(raw)) raw = `https://${raw}`;
  try {
    const u = new URL(raw);
    if (!/^https?:$/.test(u.protocol) || PRIVATE_HOST.test(u.hostname) || !u.hostname.includes(".")) return null;
    return u;
  } catch {
    return null;
  }
}
