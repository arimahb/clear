import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";

import { CLARITY_INSTRUCTIONS, clarityPrefsSchema, parseClarity, prefsToGuide } from "./clarity";
import { analyzeHtml, normalizeUrl } from "./forecast";

type Ok<T> = { ok: true; data: T };
type Fail = { ok: false; error: string };

async function guard<T>(fn: () => Promise<T>): Promise<Ok<T> | Fail> {
  try {
    return { ok: true, data: await fn() };
  } catch (e) {
    const { AiError } = await import("./ai/clarity.server");
    return { ok: false, error: e instanceof AiError ? e.message : "Something went wrong. Please try again." };
  }
}

export const explainMessage = createServerFn({ method: "POST" })
  .inputValidator(z.object({ message: z.string().trim().min(2).max(3000), prefs: clarityPrefsSchema }))
  .handler(async ({ data }) =>
    guard(async () => {
      const { generate } = await import("./ai/clarity.server");
      const text = await generate(`${CLARITY_INSTRUCTIONS}\n${prefsToGuide(data.prefs)}`, `Message:\n"""${data.message}"""`);
      return parseClarity(text);
    }),
  );

export const forecastUrl = createServerFn({ method: "POST" })
  .inputValidator(z.object({ url: z.string().max(2000) }))
  .handler(async ({ data }): Promise<Ok<ReturnType<typeof analyzeHtml>> | Fail> => {
    const url = normalizeUrl(data.url);
    if (!url) return { ok: false, error: "Please enter a public web address, like wikipedia.org." };
    try {
      const res = await fetch(url.href, {
        headers: { "User-Agent": "CLEAR-PageForecast/0.1", Accept: "text/html" },
        redirect: "follow",
        signal: AbortSignal.timeout(9000),
      });
      if (!res.ok) return { ok: false, error: `That page answered with an error (${res.status}). Try another address.` };
      if (!(res.headers.get("content-type") ?? "").includes("html")) return { ok: false, error: "That address isn't a normal webpage." };
      const html = (await res.text()).slice(0, 2_000_000);
      return { ok: true, data: analyzeHtml(html, url.href) };
    } catch {
      return { ok: false, error: "CLEAR couldn't reach that page. It may block scanners or be offline." };
    }
  });
