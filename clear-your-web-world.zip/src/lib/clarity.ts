import { z } from "zod";

export const clarityPrefsSchema = z.object({
  style: z.enum(["direct", "detailed"]).default("direct"),
  tone: z.enum(["gentle", "neutral", "direct"]).default("gentle"),
  literal: z.boolean().default(true),
  shorter: z.boolean().default(false),
  multiple: z.boolean().default(true),
  examples: z.boolean().default(false),
});
export type ClarityPrefs = z.infer<typeof clarityPrefsSchema>;

export type ClarityResult = {
  literal: string;
  underlying: string[];
  tone: string[];
  asking: string;
  responses: string[];
};

export function prefsToGuide(p: ClarityPrefs) {
  return [
    p.style === "direct" ? "Keep explanations direct and simple." : "Give fuller, more detailed explanations.",
    p.literal && "Use literal, concrete language. Avoid idioms and figures of speech in your own words.",
    p.shorter && "Keep every part short.",
    p.multiple && "Offer more than one possible interpretation where it makes sense.",
    p.examples && "Add context and a short example where helpful.",
    `Use a ${p.tone} tone.`,
  ]
    .filter(Boolean)
    .join(" ");
}

export const CLARITY_INSTRUCTIONS = `You are CLEAR, a calm assistant that helps people understand written messages.
Never claim to know what the sender thinks or feels. Use phrasing like "They might mean..." or "One possible interpretation is...".
Explain sarcasm, idioms, indirect requests and tone cues plainly. Return ONLY JSON with this shape:
{"literal": string, "underlying": string[], "tone": string[], "asking": string, "responses": string[]}
- literal: what the words directly say.
- underlying: 1-3 possible underlying meanings, each starting with "They might mean" or "One possible interpretation is".
- tone: 1-3 possible tone cues, hedged ("This could sound...").
- asking: what they might be asking or expecting, or "There may be no request here." 
- responses: 2-3 short replies the reader could send.`;

export function parseClarity(raw: string): ClarityResult {
  const json = raw.match(/\{[\s\S]*\}/)?.[0];
  const list = (v: unknown) => (Array.isArray(v) ? v.map(String).filter(Boolean) : typeof v === "string" ? [v] : []);
  try {
    const o = JSON.parse(json ?? "");
    return {
      literal: String(o.literal ?? ""),
      underlying: list(o.underlying),
      tone: list(o.tone),
      asking: String(o.asking ?? ""),
      responses: list(o.responses),
    };
  } catch {
    return { literal: raw, underlying: [], tone: [], asking: "", responses: [] };
  }
}

/** Clearly labelled example explanations, shown on request when the AI is unavailable. */
export const SAMPLE_CLARITY: { message: string; result: ClarityResult }[] = [
  {
    message: "Great, another meeting that could have been an email.",
    result: {
      literal: "They are saying there is another meeting, and that it could have been sent as an email instead.",
      underlying: [
        "They might mean they are frustrated about having to attend a meeting.",
        "One possible interpretation is that they think meetings like this waste time.",
      ],
      tone: ["The word \"Great\" here could be sarcastic: it may mean the opposite of great.", "This could sound tired or annoyed rather than angry."],
      asking: "There may be no request here. They might just want someone to agree with them.",
      responses: ["Ha, I know what you mean.", "Want me to ask if we can do it by email next time?", "Yes, it's been a busy week for meetings."],
    },
  },
  {
    message: "No worries if not, but it'd be amazing if you could take a look at this by Friday.",
    result: {
      literal: "They are asking you to look at something by Friday, and saying it's fine if you can't.",
      underlying: [
        "They might mean they really do want it done by Friday, but are asking politely.",
        "One possible interpretation is that it's a soft deadline and they would understand a delay.",
      ],
      tone: ["This could sound friendly and polite.", "\"No worries if not\" is often a softener, not a real offer to skip it."],
      asking: "They are likely asking you to review it by Friday, or to tell them if you can't.",
      responses: ["Sure, I'll have a look by Friday.", "I can do it, but Monday would be easier. Does that work?", "I don't think I'll have time this week. Can someone else help?"],
    },
  },
];
