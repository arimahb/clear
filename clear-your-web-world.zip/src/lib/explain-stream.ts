import { parseExplainOutput, type ExplainResult } from "./explain";

/** Streams an explanation from CLEAR's endpoint, calling onPartial as words arrive. */
export async function streamExplanation(
  url: string,
  payload: { text: string; style: string; prefs: string[]; context?: string; pageTitle?: string },
  onPartial: (r: ExplainResult) => void,
  signal?: AbortSignal,
): Promise<ExplainResult> {
  const res = await fetch(url, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ ...payload, stream: true }),
    ...(signal ? { signal } : {}),
  });
  if (!res.ok || !res.body) {
    const data = (await res.json().catch(() => null)) as { error?: string } | null;
    throw new Error(data?.error ?? `CLEAR's AI service didn't respond (${res.status}).`);
  }
  const reader = res.body.getReader();
  const dec = new TextDecoder();
  let raw = "";
  for (;;) {
    const { done, value } = await reader.read();
    if (done) break;
    raw += dec.decode(value, { stream: true });
    const cut = raw.indexOf("\u0000ERROR:");
    if (cut !== -1) throw new Error(raw.slice(cut + 7).trim() || "CLEAR couldn't finish the explanation.");
    onPartial(parseExplainOutput(raw));
  }
  const final = parseExplainOutput(raw);
  if (!final.explanation.trim()) throw new Error("CLEAR couldn't produce an explanation. Please try again.");
  return final;
}
