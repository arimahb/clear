import { usePrefs } from "@/lib/prefs";

/** The foggy window: layered, blurred panes of light behind every page. */
export function FogBackground() {
  const { visual } = usePrefs();
  if (visual.background === "plain") return <div aria-hidden className="fixed inset-0 -z-10 bg-background" />;
  const soft = visual.background === "soft";
  return (
    <div aria-hidden className="pointer-events-none fixed inset-0 -z-10 overflow-hidden bg-gradient-to-br from-mist-1 via-mist-2 to-mist-4">
      <div className="absolute -left-[10%] -top-[15%] h-[60vh] w-[55vw] animate-drift rounded-full bg-mist-1 opacity-90 blur-[90px]" />
      <div className="absolute -right-[8%] top-[20%] h-[55vh] w-[45vw] animate-drift rounded-full bg-mist-5 opacity-50 blur-[110px] [animation-delay:-9s]" />
      <div className="absolute bottom-[-20%] left-[25%] h-[50vh] w-[50vw] animate-drift rounded-full bg-mist-3 opacity-80 blur-[100px] [animation-delay:-16s]" />
      {!soft && (
        <>
          {/* window panes */}
          <div className="absolute left-[6%] top-[9%] h-[38vh] w-[30vw] rounded-[2.5rem] border border-mist-1/70 bg-mist-1/25 backdrop-blur-md" />
          <div className="absolute left-[38%] top-[4%] h-[30vh] w-[22vw] rounded-[2rem] border border-mist-1/50 bg-mist-1/15 blur-[1px] backdrop-blur-sm" />
          <div className="absolute right-[5%] top-[12%] h-[46vh] w-[24vw] rounded-[3rem] bg-mist-1/20 blur-[2px]" />
          <div className="absolute bottom-[6%] left-[10%] h-[34vh] w-[26vw] rounded-[3rem] border border-mist-1/40 bg-mist-4/20 backdrop-blur-sm" />
          <div className="absolute bottom-[10%] right-[14%] h-[28vh] w-[34vw] rounded-[2.25rem] border border-mist-1/60 bg-mist-1/25 backdrop-blur-md" />
          <div className="absolute left-[54%] top-[48%] h-48 w-48 rounded-full bg-mist-1/40 blur-2xl" />
          {/* condensation sheen */}
          <div className="absolute inset-0 bg-gradient-to-b from-mist-1/40 via-transparent to-mist-1/30" />
        </>
      )}
    </div>
  );
}
