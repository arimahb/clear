import { Sparkles, SlidersHorizontal, type LucideIcon } from "lucide-react";

export const FEATURES: { key: string; num: string; name: string; title: string; icon: LucideIcon; blurb: string; items: string[]; to: "/dashboard/customize" | "/dashboard/simplify" }[] = [
  {
    key: "customize",
    num: "01",
    name: "Customize",
    title: "Your Internet, Your Rules.",
    icon: SlidersHorizontal,
    blurb: "Take control of how webpages look, behave, and present information. Customize your browsing environment based on what works best for you.",
    items: ["Selective blurring of images, ads, videos and sections.", "Reduce flashing, moving animations and transitions.", "Stop videos and audio from autoplaying.", "A clean, adjustable reading mode.", "Font, size, spacing, contrast and colors.", "Hide content categories or single elements.", "Click any element and choose what CLEAR does with it."],
    to: "/dashboard/customize",
  },
  {
    key: "simplify",
    num: "02",
    name: "Simplify",
    title: "Understand Information Your Way.",
    icon: Sparkles,
    blurb: "Make complicated information easier to understand without losing its meaning. CLEAR adapts explanations to the way you prefer to learn.",
    items: ["Highlight text and choose Explain with CLEAR.", "Five explanation styles, from Simpler Language to Explain in Detail.", "Saved understanding preferences, used automatically.", "Keeps important terms and meaning intact.", "Flags ambiguous wording instead of guessing."],
    to: "/dashboard/simplify",
  },
];
