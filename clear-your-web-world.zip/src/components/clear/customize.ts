import type { CustomizeKey } from "@/lib/prefs";

export const CUSTOMIZE_ITEMS: { key: CustomizeKey; label: string; hint: string }[] = [
  { key: "ads", label: "Advertisements", hint: "Blur or hide distracting ads." },
  { key: "autoplay", label: "Autoplaying videos", hint: "Prevent automatic playback." },
  { key: "animations", label: "Moving animations", hint: "Reduce unnecessary movement." },
  { key: "images", label: "Images", hint: "Blur images until selected." },
  { key: "popups", label: "Pop-ups", hint: "Hide intrusive pop-ups." },
  { key: "backgrounds", label: "Background visuals", hint: "Simplify decorative backgrounds." },
];
