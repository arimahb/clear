import { Clock, MessageCircleQuestion, Play } from "lucide-react";
import { LogoMark } from "./Logo";

function FakeSwitch({ on }: { on: boolean }) {
  return (
    <span className={`relative inline-block h-4 w-7 rounded-full ${on ? "bg-primary" : "bg-mist-4"}`}>
      <span className={`absolute top-0.5 h-3 w-3 rounded-full bg-mist-1 ${on ? "left-3.5" : "left-0.5"}`} />
    </span>
  );
}

/** Illustration of the CLEAR extension working on a webpage. */
export function HeroMockup() {
  return (
    <div className="relative mx-auto w-full max-w-xl" role="img" aria-label="Illustration: CLEAR's panel open over a webpage, showing sensory switches, a message explanation and a page forecast">
      <div className="glass-strong overflow-hidden rounded-3xl">
        <div className="flex items-center gap-2 border-b border-mist-4/60 px-4 py-3">
          <span className="h-2.5 w-2.5 rounded-full bg-mist-5" />
          <span className="h-2.5 w-2.5 rounded-full bg-mist-4" />
          <span className="h-2.5 w-2.5 rounded-full bg-mist-3" />
          <span className="ml-3 flex-1 rounded-full bg-mist-2 px-3 py-1 text-xs text-muted-foreground">team-chat.example/messages</span>
          <LogoMark className="h-5 w-5" />
        </div>
        <div className="grid grid-cols-[1fr_200px] gap-4 p-5">
          <div className="space-y-3">
            <div className="relative flex h-28 items-center justify-center rounded-2xl bg-gradient-to-br from-mist-4 to-mist-5">
              <span className="flex items-center gap-1.5 rounded-full bg-mist-1/80 px-3 py-1 text-xs text-primary"><Play className="h-3 w-3" /> Autoplay paused</span>
            </div>
            <div className="h-2.5 w-4/5 rounded-full bg-mist-4" />
            <div className="h-2.5 w-3/5 rounded-full bg-mist-3" />
            <div className="rounded-2xl bg-mist-1/80 p-3 text-xs shadow-soft">
              <p className="font-semibold text-primary">Jordan</p>
              <p className="text-foreground">“Sure, take your time… it's only urgent.”</p>
              <div className="mt-2 rounded-xl bg-mist-3/70 p-2 text-[11px] leading-snug">
                <p className="flex items-center gap-1 font-semibold text-primary"><MessageCircleQuestion className="h-3 w-3" /> Possible meaning</p>
                <p className="text-muted-foreground">They might mean this is urgent. “Take your time” may be sarcastic.</p>
              </div>
            </div>
          </div>
          <div className="space-y-3 text-xs">
            <div className="rounded-2xl bg-mist-1/85 p-3 shadow-soft">
              <p className="mb-2 font-display font-semibold text-primary">Customize</p>
              {[["Reduce animations", true], ["Pause autoplay", true], ["Soften colours", false], ["Simplify layout", true]].map(([l, on]) => (
                <div key={String(l)} className="flex items-center justify-between py-1 text-muted-foreground">
                  {l} <FakeSwitch on={Boolean(on)} />
                </div>
              ))}
            </div>
            <div className="rounded-2xl bg-mist-1/85 p-3 shadow-soft">
              <p className="mb-2 flex items-center gap-1 font-display font-semibold text-primary"><Clock className="h-3 w-3" /> Page forecast</p>
              <p className="text-muted-foreground">4 min read · 1 video</p>
              <div className="mt-2 h-1.5 rounded-full bg-mist-3"><div className="h-full w-1/3 rounded-full bg-primary/60" /></div>
              <p className="mt-1 text-muted-foreground">Complexity: low</p>
            </div>
          </div>
        </div>
      </div>
      <div className="absolute -bottom-6 -left-6 -z-10 h-40 w-40 rounded-[2rem] bg-mist-1/50 blur-sm" />
      <div className="absolute -right-8 -top-8 -z-10 h-32 w-32 rounded-full bg-mist-5/40 blur-xl" />
    </div>
  );
}
