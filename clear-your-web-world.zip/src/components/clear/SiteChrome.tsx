import { Link } from "@tanstack/react-router";
import { Menu } from "lucide-react";
import { useState, type ReactNode } from "react";

import { Button } from "@/components/ui/button";
import { Sheet, SheetContent, SheetTitle, SheetTrigger } from "@/components/ui/sheet";
import { Logo } from "./Logo";

const NAV = [
  { label: "Features", to: "/features" as const },
  { label: "How It Works", to: "/" as const, hash: "how" },
  { label: "About", to: "/about" as const },
];

export function SiteNav() {
  const [open, setOpen] = useState(false);
  return (
    <header className="sticky top-0 z-40 px-4 pt-4">
      <nav className="glass mx-auto flex max-w-6xl items-center justify-between rounded-2xl px-5 py-3" aria-label="Main">
        <Logo />
        <div className="hidden items-center gap-8 text-sm font-medium md:flex">
          {NAV.map((n) => (
            <Link
              key={n.label}
              to={n.to}
              {...(n.hash ? { hash: n.hash } : {})}
              className="text-muted-foreground transition-colors hover:text-primary"
              activeProps={{ className: n.hash ? "" : "text-primary" }}
            >
              {n.label}
            </Link>
          ))}
          <Button asChild className="rounded-full px-5 shadow-soft">
            <Link to="/download">Get CLEAR</Link>
          </Button>
        </div>
        <Sheet open={open} onOpenChange={setOpen}>
          <SheetTrigger asChild>
            <Button variant="ghost" size="icon" className="md:hidden" aria-label="Open menu">
              <Menu />
            </Button>
          </SheetTrigger>
          <SheetContent className="glass-strong">
            <SheetTitle className="sr-only">Menu</SheetTitle>
            <div className="mt-10 flex flex-col gap-2">
              {NAV.map((n) => (
                <Link key={n.label} to={n.to} {...(n.hash ? { hash: n.hash } : {})} onClick={() => setOpen(false)} className="rounded-xl px-3 py-3 text-lg hover:bg-secondary">
                  {n.label}
                </Link>
              ))}
              <Button asChild className="mt-4 rounded-full">
                <Link to="/download" onClick={() => setOpen(false)}>Get CLEAR</Link>
              </Button>
            </div>
          </SheetContent>
        </Sheet>
      </nav>
    </header>
  );
}

export function SiteFooter() {
  const links = [
    { label: "About", to: "/about" as const },
    { label: "Features", to: "/features" as const },
    { label: "Privacy", to: "/privacy" as const },
  ];
  return (
    <footer className="px-4 pb-6">
      <div className="glass mx-auto flex max-w-6xl flex-col items-center justify-between gap-5 rounded-3xl px-6 py-8 md:flex-row">
        <Logo />
        <nav className="flex flex-wrap justify-center gap-6 text-sm text-muted-foreground" aria-label="Footer">
          {links.map((l) => (
            <Link key={l.label} to={l.to} className="hover:text-primary">{l.label}</Link>
          ))}
        </nav>
        <p className="text-sm text-muted-foreground">© {new Date().getFullYear()} CLEAR. A hackathon prototype.</p>
      </div>
    </footer>
  );
}

export function SiteShell({ children }: { children: ReactNode }) {
  return (
    <div className="flex min-h-screen flex-col font-sans">
      <SiteNav />
      <main className="flex-1">{children}</main>
      <SiteFooter />
    </div>
  );
}

export function PageHero({ eyebrow, title, children }: { eyebrow: string; title: ReactNode; children?: ReactNode }) {
  return (
    <section className="mx-auto max-w-4xl px-6 pb-12 pt-20 text-center">
      <p className="mb-4 text-sm font-semibold uppercase tracking-[0.2em] text-muted-foreground">{eyebrow}</p>
      <h1 className="font-display text-4xl font-semibold leading-tight text-primary md:text-6xl">{title}</h1>
      {children && <div className="mx-auto mt-6 max-w-2xl text-lg text-muted-foreground">{children}</div>}
    </section>
  );
}
