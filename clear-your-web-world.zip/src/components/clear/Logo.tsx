import { Link } from "@tanstack/react-router";
import { cn } from "@/lib/utils";

export function LogoMark({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 40 40" className={cn("h-8 w-8", className)} aria-hidden="true">
      <defs>
        <linearGradient id="clear-pane" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0" stopColor="var(--mist-1)" />
          <stop offset="1" stopColor="var(--mist-5)" />
        </linearGradient>
      </defs>
      <rect x="3" y="3" width="34" height="34" rx="10" fill="url(#clear-pane)" stroke="var(--slate)" strokeOpacity=".5" />
      <rect x="8" y="8" width="11" height="11" rx="3.5" fill="var(--mist-1)" fillOpacity=".9" />
      <rect x="21" y="8" width="11" height="11" rx="3.5" fill="var(--navy)" fillOpacity=".18" />
      <rect x="8" y="21" width="11" height="11" rx="3.5" fill="var(--navy)" fillOpacity=".28" />
      <rect x="21" y="21" width="11" height="11" rx="3.5" fill="var(--mist-1)" fillOpacity=".7" />
    </svg>
  );
}

export function Logo({ className }: { className?: string }) {
  return (
    <Link to="/" className={cn("inline-flex items-center gap-2.5 rounded-lg text-primary", className)} aria-label="CLEAR home">
      <LogoMark />
      <span className="logo-text font-display text-xl font-semibold">CLEAR</span>
    </Link>
  );
}
