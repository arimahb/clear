import { Link } from "@tanstack/react-router";
import { ArrowLeft, Check, Copy, Sparkles } from "lucide-react";
import { useState, type ReactNode } from "react";
import { toast } from "sonner";

import { Switch } from "@/components/ui/switch";
import type { ClarityPrefs, ClarityResult } from "@/lib/clarity";
import { usePrefs, type Prefs } from "@/lib/prefs";
import { cn } from "@/lib/utils";

export function toClarityPrefs(p: Prefs): ClarityPrefs {
  return { style: p.explanationStyle, tone: p.tone, ...p.comm };
}
export function useClarityPrefs() {
  return toClarityPrefs(usePrefs());
}

export function DashHeader({ title, sub, children }: { title: string; sub: string; children?: ReactNode }) {
  return (
    <header className="mb-8">
      <Link to="/dashboard" className="mb-5 inline-flex items-center gap-1.5 rounded-full text-sm text-muted-foreground hover:text-primary">
        <ArrowLeft className="h-4 w-4" /> Dashboard home
      </Link>
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <h1 className="font-display text-3xl font-semibold text-primary md:text-5xl">{title}</h1>
          <p className="mt-3 max-w-2xl text-lg text-muted-foreground">{sub}</p>
        </div>
        {children}
      </div>
    </header>
  );
}

export function Panel({ title, children, className, icon }: { title?: string; children: ReactNode; className?: string; icon?: ReactNode }) {
  return (
    <section className={cn("glass rounded-3xl p-6 md:p-7", className)}>
      {title && <h2 className="mb-5 flex items-center gap-2 font-display text-xl font-semibold text-primary">{icon}{title}</h2>}
      {children}
    </section>
  );
}

export function ToggleRow({ label, hint, checked, onChange }: { label: string; hint?: string; checked: boolean; onChange: (v: boolean) => void }) {
  const id = `t-${label.replace(/\W+/g, "-").toLowerCase()}`;
  return (
    <div className="flex items-center justify-between gap-4 rounded-2xl bg-mist-1/60 px-4 py-3">
      <label htmlFor={id} className="cursor-pointer">
        <span className="block font-medium">{label}</span>
        {hint && <span className="text-sm text-muted-foreground">{hint}</span>}
      </label>
      <Switch id={id} checked={checked} onCheckedChange={onChange} />
    </div>
  );
}

export function Segmented<T extends string>({ value, onChange, options, label }: { value: T; onChange: (v: T) => void; options: { v: T; label: string }[]; label: string }) {
  return (
    <div role="radiogroup" aria-label={label} className="flex flex-wrap gap-1 rounded-2xl bg-mist-3/70 p-1">
      {options.map((o) => (
        <button
          key={o.v}
          type="button"
          role="radio"
          aria-checked={value === o.v}
          onClick={() => onChange(o.v)}
          className={cn("flex-1 rounded-xl px-3 py-2 text-sm font-medium transition", value === o.v ? "bg-mist-1 text-primary shadow-soft" : "text-muted-foreground hover:text-primary")}
        >
          {o.label}
        </button>
      ))}
    </div>
  );
}

function CopyButton({ text }: { text: string }) {
  const [done, setDone] = useState(false);
  return (
    <button
      type="button"
      onClick={async () => {
        try {
          await navigator.clipboard.writeText(text);
          setDone(true);
          setTimeout(() => setDone(false), 1500);
        } catch {
          toast.error("Couldn't copy. Please select the text instead.");
        }
      }}
      className="inline-flex shrink-0 items-center gap-1 rounded-full bg-mist-3 px-3 py-1 text-xs font-medium text-primary hover:bg-mist-4"
      aria-label={`Copy reply: ${text}`}
    >
      {done ? <Check className="h-3 w-3" /> : <Copy className="h-3 w-3" />} {done ? "Copied" : "Copy"}
    </button>
  );
}

export function ClarityView({ r, sample, compact }: { r: ClarityResult; sample?: boolean | undefined; compact?: boolean }) {
  const blocks: [string, ReactNode][] = [
    ["Literal meaning", <p>{r.literal}</p>],
    ["Possible underlying meaning", <ul className="space-y-1.5">{r.underlying.map((u) => <li key={u}>{u}</li>)}</ul>],
  ];
  if (!compact) {
    blocks.push(
      ["Possible tone", <ul className="space-y-1.5">{r.tone.map((u) => <li key={u}>{u}</li>)}</ul>],
      ["What they might be asking", <p>{r.asking}</p>],
      [
        "Suggested responses",
        <ul className="space-y-2">
          {r.responses.map((u) => (
            <li key={u} className="flex items-center justify-between gap-3 rounded-xl bg-mist-1/80 px-3 py-2">
              <span>“{u}”</span><CopyButton text={u} />
            </li>
          ))}
        </ul>,
      ],
    );
  }
  return (
    <div className="space-y-3" aria-live="polite">
      {sample && (
        <p className="inline-flex items-center gap-1.5 rounded-full bg-mist-4/70 px-3 py-1 text-xs font-semibold text-primary">
          <Sparkles className="h-3 w-3" /> Example response, not a live AI analysis
        </p>
      )}
      {blocks.map(([t, b], i) => (
        <div key={t} className="rounded-2xl bg-mist-2/70 p-4">
          <h3 className="mb-1.5 text-sm font-semibold text-primary">{i + 1}. {t}</h3>
          <div className="text-foreground">{b}</div>
        </div>
      ))}
    </div>
  );
}
