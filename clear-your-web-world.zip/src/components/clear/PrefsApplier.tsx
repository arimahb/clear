import { useEffect } from "react";
import { applyPrefsToDocument, usePrefs } from "@/lib/prefs";

export function PrefsApplier() {
  const prefs = usePrefs();
  useEffect(() => applyPrefsToDocument(prefs), [prefs]);
  return null;
}
