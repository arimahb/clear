(function () {
  var params = new URLSearchParams(location.search);
  if (params.get("view") === "full") document.body.classList.add("full");

  var prefs, tab = null, host = "";
  var $ = function (id) { return document.getElementById(id); };

  var PREF_ROWS = [
    { key: "ads", ico: "▦", title: "Advertisements", desc: "Blur or hide distracting ads" },
    { key: "autoplay", ico: "▶", title: "Autoplaying videos", desc: "Prevent automatic playback" },
    { key: "animations", ico: "≈", title: "Moving animations", desc: "Reduce unnecessary movement" },
    { key: "images", ico: "◐", title: "Images", desc: "Blur images until selected" },
    { key: "popups", ico: "⧉", title: "Pop-ups", desc: "Hide intrusive pop-ups" },
    { key: "backgrounds", ico: "░", title: "Background visuals", desc: "Simplify decorative backgrounds" },
  ];

  function save() { return clearSave(prefs); }

  function el(tag, attrs, children) {
    var n = document.createElement(tag);
    Object.keys(attrs || {}).forEach(function (k) {
      if (k === "class") n.className = attrs[k];
      else if (k === "text") n.textContent = attrs[k];
      else if (k.indexOf("on") === 0) n.addEventListener(k.slice(2), attrs[k]);
      else n.setAttribute(k, attrs[k]);
    });
    (children || []).forEach(function (c) { if (c) n.appendChild(typeof c === "string" ? document.createTextNode(c) : c); });
    return n;
  }

  function isOn(key) { return key === "ads" ? prefs.customize.ads.on : !!prefs.customize[key]; }

  function renderPrefs() {
    var ul = $("prefs");
    ul.textContent = "";
    PREF_ROWS.forEach(function (row) {
      var on = isOn(row.key);
      var input = el("input", { type: "checkbox", "aria-label": row.title });
      input.checked = on;
      input.addEventListener("change", function () {
        if (row.key === "ads") prefs.customize.ads.on = input.checked;
        else prefs.customize[row.key] = input.checked;
        save(); renderPrefs();
      });
      var text = el("div", { class: "pref-text" }, [el("strong", { text: row.title }), el("small", { text: row.desc })]);
      if (row.key === "ads" && on) {
        var seg = el("div", { class: "mini-seg" });
        [["blur", "Blur"], ["hide", "Hide"]].forEach(function (o) {
          seg.appendChild(el("button", {
            class: prefs.customize.ads.mode === o[0] ? "on" : "",
            text: o[1],
            onclick: function () { prefs.customize.ads.mode = o[0]; save(); renderPrefs(); },
          }));
        });
        text.appendChild(el("div", {}, [seg]));
      }
      ul.appendChild(el("li", { class: "pref" + (on ? " on" : "") }, [
        el("span", { class: "pref-ico", text: row.ico }),
        text,
        el("label", { class: "switch small" }, [input, el("span", { class: "track" }, [el("span", { class: "thumb" })])]),
      ]));
    });
    var n = clearCountEnabled(prefs);
    $("count").textContent = n + (n === 1 ? " preference" : " preferences") + " enabled";
  }

  function renderVisual() {
    var v = prefs.visual;
    $("visual-on").checked = v.enabled;
    $("visual").classList.toggle("off", !v.enabled);
    document.querySelectorAll("#visual .seg").forEach(function (seg) {
      var key = seg.dataset.key;
      seg.querySelectorAll("button").forEach(function (b) { b.classList.toggle("on", b.dataset.v === v[key]); });
    });
    document.querySelectorAll("#visual input[type=range]").forEach(function (r) {
      r.value = v[r.dataset.key];
    });
    $("o-textScale").textContent = v.textScale + "%";
    $("o-lineHeight").textContent = Number(v.lineHeight).toFixed(1);
    $("o-letterSpacing").textContent = Number(v.letterSpacing).toFixed(2) + "em";
  }

  function renderRules() {
    var ul = $("rules");
    ul.textContent = "";
    var list = (host && prefs.siteRules[host]) || [];
    if (!list.length) {
      ul.appendChild(el("li", { class: "empty", text: "Nothing yet. Use “Pick an element” and tick “Always apply”." }));
      return;
    }
    list.forEach(function (r, i) {
      var name = r.action === "blur" ? "Blur" : r.action === "hide" ? "Hide" : "Still";
      ul.appendChild(el("li", { class: "rule" }, [
        el("span", { class: "badge", text: name }),
        el("span", { text: r.label || "Element" }),
        el("code", { text: r.selector, title: r.selector }),
        el("button", { "aria-label": "Remove rule", text: "✕", onclick: function () {
          prefs.siteRules[host].splice(i, 1);
          if (!prefs.siteRules[host].length) delete prefs.siteRules[host];
          save(); renderRules(); renderSaved();
        } }),
      ]));
    });
  }

  function renderStyles() {
    var wrap = $("styles");
    wrap.textContent = "";
    CLEAR_STYLES.forEach(function (s) {
      wrap.appendChild(el("button", {
        class: "chip" + (prefs.understanding.style === s.id ? " on" : ""),
        text: s.label,
        onclick: function () { prefs.understanding.style = s.id; save(); renderStyles(); },
      }));
    });
    var ul = $("understanding");
    ul.textContent = "";
    CLEAR_UNDERSTANDING.forEach(function (u) {
      var cb = el("input", { type: "checkbox" });
      cb.checked = prefs.understanding.prefs.indexOf(u.id) !== -1;
      cb.addEventListener("change", function () {
        var list = prefs.understanding.prefs.filter(function (x) { return x !== u.id; });
        if (cb.checked) list.push(u.id);
        prefs.understanding.prefs = list;
        save();
      });
      ul.appendChild(el("li", {}, [el("label", {}, [cb, el("span", { text: u.label })])]));
    });
    $("sel-btn").checked = prefs.understanding.selectionButton;
  }

  function renderSaved() {
    var sites = Object.keys(prefs.siteRules).length;
    var rules = Object.keys(prefs.siteRules).reduce(function (a, k) { return a + prefs.siteRules[k].length; }, 0);
    $("saved-summary").textContent = rules + " remembered element" + (rules === 1 ? "" : "s") + " across " + sites + " site" + (sites === 1 ? "" : "s") + ".";
    $("api").value = prefs.apiBase;
    var sy = document.getElementById("sync-note");
    if (sy) sy.textContent = prefs.syncedAt ? "Synced with your CLEAR dashboard " + new Date(prefs.syncedAt).toLocaleString() + "." : "Open your CLEAR dashboard once and your preferences sync here automatically.";
  }

  function renderSite() {
    var paused = host && prefs.pausedHosts.indexOf(host) !== -1;
    $("site-on").checked = !paused;
    $("site-on-label").textContent = paused ? "Paused here" : "On here";
  }

  function dashUrl() {
    if (prefs.syncedFrom && !clearIsPrivateOrigin(prefs.syncedFrom)) return prefs.syncedFrom.replace(/\/+$/, "") + "/dashboard";
    return CLEAR_DASHBOARD_URL;
  }
  function renderHome() {
    var name = (prefs.name || "").trim();
    $("hello").textContent = name ? "Hello, " + name + "." : "Hello there.";
    var on = clearCountEnabled(prefs);
    $("h-count").textContent = on + " of 6 on";
    var names = PREF_ROWS.filter(function (r) { return isOn(r.key); }).map(function (r) { return r.title; });
    $("h-custom").textContent = names.length ? names.slice(0, 3).join(", ") + (names.length > 3 ? "…" : "") : "Nothing changed yet";
    var st = CLEAR_STYLES.filter(function (s) { return s.id === prefs.understanding.style; })[0];
    $("h-style").textContent = st ? st.label : "Simpler language";
    var paused = host && prefs.pausedHosts.indexOf(host) !== -1;
    $("h-site").textContent = !host ? "Open a regular website to use CLEAR." : paused ? "CLEAR is paused on " + host + "." : "CLEAR is on for " + host + ".";
    var rules = Object.keys(prefs.siteRules).reduce(function (a, k) { return a + prefs.siteRules[k].length; }, 0);
    $("h-rules").textContent = rules + " remembered element" + (rules === 1 ? "" : "s") + " across your sites.";
    if (document.activeElement !== $("h-name")) $("h-name").value = name;
    $("h-sync").textContent = prefs.syncedAt ? "Synced with your dashboard " + new Date(prefs.syncedAt).toLocaleString() + "." : "Open your dashboard once to sync your preferences.";
  }
  function goTab(name) {
    var t = document.querySelector('.tab[data-tab="' + name + '"]');
    if (t) t.click();
  }

  function hasPref(id) { return prefs.understanding.prefs.indexOf(id) !== -1; }
  function setPrefPair(on, off) {
    var l = prefs.understanding.prefs.filter(function (x) { return x !== on && x !== off; });
    l.push(on); prefs.understanding.prefs = l;
  }
  function flashSaved() { var s = $("p-saved"); s.hidden = false; clearTimeout(flashSaved.t); flashSaved.t = setTimeout(function () { s.hidden = true; }, 1400); }
  function renderMyPrefs() {
    var sel = $("p-style");
    if (!sel.options.length) CLEAR_STYLES.forEach(function (s) { sel.appendChild(el("option", { value: s.id, text: s.label })); });
    sel.value = prefs.understanding.style;
    var len = hasPref("detailed") ? "detailed" : "short";
    var learn = hasPref("numbered") && !hasPref("examples") ? "steps" : "examples";
    $("p-length").querySelectorAll("button").forEach(function (b) { b.classList.toggle("on", b.dataset.v === (hasPref("detailed") || hasPref("concise") ? len : "")); });
    $("p-learn").querySelectorAll("button").forEach(function (b) { b.classList.toggle("on", b.dataset.v === (hasPref("numbered") || hasPref("examples") ? learn : "")); });
    var v = prefs.visual;
    $("p-visual").textContent = (v.enabled ? "On · " + v.font + " font, " + v.textScale + "% text, " + v.theme + " colors" : "Visual adjustments are off") + " · " + clearCountEnabled(prefs) + " of 6 page preferences on.";
    var hp = $("h-prefs");
    if (hp) hp.textContent = (len === "detailed" ? "Detailed" : "Short") + " · " + (learn === "steps" ? "Step-by-step" : "Examples");
  }
  function renderSimplifyBox() {
    var w = $("s-styles"); w.textContent = "";
    CLEAR_STYLES.forEach(function (s) {
      w.appendChild(el("button", { class: "chip" + (sStyle === s.id ? " on" : ""), text: s.label, onclick: function () { sStyle = s.id; renderSimplifyBox(); } }));
    });
  }
  var sStyle = null;

  function renderAll() { if (!sStyle) sStyle = prefs.understanding.style; renderSimplifyBox(); renderMyPrefs(); renderHome(); renderSite(); renderPrefs(); renderVisual(); renderRules(); renderStyles(); renderSaved(); }

  function notice(msg) {
    var n = $("notice");
    n.textContent = msg;
    n.hidden = !msg;
  }

  function sendTab(msg) {
    if (!tab) return Promise.reject();
    return chrome.tabs.sendMessage(tab.id, msg, { frameId: 0 });
  }

  // Tabs
  document.querySelectorAll(".tab").forEach(function (t) {
    t.addEventListener("click", function () {
      document.querySelectorAll(".tab").forEach(function (x) {
        x.classList.toggle("on", x === t);
        x.setAttribute("aria-selected", String(x === t));
      });
      document.querySelectorAll(".pane").forEach(function (p) { p.hidden = p.id !== "pane-" + t.dataset.tab; });
    });
  });

  document.querySelectorAll("[data-go]:not(.home-card)").forEach(function (b) { b.addEventListener("click", function () { goTab(b.dataset.go); }); });
  $("p-style").addEventListener("change", function () { prefs.understanding.style = $("p-style").value; sStyle = prefs.understanding.style; save(); renderAll(); flashSaved(); });
  $("p-length").querySelectorAll("button").forEach(function (b) { b.addEventListener("click", function () { setPrefPair(b.dataset.v === "short" ? "concise" : "detailed", b.dataset.v === "short" ? "detailed" : "concise"); save(); renderAll(); flashSaved(); }); });
  $("p-learn").querySelectorAll("button").forEach(function (b) { b.addEventListener("click", function () { setPrefPair(b.dataset.v === "steps" ? "numbered" : "examples", b.dataset.v === "steps" ? "examples" : "numbered"); save(); renderAll(); flashSaved(); }); });
  $("s-grab").addEventListener("click", function () {
    sendTab({ type: "get-selection" }).then(function (r) {
      if (r && r.text) $("s-text").value = r.text.slice(0, 4000);
      else { $("s-status").className = "api-status bad"; $("s-status").textContent = "Highlight text on the page first."; }
    }, function () { $("s-status").className = "api-status bad"; $("s-status").textContent = "Can't read this page."; });
  });
  $("s-go").addEventListener("click", function () {
    var text = $("s-text").value.trim(), st = $("s-status"), out = $("s-result");
    if (text.length < 2) { st.className = "api-status bad"; st.textContent = "Enter some text first."; return; }
    st.className = "api-status"; st.textContent = "Explaining…"; $("s-go").disabled = true;
    function draw(d) {
      out.textContent = ""; out.hidden = false;
      out.appendChild(el("p", { text: d.explanation || "" }));
      if (d.keyTerms && d.keyTerms.length) { out.appendChild(el("h3", { text: "Key terms" })); out.appendChild(el("ul", {}, d.keyTerms.map(function (k) { return el("li", { text: k.term + " — " + k.meaning }); }))); }
      if (d.says) { out.appendChild(el("h3", { text: "What it says" })); out.appendChild(el("p", { text: d.says })); }
      if (d.implies) { out.appendChild(el("h3", { text: "What it implies" })); out.appendChild(el("p", { text: d.implies })); }
    }
    var port = chrome.runtime.connect({ name: "clear-explain" });
    port.onMessage.addListener(function (m) {
      if (m.partial) { if (m.partial.explanation) draw(m.partial); return; }
      var res = m.done; port.disconnect();
      $("s-go").disabled = false;
      if (!res || !res.ok) { out.textContent = ""; out.hidden = false; st.className = "api-status bad"; st.textContent = ""; out.appendChild(el("p", { text: (res && res.error) || "CLEAR's AI service didn't respond. Try again." })); return; }
      st.className = "api-status ok"; st.textContent = "✓ Done";
      draw(res.data || {});
    });
    port.postMessage({ payload: { text: text, style: sStyle, prefs: prefs.understanding.prefs } });
  });
  document.querySelectorAll(".home-card").forEach(function (b) { b.addEventListener("click", function () { goTab(b.dataset.go); }); });
  $("open-dash").addEventListener("click", function () { chrome.tabs.create({ url: dashUrl() }); });
  var dl = $("dash-link"); if (dl) dl.addEventListener("click", function (e) { e.preventDefault(); chrome.tabs.create({ url: dashUrl() }); });
  $("h-pick").addEventListener("click", function () { $("pick").click(); });
  $("h-reading").addEventListener("click", function () { $("reading").click(); });
  $("h-name-save").addEventListener("click", function () { prefs.name = $("h-name").value.trim().slice(0, 40); prefs.nameAt = Date.now(); save(); renderHome(); });
  chrome.storage.onChanged.addListener(function (ch, area) {
    if (area === "local" && ch.clearPrefs) { prefs = clearMerge(CLEAR_DEFAULTS, ch.clearPrefs.newValue || {}); renderAll(); }
  });

  $("site-on").addEventListener("change", function () {
    if (!host) return;
    prefs.pausedHosts = prefs.pausedHosts.filter(function (h) { return h !== host; });
    if (!$("site-on").checked) prefs.pausedHosts.push(host);
    save(); renderSite();
  });

  $("pick").addEventListener("click", function () {
    sendTab({ type: "start-picker" }).then(function () { window.close(); }, function () { notice("CLEAR can't run on this page. Try it on a regular website."); });
  });
  $("reading").addEventListener("click", function () {
    sendTab({ type: "toggle-reading" }).then(function () { window.close(); }, function () { notice("CLEAR can't run on this page. Try it on a regular website."); });
  });

  $("reset-prefs").addEventListener("click", function () {
    prefs.customize = clearMerge(CLEAR_DEFAULTS.customize, {});
    save(); renderPrefs();
  });

  $("visual-on").addEventListener("change", function () { prefs.visual.enabled = $("visual-on").checked; save(); renderVisual(); });
  document.querySelectorAll("#visual .seg button").forEach(function (b) {
    b.addEventListener("click", function () { prefs.visual[b.parentElement.dataset.key] = b.dataset.v; save(); renderVisual(); });
  });
  document.querySelectorAll("#visual input[type=range]").forEach(function (r) {
    r.addEventListener("input", function () { prefs.visual[r.dataset.key] = Number(r.value); save(); renderVisual(); });
  });

  $("sel-btn").addEventListener("change", function () { prefs.understanding.selectionButton = $("sel-btn").checked; save(); });

  function testApi() {
    var s = $("api-status");
    s.className = "api-status";
    s.textContent = "Testing…";
    chrome.runtime.sendMessage({ type: "ping-api" }, function (res) {
      s.className = "api-status " + (res && res.ok ? "ok" : "bad");
      s.textContent = res && res.ok ? "✓ Connected" : "✕ Not reachable";
    });
  }
  $("api-save").addEventListener("click", function () {
    var v = $("api").value.trim().replace(/\/+$/, "");
    if (!/^https?:\/\//.test(v)) { $("api-status").className = "api-status bad"; $("api-status").textContent = "Enter a full https:// address"; return; }
    prefs.apiBase = v;
    save().then(testApi);
  });
  $("api-reset").addEventListener("click", function () { prefs.apiBase = CLEAR_DEFAULT_API; save().then(function () { renderSaved(); testApi(); }); });
  $("reset-all").addEventListener("click", function () {
    if (!confirm("Reset all CLEAR preferences and remembered elements?")) return;
    prefs = clearMerge(CLEAR_DEFAULTS, {});
    save(); renderAll();
  });

  clearLoad().then(function (p) {
    prefs = p;
    chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
      tab = tabs && tabs[0];
      try {
        var u = new URL(tab.url);
        if (/^https?:$/.test(u.protocol) || u.protocol === "file:") host = u.hostname || "local";
      } catch (e) {}
      $("host").textContent = host || "Not available on this page";
      if (!host && !document.body.classList.contains("full")) notice("Open a regular website to use CLEAR here. Your preferences still save.");
      renderAll();
    });
  });
})();
