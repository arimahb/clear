/* CLEAR content script: customization engine, element picker, reading mode, explain panel. */
(function () {
  if (window.__clearLoaded) return;
  window.__clearLoaded = true;

  var HOST = location.hostname || "local";
  var IS_TOP = window === window.top;
  var prefs = clearMerge(CLEAR_DEFAULTS, {});
  var sessionRules = [];
  var lastGesture = 0;
  var lastContextTarget = null;

  /* ------------------------------------------------------------------ */
  /* Styles applied to the page                                          */
  /* ------------------------------------------------------------------ */
  var styleEl = document.createElement("style");
  styleEl.id = "clear-ext-style";
  function mountStyle() {
    var parent = document.head || document.documentElement;
    if (parent && styleEl.parentNode !== parent) parent.appendChild(styleEl);
  }

  var AD_SELECTORS = [
    "ins.adsbygoogle",
    "[id^='google_ads']",
    "[id^='div-gpt-ad']",
    "iframe[src*='doubleclick']",
    "iframe[src*='googlesyndication']",
    "iframe[id^='google_ads']",
    "[data-ad]",
    "[data-ad-slot]",
    "[data-adunit]",
    "[aria-label='Advertisement' i]",
    "[aria-label='Ad' i]",
    ".advertisement",
    ".ad-banner",
    ".ad-container",
    ".ad-slot",
    ".adslot",
    "[class*='sponsored-' i]",
    "[id*='ad-container' i]",
    "[class*='ad-wrapper' i]",
    ".clear-demo-ad",
  ].join(",");

  var POPUP_SELECTORS = [
    "#onetrust-banner-sdk",
    "#onetrust-consent-sdk",
    ".fc-consent-root",
    "#CybotCookiebotDialog",
    "[id*='cookie-banner' i]",
    "[class*='cookie-banner' i]",
    "[class*='cookie-consent' i]",
    "[id*='cookieconsent' i]",
    "[class*='newsletter-popup' i]",
    "[class*='newsletter-modal' i]",
    "[class*='modal-backdrop' i]",
    "[data-clear-popup]",
  ].join(",");

  var TEXT_SEL = "p, li, blockquote, dd, dt, td, th, figcaption, label, h1, h2, h3, h4, h5, h6, article, a, span";

  function isPaused() {
    return prefs.pausedHosts.indexOf(HOST) !== -1;
  }

  function allRules() {
    return (prefs.siteRules[HOST] || []).concat(sessionRules);
  }

  function buildCSS() {
    var css = "clear-root{all:initial !important;}";
    if (isPaused()) return css;
    var c = prefs.customize;
    var v = prefs.visual;

    if (c.ads.on) {
      css +=
        c.ads.mode === "hide"
          ? AD_SELECTORS + "{display:none !important;}"
          : AD_SELECTORS + "{filter:blur(14px) grayscale(.6) !important;opacity:.55 !important;pointer-events:none !important;}";
    }
    if (c.animations) {
      css +=
        "*,*::before,*::after{animation-duration:0.001ms !important;animation-iteration-count:1 !important;animation-delay:0s !important;transition-duration:0.001ms !important;transition-delay:0s !important;scroll-behavior:auto !important;}" +
        "marquee{display:block !important;}";
    }
    if (c.images) {
      css +=
        "img:not([data-clear-revealed]),picture:not([data-clear-revealed]) img{filter:blur(18px) !important;cursor:pointer !important;}";
    }
    if (c.popups) {
      css +=
        POPUP_SELECTORS +
        ",[data-clear-hidden-popup]{display:none !important;}" +
        "html[data-clear-unlocked],html[data-clear-unlocked] body{overflow:auto !important;}";
    }
    if (c.backgrounds) {
      css +=
        "body,body *:not(img):not(video):not(picture):not(svg):not(canvas):not(clear-root){background-image:none !important;}" +
        "video[loop][muted]:not([controls]){visibility:hidden !important;}";
    }
    if (v.enabled) {
      var fam =
        v.font === "sans"
          ? "ui-sans-serif, system-ui, -apple-system, 'Segoe UI', Roboto, Arial, sans-serif"
          : v.font === "serif"
            ? "'Iowan Old Style', 'Palatino Linotype', Georgia, 'Times New Roman', serif"
            : v.font === "readable"
              ? "Verdana, 'Atkinson Hyperlegible', Tahoma, sans-serif"
              : "";
      var scale = (Number(v.textScale) || 100) / 100;
      css += "p,li,blockquote,dd,dt,td,th,figcaption{";
      if (fam) css += "font-family:" + fam + " !important;";
      if (scale !== 1) css += "font-size:" + (16 * scale).toFixed(1) + "px !important;";
      css += "line-height:" + v.lineHeight + " !important;";
      if (Number(v.letterSpacing) > 0) css += "letter-spacing:" + v.letterSpacing + "em !important;word-spacing:" + v.letterSpacing * 2 + "em !important;";
      css += "}";
      if (fam) css += "h1,h2,h3,h4,h5,h6,a{font-family:" + fam + " !important;}";
      if (v.theme === "paper") {
        css += "html{filter:saturate(.85) brightness(.99) !important;background:#eef3f7 !important;}clear-root{filter:none;}";
      } else if (v.theme === "dark") {
        css +=
          "html{filter:invert(.92) hue-rotate(180deg) !important;background:#fff !important;}" +
          "img,video,picture,canvas,iframe,[style*='background-image'],clear-root{filter:invert(1) hue-rotate(180deg) !important;}";
      } else if (v.theme === "original" && v.filter) {
        css += "html{filter:" + v.filter + " !important;}";
      } else if (v.theme === "contrast") {
        css += "html{filter:contrast(1.35) !important;}p,li,td,dd,span{color:#000 !important;}a{text-decoration:underline !important;}";
      }
    }

    allRules().forEach(function (r) {
      try {
        document.querySelector(r.selector);
      } catch (e) {
        return;
      }
      if (r.action === "blur") css += r.selector + "{filter:blur(12px) !important;}";
      if (r.action === "hide") css += r.selector + "{display:none !important;}";
      if (r.action === "still")
        css +=
          r.selector +
          "," +
          r.selector +
          " *{animation:none !important;transition:none !important;}";
    });
    return css;
  }

  function apply() {
    styleEl.textContent = buildCSS();
    mountStyle();
    if (!isPaused()) {
      if (prefs.customize.autoplay) stopAutoplay();
      if (prefs.customize.popups) scanOverlays();
      allRules().forEach(function (r) {
        if (r.action === "still") pauseMediaIn(r.selector);
      });
    }
  }

  /* ------------------------------------------------------------------ */
  /* Autoplay                                                            */
  /* ------------------------------------------------------------------ */
  ["pointerdown", "keydown", "touchstart"].forEach(function (e) {
    window.addEventListener(e, function () { lastGesture = Date.now(); }, true);
  });

  function userInitiated() {
    return Date.now() - lastGesture < 1500;
  }

  document.addEventListener(
    "play",
    function (e) {
      var m = e.target;
      if (!(m instanceof HTMLMediaElement)) return;
      if (isPaused() || !prefs.customize.autoplay) return;
      if (userInitiated() || m.dataset.clearAllowed) {
        m.dataset.clearAllowed = "1";
        return;
      }
      m.pause();
    },
    true,
  );

  function stopAutoplay() {
    document.querySelectorAll("video, audio").forEach(function (m) {
      m.autoplay = false;
      m.removeAttribute("autoplay");
      if (!m.paused && !m.dataset.clearAllowed) m.pause();
    });
  }

  function pauseMediaIn(selector) {
    try {
      document.querySelectorAll(selector).forEach(function (el) {
        el.querySelectorAll("video, audio").forEach(function (m) { m.pause(); });
        if (el instanceof HTMLMediaElement) el.pause();
      });
    } catch (e) {}
  }

  /* ------------------------------------------------------------------ */
  /* Pop-up overlays (heuristic)                                         */
  /* ------------------------------------------------------------------ */
  function scanOverlays() {
    if (!document.body) return;
    var vw = window.innerWidth, vh = window.innerHeight, hid = false;
    var candidates = document.body.querySelectorAll("body > *, body > * > *, body > * > * > *, [role='dialog'], [aria-modal='true'], dialog[open], [id*='cookie' i], [class*='cookie' i], [id*='consent' i], [class*='consent' i]");
    candidates.forEach(function (el) {
      if (el.tagName === "CLEAR-ROOT" || el.hasAttribute("data-clear-hidden-popup")) return;
      var cs = getComputedStyle(el);
      if (cs.position !== "fixed" && cs.position !== "sticky" && !el.matches("[aria-modal='true'], dialog[open]")) return;
      if (cs.display === "none" || cs.visibility === "hidden") return;
      var z = parseInt(cs.zIndex, 10) || 0;
      var r = el.getBoundingClientRect();
      var coverage = (Math.max(0, r.width) * Math.max(0, r.height)) / (vw * vh);
      var isModal = el.matches("[aria-modal='true'], dialog[open]");
      var named = /cookie|consent|gdpr|newsletter|subscribe|popup|pop-up|modal|overlay|interstitial|signup|paywall/i.test((el.id || "") + " " + (typeof el.className === "string" ? el.className : ""));
      if (named && cs.position === "fixed" && coverage > 0.02 && el.tagName !== "HEADER" && el.tagName !== "NAV") {
        el.setAttribute("data-clear-hidden-popup", "");
        hid = true;
        return;
      }
      if ((z >= 100 && coverage > 0.3 && cs.position === "fixed") || (isModal && coverage > 0.08)) {
        el.setAttribute("data-clear-hidden-popup", "");
        hid = true;
      }
    });
    if (hid) document.documentElement.setAttribute("data-clear-unlocked", "");
  }

  var scanTimer = null;
  var observer = new MutationObserver(function () {
    if (scanTimer) return;
    scanTimer = setTimeout(function () {
      scanTimer = null;
      if (isPaused()) return;
      if (prefs.customize.popups) scanOverlays();
      if (prefs.customize.autoplay) stopAutoplay();
    }, 600);
  });

  /* Click to reveal blurred images */
  document.addEventListener(
    "click",
    function (e) {
      if (isPaused() || !prefs.customize.images) return;
      var t = e.target;
      if (t && t.tagName === "IMG" && !t.hasAttribute("data-clear-revealed")) {
        e.preventDefault();
        e.stopPropagation();
        t.setAttribute("data-clear-revealed", "");
        var pic = t.closest("picture");
        if (pic) pic.setAttribute("data-clear-revealed", "");
      }
    },
    true,
  );

  document.addEventListener("contextmenu", function (e) { lastContextTarget = e.target; }, true);

  /* ------------------------------------------------------------------ */
  /* Shadow-DOM UI root                                                  */
  /* ------------------------------------------------------------------ */
  var host = null, shadow = null;
  function ui() {
    if (shadow) return shadow;
    host = document.createElement("clear-root");
    shadow = host.attachShadow({ mode: "open" });
    var st = document.createElement("style");
    st.textContent = UI_CSS;
    shadow.appendChild(st);
    document.documentElement.appendChild(host);
    shadow.addEventListener("mouseup", onSelectionMaybe);
    return shadow;
  }
  function h(tag, attrs, children) {
    var el = document.createElement(tag);
    if (attrs) {
      Object.keys(attrs).forEach(function (k) {
        if (k === "class") el.className = attrs[k];
        else if (k === "text") el.textContent = attrs[k];
        else if (k.indexOf("on") === 0) el.addEventListener(k.slice(2), attrs[k]);
        else el.setAttribute(k, attrs[k]);
      });
    }
    (children || []).forEach(function (c) {
      if (c == null || c === false) return;
      el.appendChild(typeof c === "string" ? document.createTextNode(c) : c);
    });
    return el;
  }
  function toast(message, undo) {
    var root = ui();
    var old = root.querySelector(".toast");
    if (old) old.remove();
    var t = h("div", { class: "toast", role: "status" }, [
      h("span", { text: message }),
      undo ? h("button", { class: "link", text: "Undo", onclick: function () { undo(); t.remove(); } }) : null,
    ]);
    root.appendChild(t);
    setTimeout(function () { t.remove(); }, 4500);
  }

  /* ------------------------------------------------------------------ */
  /* Element picker                                                      */
  /* ------------------------------------------------------------------ */
  var picking = false, pickTarget = null, hl = null, hlLabel = null, menu = null;

  function cleanId(id) {
    return id && /^[a-zA-Z][\w-]{0,60}$/.test(id) && !/\d{4,}/.test(id);
  }
  function cssPath(el) {
    if (cleanId(el.id)) {
      var s = "#" + CSS.escape(el.id);
      if (document.querySelectorAll(s).length === 1) return s;
    }
    var parts = [], cur = el;
    while (cur && cur.nodeType === 1 && cur !== document.body && cur !== document.documentElement && parts.length < 6) {
      var part = cur.tagName.toLowerCase();
      if (cleanId(cur.id)) {
        parts.unshift("#" + CSS.escape(cur.id));
        break;
      }
      var cls = Array.prototype.filter
        .call(cur.classList, function (c) { return /^[a-zA-Z][\w-]*$/.test(c) && !/\d{3,}/.test(c) && c.length < 40 && c.indexOf("clear-") !== 0; })
        .slice(0, 2);
      if (cls.length) part += "." + cls.map(function (c) { return CSS.escape(c); }).join(".");
      var parent = cur.parentElement;
      if (parent) {
        var same = Array.prototype.filter.call(parent.children, function (s) { return s.tagName === cur.tagName; });
        if (same.length > 1) part += ":nth-of-type(" + (same.indexOf(cur) + 1) + ")";
      }
      parts.unshift(part);
      var sel = parts.join(" > ");
      try {
        if (document.querySelectorAll(sel).length === 1) return sel;
      } catch (e) {}
      cur = parent;
    }
    var out = parts.join(" > ");
    return cur === document.body ? "body > " + out : out;
  }
  function describe(el) {
    var tag = el.tagName.toLowerCase();
    var names = { img: "Image", video: "Video", iframe: "Embedded frame", aside: "Sidebar", nav: "Navigation", header: "Header", footer: "Footer", figure: "Figure", section: "Section", form: "Form", button: "Button", a: "Link", p: "Paragraph", ul: "List", ol: "List", table: "Table", h1: "Heading", h2: "Heading", h3: "Heading" };
    var name = names[tag] || "Section";
    var r = el.getBoundingClientRect();
    return name + " · " + Math.round(r.width) + "×" + Math.round(r.height);
  }

  function startPicker() {
    if (picking) return;
    var root = ui();
    closeMenu();
    picking = true;
    hl = h("div", { class: "hl" });
    hlLabel = h("div", { class: "hl-label" });
    var bar = h("div", { class: "pick-bar" }, [
      h("strong", { text: "CLEAR" }),
      h("span", { text: "Click anything on the page to blur, hide or calm it. " }),
      h("kbd", { text: "Esc" }),
      h("span", { text: " to cancel" }),
    ]);
    root.appendChild(hl);
    root.appendChild(hlLabel);
    root.appendChild(bar);
    document.addEventListener("mousemove", onPickMove, true);
    document.addEventListener("click", onPickClick, true);
    document.addEventListener("keydown", onPickKey, true);
  }
  function stopPicker() {
    picking = false;
    document.removeEventListener("mousemove", onPickMove, true);
    document.removeEventListener("click", onPickClick, true);
    document.removeEventListener("keydown", onPickKey, true);
    if (shadow) shadow.querySelectorAll(".hl, .hl-label, .pick-bar").forEach(function (n) { n.remove(); });
    hl = hlLabel = null;
  }
  function placeHighlight(el) {
    if (!hl) {
      var root = ui();
      hl = h("div", { class: "hl" });
      hlLabel = h("div", { class: "hl-label" });
      root.appendChild(hl);
      root.appendChild(hlLabel);
    }
    var r = el.getBoundingClientRect();
    hl.style.cssText = "top:" + r.top + "px;left:" + r.left + "px;width:" + r.width + "px;height:" + r.height + "px;";
    hlLabel.textContent = describe(el);
    hlLabel.style.cssText = "top:" + Math.max(4, r.top - 26) + "px;left:" + Math.max(4, r.left) + "px;";
  }
  function onPickMove(e) {
    var el = document.elementFromPoint(e.clientX, e.clientY);
    if (!el || el === host || el === document.documentElement || el === document.body) return;
    pickTarget = el;
    placeHighlight(el);
  }
  function onPickClick(e) {
    if (e.composedPath().indexOf(host) !== -1) return;
    e.preventDefault();
    e.stopPropagation();
    if (!pickTarget) return;
    var target = pickTarget;
    stopPicker();
    openMenu(target);
  }
  function onPickKey(e) {
    if (e.key === "Escape") {
      e.preventDefault();
      stopPicker();
    } else if (e.key === "ArrowUp" && pickTarget && pickTarget.parentElement && pickTarget.parentElement !== document.body) {
      e.preventDefault();
      pickTarget = pickTarget.parentElement;
      placeHighlight(pickTarget);
    }
  }

  function closeMenu() {
    if (menu) menu.remove();
    menu = null;
    if (!picking && shadow) shadow.querySelectorAll(".hl, .hl-label").forEach(function (n) { n.remove(); });
    hl = hlLabel = null;
  }

  function openMenu(target) {
    var root = ui();
    closeMenu();
    placeHighlight(target);
    var current = target;
    var always = h("input", { type: "checkbox", id: "clear-always" });
    var choose = function (action) {
      return function () {
        var rule = { selector: cssPath(current), action: action, label: describe(current).split(" · ")[0] };
        var remember = always.checked;
        if (remember) {
          var list = (prefs.siteRules[HOST] || []).filter(function (r) { return r.selector !== rule.selector; });
          list.push(rule);
          prefs.siteRules[HOST] = list;
          clearSave(prefs);
        } else {
          sessionRules.push(rule);
        }
        apply();
        closeMenu();
        var verb = action === "blur" ? "Blurred" : action === "hide" ? "Hidden" : "Movement reduced";
        toast(verb + (remember ? " — remembered on " + HOST : " for this visit"), function () {
          if (remember) {
            prefs.siteRules[HOST] = (prefs.siteRules[HOST] || []).filter(function (r) { return r.selector !== rule.selector; });
            clearSave(prefs);
          } else {
            sessionRules = sessionRules.filter(function (r) { return r !== rule; });
          }
          apply();
        });
      };
    };
    var label = h("div", { class: "menu-target", text: describe(current) });
    menu = h("div", { class: "menu", role: "menu" }, [
      h("div", { class: "menu-head" }, [h("span", { class: "dot" }), h("strong", { text: "CLEAR" }), label]),
      h("button", { class: "menu-item", role: "menuitem", onclick: choose("blur") }, [h("span", { class: "ico", text: "◐" }), "Blur this"]),
      h("button", { class: "menu-item", role: "menuitem", onclick: choose("hide") }, [h("span", { class: "ico", text: "⊘" }), "Hide this"]),
      h("button", { class: "menu-item", role: "menuitem", onclick: choose("still") }, [h("span", { class: "ico", text: "≈" }), "Reduce its movement"]),
      h("label", { class: "menu-always", for: "clear-always" }, [always, h("span", { text: "Always apply on " + HOST })]),
      h("div", { class: "menu-foot" }, [
        h("button", {
          class: "link",
          text: "↑ Select larger area",
          onclick: function () {
            if (current.parentElement && current.parentElement !== document.body) {
              current = current.parentElement;
              placeHighlight(current);
              label.textContent = describe(current);
            }
          },
        }),
        h("button", { class: "link", text: "Pick again", onclick: function () { closeMenu(); startPicker(); } }),
        h("button", { class: "link", text: "Cancel", onclick: closeMenu }),
      ]),
    ]);
    root.appendChild(menu);
    var r = target.getBoundingClientRect();
    var top = Math.min(window.innerHeight - 280, Math.max(12, r.top + 8));
    var left = Math.min(window.innerWidth - 292, Math.max(12, r.left + 8));
    menu.style.top = top + "px";
    menu.style.left = left + "px";
    var esc = function (e) {
      if (e.key === "Escape") { closeMenu(); document.removeEventListener("keydown", esc, true); }
    };
    document.addEventListener("keydown", esc, true);
  }

  /* ------------------------------------------------------------------ */
  /* Selection → Explain button                                          */
  /* ------------------------------------------------------------------ */
  var selBtn = null;
  function currentSelection() {
    var sel = (shadow && shadow.getSelection && shadow.getSelection()) || window.getSelection();
    var text = sel ? String(sel).trim() : "";
    if (!text && sel !== window.getSelection()) {
      sel = window.getSelection();
      text = sel ? String(sel).trim() : "";
    }
    return { sel: sel, text: text };
  }
  function contextFor(sel) {
    try {
      var node = sel.anchorNode;
      var el = node && (node.nodeType === 1 ? node : node.parentElement);
      var block = el && el.closest("p, li, blockquote, td, dd, section, article, div");
      return block ? block.textContent.replace(/\s+/g, " ").trim().slice(0, 1400) : "";
    } catch (e) {
      return "";
    }
  }
  function hideSelBtn() {
    if (selBtn) selBtn.remove();
    selBtn = null;
  }
  function onSelectionMaybe(e) {
    if (!IS_TOP && window.innerWidth < 300) return;
    if (!prefs.understanding.selectionButton) return;
    if (e && e.composedPath && e.composedPath().some(function (n) { return n.classList && (n.classList.contains("panel") || n.classList.contains("sel-btn")); })) return;
    setTimeout(function () {
      var s = currentSelection();
      if (!s.text || s.text.length < 3 || s.text.length > 4000 || !s.sel.rangeCount) return hideSelBtn();
      var r = s.sel.getRangeAt(0).getBoundingClientRect();
      if (!r.width && !r.height) return hideSelBtn();
      var root = ui();
      hideSelBtn();
      var text = s.text, ctx = contextFor(s.sel);
      selBtn = h("button", {
        class: "sel-btn",
        onmousedown: function (ev) { ev.preventDefault(); },
        onclick: function () { hideSelBtn(); openExplain(text, ctx); },
      }, [h("span", { class: "dot" }), "Explain with CLEAR"]);
      root.appendChild(selBtn);
      selBtn.style.top = Math.min(window.innerHeight - 44, r.bottom + 8) + "px";
      selBtn.style.left = Math.max(8, Math.min(window.innerWidth - 200, r.left)) + "px";
    }, 10);
  }
  document.addEventListener("mouseup", onSelectionMaybe);
  document.addEventListener("mousedown", function (e) {
    if (selBtn && e.composedPath().indexOf(selBtn) === -1) hideSelBtn();
  });
  window.addEventListener("scroll", hideSelBtn, { passive: true });

  /* ------------------------------------------------------------------ */
  /* Explain panel                                                       */
  /* ------------------------------------------------------------------ */
  var panel = null;
  var cache = {};

  function prefLabel(id) {
    var f = CLEAR_UNDERSTANDING.filter(function (u) { return u.id === id; })[0];
    return f ? f.label : id;
  }

  function renderExplanation(text) {
    var wrap = h("div", { class: "explanation" });
    var lines = text.split("\n").map(function (l) { return l.trim(); }).filter(Boolean);
    var list = null;
    lines.forEach(function (l) {
      var m = l.match(/^(\d+)[.)]\s+(.*)$/);
      var b = l.match(/^[-*•]\s+(.*)$/);
      if (m || b) {
        var tag = m ? "ol" : "ul";
        if (!list || list.tagName.toLowerCase() !== tag) {
          list = h(tag);
          wrap.appendChild(list);
        }
        list.appendChild(h("li", { text: m ? m[2] : b[1] }));
      } else {
        list = null;
        wrap.appendChild(h("p", { text: l }));
      }
    });
    return wrap;
  }

  function openExplain(text, context) {
    text = (text || "").trim();
    if (!text) {
      toast("Select some text first, then choose Explain with CLEAR.");
      return;
    }
    var root = ui();
    if (panel) panel.remove();
    var style = prefs.understanding.style;
    var body = h("div", { class: "result" });
    var chips = h("div", { class: "chips", role: "radiogroup", "aria-label": "Explanation style" });

    var quote = h("blockquote", { class: "quote", text: "“" + (text.length > 600 ? text.slice(0, 600) + "…" : text) + "”" });
    var prefsLine = prefs.understanding.prefs.length
      ? h("p", { class: "using" }, [
          h("span", { text: "Using your preferences: " }),
          h("span", { class: "using-list", text: prefs.understanding.prefs.map(prefLabel).join(" · ") }),
        ])
      : null;

    function drawChips() {
      chips.textContent = "";
      CLEAR_STYLES.forEach(function (s) {
        chips.appendChild(
          h("button", {
            class: "chip" + (s.id === style ? " on" : ""),
            role: "radio",
            "aria-checked": String(s.id === style),
            text: s.label,
            onclick: function () { style = s.id; drawChips(); run(); },
          }),
        );
      });
    }

    function showResult(d, partial) {
      body.textContent = "";
      var styleName = CLEAR_STYLES.filter(function (s) { return s.id === style; })[0].label;
      body.appendChild(h("div", { class: "label", text: styleName }));
      body.appendChild(renderExplanation(d.explanation || ""));
      if (d.keyTerms && d.keyTerms.length) {
        body.appendChild(h("div", { class: "label", text: "Key terms kept" }));
        body.appendChild(
          h("dl", { class: "terms" }, d.keyTerms.reduce(function (acc, t) {
            acc.push(h("dt", { text: t.term }));
            acc.push(h("dd", { text: t.meaning }));
            return acc;
          }, [])),
        );
      }
      if (d.says || d.implies) {
        body.appendChild(
          h("div", { class: "split" }, [
            h("div", { class: "says" }, [h("div", { class: "label", text: "What it says" }), h("p", { text: d.says })]),
            h("div", { class: "implies" }, [h("div", { class: "label", text: "What it implies" }), h("p", { text: d.implies })]),
          ]),
        );
      }
      if (d.ambiguity && d.ambiguity.length) {
        body.appendChild(
          h("div", { class: "ambig" }, [
            h("div", { class: "label", text: "⚑ Unclear in the original" }),
            h("ul", null, d.ambiguity.map(function (a) { return h("li", { text: a }); })),
          ]),
        );
      }
      if (partial) return;
      body.appendChild(
        h("div", { class: "actions" }, [
          h("button", {
            class: "btn ghost",
            text: "Copy",
            onclick: function (ev) {
              var out = (d.explanation || "") + (d.keyTerms && d.keyTerms.length ? "\n\nKey terms:\n" + d.keyTerms.map(function (t) { return "- " + t.term + ": " + t.meaning; }).join("\n") : "");
              navigator.clipboard.writeText(out).then(function () { ev.target.textContent = "Copied"; });
            },
          }),
          h("button", { class: "btn ghost", text: "Explain again", onclick: function () { delete cache[style]; run(); } }),
        ]),
      );
    }

    function run() {
      if (cache[style]) return showResult(cache[style]);
      body.textContent = "";
      body.appendChild(
        h("div", { class: "loading", "aria-live": "polite" }, [
          h("div", { class: "bar w80" }), h("div", { class: "bar w95" }), h("div", { class: "bar w60" }),
          h("p", { class: "muted", text: "Reading carefully — keeping the meaning intact…" }),
        ]),
      );
      var asked = style;
      var port = chrome.runtime.connect({ name: "clear-explain" });
      port.onMessage.addListener(function (m) {
        if (asked !== style || !panel) { port.disconnect(); return; }
        if (m.partial) { if (m.partial.explanation) showResult(m.partial, true); return; }
        var res = m.done;
        port.disconnect();
        if (!res || !res.ok) {
          body.textContent = "";
          body.appendChild(
            h("div", { class: "error" }, [
              h("p", { text: (res && res.error) || "Something went wrong." }),
              h("button", { class: "btn", text: "Try again", onclick: run }),
            ]),
          );
          return;
        }
        cache[asked] = res.data;
        showResult(res.data);
      });
      port.postMessage({
        payload: {
          text: text.slice(0, 4000),
          style: asked,
          prefs: prefs.understanding.prefs,
          context: (context || "").slice(0, 600) || undefined,
          pageTitle: (document.title || "").slice(0, 300) || undefined,
        },
      });
    }

    panel = h("aside", { class: "panel", role: "dialog", "aria-label": "CLEAR explanation" }, [
      h("header", null, [
        h("div", { class: "brand" }, [h("span", { class: "dot" }), h("strong", { text: "CLEAR" }), h("span", { class: "muted", text: "Explain" })]),
        h("button", { class: "icon-btn", "aria-label": "Close", text: "✕", onclick: function () { panel.remove(); panel = null; } }),
      ]),
      h("div", { class: "scroll" }, [
        h("div", { class: "label", text: "Original text" }),
        quote,
        h("div", { class: "label", text: "How would you like CLEAR to explain it?" }),
        chips,
        prefsLine,
        body,
        h("p", { class: "fine" }, [
          "CLEAR keeps key terms, separates what is said from what is implied, and flags anything unclear. ",
          h("button", { class: "link", text: "Edit preferences", onclick: function () { chrome.runtime.sendMessage({ type: "open-options" }); } }),
        ]),
      ]),
    ]);
    root.appendChild(panel);
    drawChips();
    run();
  }

  /* ------------------------------------------------------------------ */
  /* Reading mode                                                        */
  /* ------------------------------------------------------------------ */
  var reader = null;
  var ALLOWED = "h1,h2,h3,h4,h5,h6,p,ul,ol,li,blockquote,pre,code,figure,figcaption,img,a,strong,em,b,i,table,thead,tbody,tr,td,th,hr,br,dl,dt,dd,sup,sub".split(",");
  var DROP = "script,style,noscript,iframe,form,nav,aside,footer,button,input,select,textarea,svg,canvas,video,audio,object,embed,[aria-hidden='true'],[role='navigation'],[role='complementary'],[class*='share' i],[class*='related' i],[class*='comment' i],[class*='newsletter' i],[class*='promo' i],[class*='language' i],[class*='dropdown' i],[class*='menu' i],[class*='toc' i],[class*='editsection' i],[class*='navbox' i],[hidden],[role='menu'],[role='dialog'],.mw-jump-link,.noprint," + AD_SELECTORS;

  function textLen(el) {
    var n = 0;
    el.querySelectorAll("p").forEach(function (p) { n += p.textContent.trim().length; });
    return n;
  }
  function findMain() {
    var known = document.querySelector("#mw-content-text .mw-parser-output, [itemprop='articleBody'], .article-body, .entry-content, .post-content, article");
    if (known && textLen(known) > 400) return known;
    var best = null, bestScore = 0;
    var cands = document.querySelectorAll("article, main, [role='main'], .post-content, .entry-content, .article-body, #content, .content, section, div");
    var limit = Math.min(cands.length, 2500);
    for (var i = 0; i < limit; i++) {
      var el = cands[i];
      var ps = el.querySelectorAll(":scope > p, :scope > div > p");
      if (ps.length < 2 && !el.matches("article, main, [role='main']")) continue;
      var score = textLen(el);
      if (el.matches("article, main, [role='main']")) score *= 1.25;
      var links = 0;
      el.querySelectorAll("a").forEach(function (a) { links += a.textContent.length; });
      score -= links * 0.5;
      if (score > bestScore) { bestScore = score; best = el; }
    }
    // Narrow down to the child that holds most of the reading text.
    while (best) {
      var total = textLen(best), next = null;
      for (var j = 0; j < best.children.length; j++) {
        if (textLen(best.children[j]) >= total * 0.8) { next = best.children[j]; break; }
      }
      if (!next || total < 300) break;
      best = next;
    }
    return best || document.body;
  }
  function sanitize(src, out) {
    src.childNodes.forEach(function (n) {
      if (n.nodeType === 3) {
        out.appendChild(document.createTextNode(n.textContent));
        return;
      }
      if (n.nodeType !== 1) return;
      if (n.matches && n.matches(DROP)) return;
      var tag = n.tagName.toLowerCase();
      if (ALLOWED.indexOf(tag) === -1) {
        sanitize(n, out);
        return;
      }
      var el = document.createElement(tag);
      if (tag === "a") {
        var href = n.href;
        if (/^https?:/i.test(href)) {
          el.setAttribute("href", href);
          el.setAttribute("target", "_blank");
          el.setAttribute("rel", "noopener noreferrer");
        }
      }
      if (tag === "img") {
        var s = n.currentSrc || n.src || n.getAttribute("data-src") || "";
        if (!/^https?:/i.test(s) || (n.naturalWidth && n.naturalWidth < 80)) return;
        el.setAttribute("src", s);
        el.setAttribute("alt", n.alt || "");
        el.setAttribute("loading", "lazy");
      }
      sanitize(n, el);
      if (tag !== "img" && tag !== "br" && tag !== "hr" && !el.textContent.trim() && !el.querySelector("img")) return;
      out.appendChild(el);
    });
    return out;
  }

  function openReader() {
    var root = ui();
    if (reader) { closeReader(); return; }
    var main = findMain();
    var content = sanitize(main, document.createElement("div"));
    var title = (document.querySelector("h1") && document.querySelector("h1").textContent.trim()) || document.title;
    var firstH1 = content.querySelector("h1");
    if (firstH1 && firstH1.textContent.trim() === title) firstH1.remove();
    var site = (document.querySelector("meta[property='og:site_name']") || {}).content || HOST;
    var author = (document.querySelector("meta[name='author']") || {}).content || "";
    var words = content.textContent.trim().split(/\s+/).length;
    var rp = prefs.reading;

    var article = h("article", { class: "r-article" }, [
      h("div", { class: "r-meta", text: site + (author ? " · " + author : "") + " · " + Math.max(1, Math.round(words / 230)) + " min read" }),
      h("h1", { class: "r-title", text: title }),
      content,
    ]);

    function seg(name, key, options) {
      var g = h("div", { class: "seg", role: "group", "aria-label": name });
      options.forEach(function (o) {
        g.appendChild(h("button", {
          class: rp[key] === o[0] ? "on" : "",
          text: o[1],
          title: name + ": " + o[1],
          onclick: function () { rp[key] = o[0]; saveReading(); },
        }));
      });
      return g;
    }
    function step(label, key, delta, min, max, fmt) {
      return h("div", { class: "seg", role: "group", "aria-label": label }, [
        h("button", { text: "−", title: label + " smaller", onclick: function () { rp[key] = Math.max(min, +(rp[key] - delta).toFixed(2)); saveReading(); } }),
        h("span", { class: "seg-val", text: fmt(rp[key]) }),
        h("button", { text: "+", title: label + " larger", onclick: function () { rp[key] = Math.min(max, +(rp[key] + delta).toFixed(2)); saveReading(); } }),
      ]);
    }
    var toolbar = h("div", { class: "r-toolbar" });
    function drawToolbar() {
      toolbar.textContent = "";
      toolbar.appendChild(h("div", { class: "brand" }, [h("span", { class: "dot" }), h("strong", { text: "CLEAR" }), h("span", { class: "muted", text: "Reading mode" })]));
      toolbar.appendChild(seg("Font", "font", [["serif", "Serif"], ["sans", "Sans"], ["readable", "Readable"]]));
      toolbar.appendChild(step("Text size", "size", 1, 14, 32, function (v) { return v + "px"; }));
      toolbar.appendChild(step("Line spacing", "lineHeight", 0.15, 1.3, 2.5, function (v) { return v.toFixed(2); }));
      toolbar.appendChild(seg("Width", "width", [["narrow", "Narrow"], ["medium", "Medium"], ["wide", "Wide"]]));
      toolbar.appendChild(seg("Colors", "theme", [["paper", "Paper"], ["light", "Light"], ["dark", "Dark"], ["contrast", "Contrast"]]));
      toolbar.appendChild(seg("Images", "images", [["show", "Images"], ["blur", "Blur"], ["hide", "No images"]]));
      toolbar.appendChild(h("button", { class: "toggle" + (rp.focus ? " on" : ""), "aria-pressed": String(rp.focus), text: "Focus line", title: "Dim everything except the paragraph you're reading", onclick: function () { rp.focus = !rp.focus; saveReading(); } }));
      toolbar.appendChild(h("button", { class: "icon-btn close", "aria-label": "Close reading mode", text: "✕", onclick: closeReader }));
    }
    function paint() {
      reader.className = "reader theme-" + rp.theme + " font-" + rp.font + " w-" + rp.width + " img-" + rp.images + (rp.focus ? " focus" : "");
      reader.style.setProperty("--r-size", rp.size + "px");
      reader.style.setProperty("--r-lh", rp.lineHeight);
      drawToolbar();
    }
    function saveReading() {
      prefs.reading = rp;
      clearSave(prefs);
      paint();
    }
    reader = h("div", { class: "reader", role: "dialog", "aria-label": "CLEAR reading mode" }, [toolbar, h("div", { class: "r-scroll" }, [article])]);
    reader.addEventListener("mouseover", function (e) {
      if (!rp.focus) return;
      var t = e.target.closest && e.target.closest("p, li, blockquote, h2, h3, figure");
      reader.querySelectorAll(".lit").forEach(function (n) { if (n !== t) n.classList.remove("lit"); });
      if (t) t.classList.add("lit");
    });
    reader.addEventListener("click", function (e) {
      var img = e.target.closest && e.target.closest("img");
      if (img && rp.images === "blur") img.classList.add("revealed");
    });
    root.appendChild(reader);
    paint();
    document.documentElement.setAttribute("data-clear-reading", "");
    document.documentElement.style.setProperty("overflow", "hidden", "important");
    document.addEventListener("keydown", readerKey, true);
  }
  function readerKey(e) {
    if (e.key === "Escape" && reader && !panel) closeReader();
  }
  function closeReader() {
    if (reader) reader.remove();
    reader = null;
    document.documentElement.removeAttribute("data-clear-reading");
    document.documentElement.style.removeProperty("overflow");
    document.removeEventListener("keydown", readerKey, true);
  }

  /* ------------------------------------------------------------------ */
  /* Messaging + boot                                                    */
  /* ------------------------------------------------------------------ */
  chrome.runtime.onMessage.addListener(function (msg, _s, sendResponse) {
    if (!msg) return;
    if (msg.type === "status") {
      if (IS_TOP) sendResponse({ host: HOST, paused: isPaused(), sessionRules: sessionRules.length, reading: !!reader });
      return;
    }
    if (msg.type === "get-selection") {
      if (IS_TOP) sendResponse({ text: currentSelection().text || "" });
      return;
    }
    if (msg.type === "open-explain") {
      var s = currentSelection();
      openExplain(msg.text || s.text, s.sel ? contextFor(s.sel) : "");
    } else if (msg.type === "explain-selection") {
      var cur = currentSelection();
      if (cur.text) openExplain(cur.text, contextFor(cur.sel));
      else if (IS_TOP) toast("Select some text first, then press Alt+Shift+E.");
    } else if (msg.type === "start-picker" && IS_TOP) {
      startPicker();
    } else if (msg.type === "pick-context-target") {
      if (lastContextTarget && lastContextTarget.nodeType === 1) openMenu(lastContextTarget);
      else startPicker();
    } else if (msg.type === "toggle-reading" && IS_TOP) {
      openReader();
    } else if (msg.type === "clear-session-rules") {
      sessionRules = [];
      apply();
    }
  });

  chrome.storage.onChanged.addListener(function (changes, area) {
    if (area === "local" && changes.clearPrefs) {
      prefs = clearMerge(CLEAR_DEFAULTS, changes.clearPrefs.newValue || {});
      if (!prefs.customize.popups) {
        document.querySelectorAll("[data-clear-hidden-popup]").forEach(function (n) { n.removeAttribute("data-clear-hidden-popup"); });
        document.documentElement.removeAttribute("data-clear-unlocked");
      }
      if (!prefs.customize.images) {
        document.querySelectorAll("[data-clear-revealed]").forEach(function (n) { n.removeAttribute("data-clear-revealed"); });
      }
      apply();
    }
  });

  mountStyle();
  clearLoad().then(function (p) {
    prefs = p;
    apply();
  });
  function onReady() {
    apply();
    if (document.body) observer.observe(document.body, { childList: true, subtree: true });
  }
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", onReady);
  else onReady();
  window.addEventListener("load", function () { if (!isPaused() && prefs.customize.popups) setTimeout(scanOverlays, 800); });

  /* ------------------------------------------------------------------ */
  /* UI styles (inside shadow root)                                      */
  /* ------------------------------------------------------------------ */
  var UI_CSS = [
    ":host{all:initial}",
    "*{box-sizing:border-box}",
    ".panel,.menu,.sel-btn,.toast,.pick-bar,.hl-label,.reader{--ink:#344b60;--ink-2:#5f7a90;--paper:#f5f8fa;--card:#f5f8fa;--line:#c8d9e6;--teal:#344b60;--teal-2:#dce8f1;--hi:#afc4d5;--hi-2:#dce8f1;--warn:#9a5b12;--warn-bg:#fdf1de;font-family:ui-sans-serif,system-ui,-apple-system,'Segoe UI',Roboto,sans-serif;color:var(--ink);font-size:14px;line-height:1.5;-webkit-font-smoothing:antialiased}",
    ".dot{display:inline-block;width:10px;height:10px;border-radius:50%;background:var(--teal);box-shadow:0 0 0 3px var(--hi)}",
    ".muted{color:var(--ink-2)}",
    "button{font:inherit;color:inherit;cursor:pointer}",
    ".link{background:none;border:0;padding:0;color:var(--teal);text-decoration:underline;text-underline-offset:3px;font-size:13px}",
    ".hl{position:fixed;z-index:2147483646;pointer-events:none;border:2px solid #344b60;background:rgba(175,196,213,.3);border-radius:6px;transition:all .06s}",
    ".hl-label{position:fixed;z-index:2147483647;pointer-events:none;background:#344b60;color:#f5f8fa;font:600 12px ui-sans-serif,system-ui,sans-serif;padding:3px 8px;border-radius:6px}",
    ".pick-bar{position:fixed;z-index:2147483647;left:50%;bottom:20px;transform:translateX(-50%);background:var(--ink);color:var(--paper);padding:10px 16px;border-radius:999px;box-shadow:0 10px 30px rgba(0,0,0,.25);display:flex;gap:6px;align-items:center;font-size:13px}",
    ".pick-bar strong{color:var(--hi);letter-spacing:.12em;margin-right:6px}",
    "kbd{background:rgba(255,255,255,.15);border-radius:4px;padding:1px 6px;font:600 12px ui-monospace,monospace}",
    ".menu{position:fixed;z-index:2147483647;width:280px;background:var(--card);border:1px solid var(--line);border-radius:16px;box-shadow:0 18px 50px rgba(28,42,51,.22);padding:8px}",
    ".menu-head{display:flex;align-items:center;gap:8px;padding:8px 10px 10px;border-bottom:1px solid var(--line);margin-bottom:6px}",
    ".menu-head strong{letter-spacing:.14em;font-size:12px}",
    ".menu-target{margin-left:auto;font-size:12px;color:var(--ink-2)}",
    ".menu-item{display:flex;align-items:center;gap:10px;width:100%;text-align:left;background:none;border:0;border-radius:10px;padding:10px 10px;font-size:14px;font-weight:600}",
    ".menu-item:hover,.menu-item:focus-visible{background:var(--hi-2);outline:none}",
    ".ico{width:26px;height:26px;border-radius:8px;background:var(--teal-2);color:var(--teal);display:inline-flex;align-items:center;justify-content:center;font-size:15px}",
    ".menu-always{display:flex;align-items:center;gap:8px;padding:10px;margin-top:4px;border-top:1px solid var(--line);font-size:13px;cursor:pointer}",
    ".menu-always input{accent-color:#344b60;width:16px;height:16px}",
    ".menu-foot{display:flex;justify-content:space-between;padding:6px 10px 4px}",
    ".sel-btn{position:fixed;z-index:2147483647;display:inline-flex;align-items:center;gap:8px;background:var(--ink);color:var(--paper);border:0;border-radius:999px;padding:8px 14px 8px 12px;font-weight:600;font-size:13px;box-shadow:0 8px 24px rgba(28,42,51,.3)}",
    ".sel-btn:hover{background:#26394a}",
    ".toast{position:fixed;z-index:2147483647;left:50%;bottom:24px;transform:translateX(-50%);background:var(--ink);color:var(--paper);padding:10px 16px;border-radius:12px;display:flex;gap:14px;align-items:center;box-shadow:0 10px 30px rgba(0,0,0,.25);font-size:13px}",
    ".toast .link{color:var(--hi)}",
    ".panel{position:fixed;z-index:2147483647;top:16px;right:16px;bottom:16px;width:min(400px,calc(100vw - 32px));background:rgba(245,248,250,.88);backdrop-filter:blur(18px) saturate(1.2);-webkit-backdrop-filter:blur(18px);border:1px solid rgba(255,255,255,.7);border-radius:24px;box-shadow:0 24px 70px rgba(28,42,51,.25);display:flex;flex-direction:column;overflow:hidden;animation:clr-in .18s ease-out}",
    "@keyframes clr-in{from{opacity:0;transform:translateX(12px)}to{opacity:1;transform:none}}",
    ".panel header,.r-toolbar .brand{display:flex;align-items:center;gap:8px}",
    ".panel header{justify-content:space-between;padding:14px 16px;border-bottom:1px solid var(--line);background:var(--card)}",
    ".brand strong{letter-spacing:.16em;font-size:13px}",
    ".brand{display:flex;align-items:center;gap:8px}",
    ".icon-btn{border:1px solid var(--line);background:var(--card);border-radius:10px;width:32px;height:32px;font-size:13px}",
    ".icon-btn:hover{background:var(--hi-2)}",
    ".scroll{overflow:auto;padding:16px 18px 20px}",
    ".label{font-size:11px;font-weight:700;letter-spacing:.12em;text-transform:uppercase;color:var(--ink-2);margin:16px 0 8px}",
    ".scroll>.label:first-child{margin-top:0}",
    ".quote{margin:0;padding:12px 14px;background:var(--hi-2);border-left:3px solid var(--hi);border-radius:4px 12px 12px 4px;font-family:'Iowan Old Style','Palatino Linotype',Georgia,serif;font-size:15px;line-height:1.55;max-height:180px;overflow:auto}",
    ".chips{display:flex;flex-wrap:wrap;gap:6px}",
    ".chip{border:1px solid var(--line);background:var(--card);border-radius:999px;padding:6px 12px;font-size:13px;font-weight:600}",
    ".chip:hover{border-color:var(--teal)}",
    ".chip.on{background:var(--teal);border-color:var(--teal);color:#fff}",
    ".using{font-size:12px;color:var(--ink-2);margin:10px 0 0}",
    ".using-list{color:var(--teal);font-weight:600}",
    ".result{margin-top:6px}",
    ".explanation{background:var(--card);border:1px solid var(--line);border-radius:14px;padding:12px 16px;font-size:15px}",
    ".explanation p{margin:6px 0}",
    ".explanation ol,.explanation ul{margin:6px 0;padding-left:22px}",
    ".explanation li{margin:6px 0;padding-left:4px}",
    ".explanation ol li::marker{color:var(--teal);font-weight:700}",
    ".terms{display:grid;grid-template-columns:auto 1fr;gap:6px 12px;margin:0;font-size:13px}",
    ".terms dt{font-weight:700;background:var(--teal-2);color:var(--teal);border-radius:6px;padding:1px 8px;height:fit-content}",
    ".terms dd{margin:0;color:var(--ink-2)}",
    ".split{display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-top:4px}",
    ".split>div{background:var(--card);border:1px solid var(--line);border-radius:12px;padding:0 12px 10px;font-size:13px}",
    ".split .label{margin-top:10px}",
    ".split p{margin:0}",
    ".ambig{margin-top:10px;background:var(--warn-bg);border-radius:12px;padding:0 12px 8px;font-size:13px;color:var(--warn)}",
    ".ambig .label{color:var(--warn);margin-top:0;padding-top:10px}",
    ".ambig ul{margin:0;padding-left:18px}",
    ".actions{display:flex;gap:8px;margin-top:14px}",
    ".btn{border:0;background:var(--teal);color:#fff;border-radius:10px;padding:8px 14px;font-weight:600;font-size:13px}",
    ".btn.ghost{background:var(--card);border:1px solid var(--line);color:var(--ink)}",
    ".btn.ghost:hover{background:var(--hi-2)}",
    ".loading{padding:8px 0}",
    ".bar{height:12px;border-radius:6px;background:linear-gradient(90deg,var(--line),var(--hi-2),var(--line));background-size:200% 100%;animation:clr-sh 1.2s linear infinite;margin:10px 0}",
    ".w80{width:80%}.w95{width:95%}.w60{width:60%}",
    "@keyframes clr-sh{to{background-position:-200% 0}}",
    ".error{background:var(--warn-bg);color:var(--warn);border-radius:12px;padding:12px 14px}",
    ".error p{margin:0 0 10px}",
    ".fine{font-size:12px;color:var(--ink-2);margin-top:18px;border-top:1px solid var(--line);padding-top:12px}",
    ".reader{position:fixed;inset:0;z-index:2147483645;display:flex;flex-direction:column;--r-bg:#f5f8fa;--r-fg:#2c3e50;--r-muted:#829fb5;--r-link:#344b60;--r-bar:#dce8f1;background:var(--r-bg);color:var(--r-fg)}",
    ".reader.theme-light{--r-bg:#ffffff;--r-fg:#344b60;--r-muted:#5f6b72;--r-bar:#f3f4f2}",
    ".reader.theme-dark{--r-bg:#151b1f;--r-fg:#e6e1d6;--r-muted:#98a2a6;--r-link:#8fd3cf;--r-bar:#1d252a}",
    ".reader.theme-contrast{--r-bg:#000;--r-fg:#fff;--r-muted:#afc4d5;--r-link:#afc4d5;--r-bar:#111}",
    ".r-toolbar{display:flex;flex-wrap:wrap;align-items:center;gap:8px;padding:10px 16px;background:var(--r-bar);border-bottom:1px solid rgba(0,0,0,.08);color:var(--r-fg)}",
    ".r-toolbar .brand{margin-right:8px}",
    ".r-toolbar .close{margin-left:auto}",
    ".seg{display:inline-flex;align-items:center;border:1px solid rgba(127,127,127,.35);border-radius:10px;overflow:hidden}",
    ".seg button{border:0;background:transparent;padding:6px 10px;font-size:12px;font-weight:600;color:var(--r-fg)}",
    ".seg button.on{background:var(--r-fg);color:var(--r-bg)}",
    ".seg-val{font-size:12px;padding:0 6px;min-width:44px;text-align:center;font-variant-numeric:tabular-nums}",
    ".toggle{border:1px solid rgba(127,127,127,.35);background:transparent;border-radius:10px;padding:6px 10px;font-size:12px;font-weight:600;color:var(--r-fg)}",
    ".toggle.on{background:var(--hi);color:#344b60;border-color:var(--hi)}",
    ".reader .icon-btn{background:transparent;color:var(--r-fg);border-color:rgba(127,127,127,.35)}",
    ".r-scroll{flex:1;overflow:auto;padding:48px 24px 120px}",
    ".r-article{margin:0 auto;max-width:680px;font-size:var(--r-size);line-height:var(--r-lh)}",
    ".w-narrow .r-article{max-width:560px}.w-wide .r-article{max-width:860px}",
    ".font-serif .r-article{font-family:'Iowan Old Style','Palatino Linotype',Georgia,serif}",
    ".font-sans .r-article{font-family:ui-sans-serif,system-ui,-apple-system,'Segoe UI',Roboto,sans-serif}",
    ".font-readable .r-article{font-family:Verdana,Tahoma,sans-serif;letter-spacing:.02em;word-spacing:.08em}",
    ".r-meta{font-family:ui-sans-serif,system-ui,sans-serif;font-size:13px;color:var(--r-muted);letter-spacing:.04em;text-transform:uppercase}",
    ".r-title{font-size:2em;line-height:1.15;margin:.3em 0 .8em}",
    ".r-article h2,.r-article h3{line-height:1.25;margin:1.6em 0 .5em}",
    ".r-article p,.r-article li{margin:0 0 1em}",
    ".r-article a{color:var(--r-link)}",
    ".r-article img{max-width:100%;height:auto;border-radius:10px;display:block;margin:1.2em auto}",
    ".r-article blockquote{margin:1.2em 0;padding-left:1em;border-left:3px solid var(--r-link);color:var(--r-muted)}",
    ".r-article pre{overflow:auto;background:rgba(127,127,127,.12);padding:12px;border-radius:8px;font-size:.8em}",
    ".r-article figcaption{font-size:.75em;color:var(--r-muted);text-align:center}",
    ".img-hide .r-article img,.img-hide .r-article figure{display:none}",
    ".img-blur .r-article img:not(.revealed){filter:blur(18px);cursor:pointer}",
    ".focus .r-article p,.focus .r-article li,.focus .r-article blockquote,.focus .r-article h2,.focus .r-article h3,.focus .r-article figure{opacity:.28;transition:opacity .15s}",
    ".focus .r-article .lit{opacity:1}",
    "@media (prefers-reduced-motion:reduce){.panel{animation:none}.bar{animation:none}}",
  ].join("\n");
})();
