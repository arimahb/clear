/* Shared between popup, background and content scripts. Plain script (no modules). */
var CLEAR_DEFAULT_API = "https://clear-your-web-world.lovable.app";
// The public, published CLEAR site. Preview/dev addresses need a Lovable login and fail in a new tab.
var CLEAR_DASHBOARD_URL = "https://clear-your-web-world.lovable.app/dashboard";
function clearIsPrivateOrigin(o) { return !o || /localhost|127\.0\.0\.1|id-preview--|preview--|project--|lovableproject\.com/.test(o); }

var CLEAR_DEFAULTS = {
  name: "",
  pausedHosts: [],
  customize: {
    ads: { on: true, mode: "blur" },
    autoplay: true,
    animations: true,
    images: false,
    popups: true,
    backgrounds: false,
  },
  visual: {
    enabled: false,
    font: "original", // original | sans | serif | readable
    textScale: 100, // percent
    lineHeight: 1.6,
    letterSpacing: 0, // em
    theme: "original", // original | paper | dark | contrast
    filter: "", // set from the CLEAR dashboard colors settings
  },
  reading: {
    font: "serif",
    size: 20,
    lineHeight: 1.75,
    width: "medium",
    theme: "paper",
    images: "show",
    focus: false,
  },
  understanding: {
    style: "simpler",
    prefs: ["simple"],
    selectionButton: true,
  },
  siteRules: {}, // { [host]: [{ selector, action, label }] }
  apiBase: CLEAR_DEFAULT_API,
};

var CLEAR_STYLES = [
  { id: "simpler", label: "Simpler language" },
  { id: "steps", label: "Step-by-step" },
  { id: "example", label: "Real-life example" },
  { id: "summary", label: "Short summary" },
  { id: "detail", label: "Explain in detail" },
];

var CLEAR_UNDERSTANDING = [
  { id: "simple", label: "Prefer simple language over technical terminology" },
  { id: "numbered", label: "Prefer numbered steps over paragraphs" },
  { id: "examples", label: "I understand better through practical examples" },
  { id: "concise", label: "Prefer concise explanations" },
  { id: "context", label: "I need extra context before a new concept" },
  { id: "detailed", label: "Prefer detailed explanations" },
];

function clearMerge(base, over) {
  if (Array.isArray(base)) return Array.isArray(over) ? over.slice() : base.slice();
  if (base && typeof base === "object") {
    var out = {};
    var keys = Object.keys(base);
    if (over && typeof over === "object") {
      Object.keys(over).forEach(function (k) {
        if (keys.indexOf(k) === -1) keys.push(k);
      });
    }
    keys.forEach(function (k) {
      if (!(k in base)) out[k] = over[k];
      else if (over && typeof over === "object" && k in over) out[k] = clearMerge(base[k], over[k]);
      else out[k] = clearMerge(base[k], undefined);
    });
    return out;
  }
  return over === undefined ? base : over;
}

function clearLoad() {
  return chrome.storage.local.get("clearPrefs").then(function (r) {
    return clearMerge(CLEAR_DEFAULTS, r.clearPrefs || {});
  });
}

function clearSave(prefs) {
  return chrome.storage.local.set({ clearPrefs: prefs });
}

function clearCountEnabled(prefs) {
  var c = prefs.customize;
  return [c.ads.on, c.autoplay, c.animations, c.images, c.popups, c.backgrounds].filter(Boolean).length;
}

/* Mirrors parseExplainOutput on the server; works on partial (streaming) text too. */
function clearParse(raw) {
  var LABELS = ["EXPLANATION", "KEY TERMS", "SAYS", "IMPLIES", "AMBIGUITY"];
  var re = new RegExp("^\\s*(" + LABELS.join("|") + ")\\s*:\\s*", "gim");
  var marks = [], m;
  while ((m = re.exec(raw))) marks.push({ label: m[1].toUpperCase(), start: m.index, end: m.index + m[0].length });
  if (!marks.length) return { explanation: /^\s*[A-Z ]{0,12}$/.test(raw) ? "" : raw.trim(), keyTerms: [], says: "", implies: "", ambiguity: [] };
  var sec = {};
  marks.forEach(function (k, i) { sec[k.label] = raw.slice(k.end, marks[i + 1] ? marks[i + 1].start : raw.length).trim(); });
  function bullets(s) { return (s || "").split("\n").map(function (l) { return l.replace(/^\s*[-*•]\s*/, "").trim(); }).filter(Boolean); }
  return {
    explanation: sec["EXPLANATION"] || "",
    keyTerms: bullets(sec["KEY TERMS"]).map(function (l) { var p = l.split(/\s*(?:::|—|–| - |:)\s*/); return { term: (p[0] || "").trim(), meaning: p.slice(1).join(" ").trim() }; }).filter(function (t) { return t.term && t.meaning; }),
    says: sec["SAYS"] || "",
    implies: sec["IMPLIES"] || "",
    ambiguity: bullets(sec["AMBIGUITY"]).filter(function (l) { return !/^none\.?$/i.test(l); }),
  };
}
