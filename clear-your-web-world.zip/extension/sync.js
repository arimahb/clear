/* Runs only on the CLEAR website. Copies the preferences you set in your
   CLEAR dashboard into the extension, so every site follows them. */
(function () {
  var KEY = "clear:prefs:v1";
  var last = "";
  function sync() {
    var raw;
    try { raw = localStorage.getItem(KEY); } catch (e) { return; }
    if (!raw || raw === last) return;
    last = raw;
    var s;
    try { s = JSON.parse(raw); } catch (e) { return; }
    clearLoad().then(function (p) {
      if (typeof s.name === "string") p.name = s.name;
      var c = s.customize || {};
      p.customize.ads = { on: !!c.ads, mode: (p.customize.ads && p.customize.ads.mode) || "blur" };
      var sen0 = s.sensory || {};
      ["autoplay", "animations", "images", "popups", "backgrounds"].forEach(function (k) { if (k in c) p.customize[k] = !!c[k]; });
      // Colors & motion settings ask for the same calming, so either one turns it on.
      if (sen0.pauseVideos) p.customize.autoplay = true;
      if (sen0.reduceAnimations || sen0.disableTransitions || sen0.reduceMovement) p.customize.animations = true;
      if (sen0.simplifyLayout || sen0.reduceClutter) p.customize.backgrounds = true;
      var sim = s.simplify || {};
      if (sim.style) p.understanding.style = sim.style;
      p.understanding.prefs = ["simple", "numbered", "examples", "concise", "context", "detailed"].filter(function (k) { return !!sim[k]; });
      var v = s.visual || {}, sen = s.sensory || {};
      var size = (v.fontSize || 16) + (sen.readableText ? 1 : 0);
      var spacing = (v.textSpacing || 0) + (sen.extraSpacing ? 1 : 0);
      p.visual.textScale = Math.round((size / 16) * 100);
      p.visual.lineHeight = +(1.6 + spacing * 0.12).toFixed(2);
      p.visual.letterSpacing = +(spacing * 0.012).toFixed(3);
      if (sen.readableText) p.visual.font = "readable";
      var f = [];
      if (sen.brightness && sen.brightness !== 100) f.push("brightness(" + sen.brightness / 100 + ")");
      if (sen.softContrast) f.push("contrast(0.92)");
      if (sen.reduceColors) f.push("saturate(0.6)");
      p.visual.filter = f.join(" ");
      p.visual.enabled = size !== 16 || spacing > 0 || !!sen.readableText || f.length > 0;
      if (!clearIsPrivateOrigin(location.origin) && location.protocol === "https:") p.apiBase = location.origin;
      p.syncedFrom = location.origin;
      p.syncedAt = Date.now();
      return clearSave(p);
    });
  }
  // Changes made in the extension pop-up flow back into the dashboard.
  chrome.storage.onChanged.addListener(function (ch, area) {
    if (area !== "local" || !ch.clearPrefs) return;
    var e = clearMerge(CLEAR_DEFAULTS, ch.clearPrefs.newValue || {});
    var raw = null, s = {};
    try { raw = localStorage.getItem(KEY); s = JSON.parse(raw || "{}") || {}; } catch (err) { return; }
    var next = JSON.parse(JSON.stringify(s));
    next.name = e.name || "";
    next.customize = Object.assign({}, s.customize || {}, {
      ads: !!e.customize.ads.on, autoplay: !!e.customize.autoplay, animations: !!e.customize.animations,
      images: !!e.customize.images, popups: !!e.customize.popups, backgrounds: !!e.customize.backgrounds,
    });
    var u = e.understanding.prefs || [];
    next.simplify = Object.assign({}, s.simplify || {}, { style: e.understanding.style });
    ["simple", "numbered", "examples", "concise", "context", "detailed"].forEach(function (k) { next.simplify[k] = u.indexOf(k) !== -1; });
    // Colors & motion switches can't be partly undone from here: clear them when the matching switch is turned off.
    if (next.sensory) {
      if (!e.customize.autoplay) next.sensory.pauseVideos = false;
      if (!e.customize.animations) { next.sensory.reduceAnimations = false; next.sensory.disableTransitions = false; next.sensory.reduceMovement = false; }
      if (!e.customize.backgrounds) { next.sensory.simplifyLayout = false; next.sensory.reduceClutter = false; }
    }
    var out = JSON.stringify(next);
    if (out === raw) return;
    try { localStorage.setItem(KEY, out); } catch (err) { return; }
    last = out;
    window.dispatchEvent(new StorageEvent("storage", { key: KEY }));
  });

  sync();
  setInterval(sync, 1500);
  document.documentElement.setAttribute("data-clear-extension", "1");
})();
