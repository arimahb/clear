importScripts("shared.js");

function setupMenus() {
  chrome.contextMenus.removeAll(function () {
    chrome.contextMenus.create({ id: "clear-explain", title: "Explain with CLEAR", contexts: ["selection"] });
    chrome.contextMenus.create({
      id: "clear-pick",
      title: "CLEAR: blur, hide or calm this…",
      contexts: ["page", "image", "video", "link", "frame"],
    });
    chrome.contextMenus.create({ id: "clear-reading", title: "CLEAR: open reading mode", contexts: ["page"] });
  });
}

chrome.runtime.onInstalled.addListener(setupMenus);
chrome.runtime.onStartup.addListener(setupMenus);

function sendToTab(tabId, msg, frameId) {
  var opts = typeof frameId === "number" ? { frameId: frameId } : { frameId: 0 };
  chrome.tabs.sendMessage(tabId, msg, opts).catch(function () {});
}

chrome.contextMenus.onClicked.addListener(function (info, tab) {
  if (!tab || tab.id == null) return;
  if (info.menuItemId === "clear-explain") {
    sendToTab(tab.id, { type: "open-explain", text: info.selectionText || "" }, info.frameId);
  } else if (info.menuItemId === "clear-pick") {
    sendToTab(tab.id, { type: "pick-context-target" }, info.frameId);
  } else if (info.menuItemId === "clear-reading") {
    sendToTab(tab.id, { type: "toggle-reading" });
  }
});

chrome.commands.onCommand.addListener(function (command, tab) {
  var run = function (t) {
    if (!t || t.id == null) return;
    if (command === "explain-selection") sendToTab(t.id, { type: "explain-selection" });
    if (command === "reading-mode") sendToTab(t.id, { type: "toggle-reading" });
    if (command === "pick-element") sendToTab(t.id, { type: "start-picker" });
  };
  if (tab) run(tab);
  else chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) { run(tabs[0]); });
});

var explainCache = new Map();
async function explain(payload) {
  var key = JSON.stringify([payload && payload.text, payload && payload.style, payload && payload.prefs]);
  if (explainCache.has(key)) return explainCache.get(key);
  var out = await explainUncached(payload);
  if (out.ok) {
    explainCache.set(key, out);
    if (explainCache.size > 50) explainCache.delete(explainCache.keys().next().value);
  }
  return out;
}

async function explainUncached(payload) {
  var prefs = await clearLoad();
  var base = (prefs.apiBase || CLEAR_DEFAULT_API).replace(/\/+$/, "");
  var first = await explainAt(base, payload);
  // Older CLEAR servers don't know the "detailed" preference yet: retry without it.
  if (!first.ok && payload && Array.isArray(payload.prefs) && payload.prefs.indexOf("detailed") !== -1) {
    payload = Object.assign({}, payload, { prefs: payload.prefs.filter(function (k) { return k !== "detailed"; }) });
    first = await explainAt(base, payload);
  }
  if (first.ok || base === CLEAR_DEFAULT_API) return first;
  return explainAt(CLEAR_DEFAULT_API, payload);
}

async function explainAt(base, payload) {
  try {
    var res = await fetch(base + "/api/public/explain", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    });
    var data = await res.json().catch(function () { return null; });
    if (!res.ok || !data) {
      return { ok: false, error: (data && data.error) || "CLEAR's AI service didn't respond (" + res.status + ")." };
    }
    return { ok: true, data: data };
  } catch (e) {
    return {
      ok: false,
      error: "Couldn't reach CLEAR's AI service. Check the AI endpoint in CLEAR settings.",
    };
  }
}

async function ping() {
  var prefs = await clearLoad();
  var base = (prefs.apiBase || CLEAR_DEFAULT_API).replace(/\/+$/, "");
  try {
    var res = await fetch(base + "/api/public/explain", { method: "GET" });
    var data = await res.json().catch(function () { return null; });
    return { ok: res.ok && !!data && data.service === "clear-explain" };
  } catch (e) {
    return { ok: false };
  }
}

// Streaming explanations: popup/content open a port named "clear-explain" and get {partial} then {done}.
async function streamAt(base, payload, onPartial) {
  var res = await fetch(base + "/api/public/explain", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(Object.assign({}, payload, { stream: true })),
  });
  if (!res.ok || !res.body) {
    var data = await res.json().catch(function () { return null; });
    return { ok: false, status: res.status, error: (data && data.error) || "CLEAR's AI service didn't respond (" + res.status + ")." };
  }
  var reader = res.body.getReader(), dec = new TextDecoder(), raw = "";
  for (;;) {
    var r = await reader.read();
    if (r.done) break;
    raw += dec.decode(r.value, { stream: true });
    var cut = raw.indexOf("\u0000ERROR:");
    if (cut !== -1) return { ok: false, error: raw.slice(cut + 7).trim() };
    onPartial(clearParse(raw));
  }
  var final = clearParse(raw);
  return final.explanation ? { ok: true, data: final } : { ok: false, error: "CLEAR couldn't produce an explanation. Please try again." };
}
async function explainStreaming(payload, onPartial) {
  var key = JSON.stringify([payload && payload.text, payload && payload.style, payload && payload.prefs]);
  if (explainCache.has(key)) return explainCache.get(key);
  var prefs = await clearLoad();
  var base = (prefs.apiBase || CLEAR_DEFAULT_API).replace(/\/+$/, "");
  var out;
  try { out = await streamAt(base, payload, onPartial); } catch (e) { out = { ok: false, error: "Couldn't reach CLEAR's AI service." }; }
  if (!out.ok && base !== CLEAR_DEFAULT_API && !(out.status >= 400 && out.status < 500 && out.status !== 404)) {
    try { out = await streamAt(CLEAR_DEFAULT_API, payload, onPartial); } catch (e) {}
  }
  if (!out.ok) out = await explain(payload); // older servers without streaming
  else { explainCache.set(key, out); if (explainCache.size > 50) explainCache.delete(explainCache.keys().next().value); }
  return out;
}
chrome.runtime.onConnect.addListener(function (port) {
  if (port.name !== "clear-explain") return;
  var alive = true;
  port.onDisconnect.addListener(function () { alive = false; });
  port.onMessage.addListener(function (msg) {
    explainStreaming(msg.payload, function (p) { if (alive) port.postMessage({ partial: p }); })
      .then(function (res) { if (alive) port.postMessage({ done: res }); });
  });
});

chrome.runtime.onMessage.addListener(function (msg, _sender, sendResponse) {
  if (msg && msg.type === "explain") {
    explain(msg.payload).then(sendResponse);
    return true;
  }
  if (msg && msg.type === "ping-api") {
    ping().then(sendResponse);
    return true;
  }
  if (msg && msg.type === "open-options") {
    chrome.runtime.openOptionsPage();
  }
  return false;
});
