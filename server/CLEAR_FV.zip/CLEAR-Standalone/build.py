#!/usr/bin/env python3
"""Keep the shared files identical in extension/ and website/, then zip the extension for download.
   Edit files in shared/ (fog.js, prefs.js, explain-ui.js), then run:  python3 build.py"""
import shutil, zipfile, pathlib
root = pathlib.Path(__file__).parent
for f in ('fog.js', 'prefs.js', 'explain-ui.js'):
    for dest in ('extension', 'website'):
        shutil.copy(root / 'shared' / f, root / dest / f)
out = root / 'website' / 'downloads' / 'clear-extension.zip'
out.parent.mkdir(exist_ok=True)
with zipfile.ZipFile(out, 'w', zipfile.ZIP_DEFLATED) as z:
    for p in sorted((root / 'extension').rglob('*')):
        if p.is_file() and not p.name.startswith('.'):
            z.write(p, 'extension/' + str(p.relative_to(root / 'extension')))
print('synced shared files; wrote', out.relative_to(root), f'({out.stat().st_size//1024} KB)')
