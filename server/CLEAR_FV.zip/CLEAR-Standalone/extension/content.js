/* CLEAR — content script.
 * Finds distracting visual content and covers it with an opaque, fog-textured layer.
 * Covers live in one closed shadow root so page CSS can never restyle or reveal them. */
(() => {
  'use strict';
  if (window.__CLEAR_LOADED__) return;
  window.__CLEAR_LOADED__ = true;

  const CFG = self.CLEAR_CONFIG || {};
  const P = self.ClearPrefs, Fog = self.ClearFog;
  let prefs = P.sanitize();

  /* ───────────────────────── website <-> extension bridge ───────────────────────── */
  if ((CFG.SITE_ORIGINS || []).includes(location.origin)) {
    document.documentElement.dataset.clearExtension = 'installed';
    const send = (type, data) => window.postMessage({ clearExt: true, type, prefs: data }, location.origin);
    const pull = () => chrome.storage.sync.get(P.DEFAULTS, v => send('prefs', P.sanitize(v)));
    window.addEventListener('message', e => {
      if (e.source !== window || e.origin !== location.origin || !e.data || !e.data.clearSite) return;
      if (e.data.type === 'get') pull();
      if (e.data.type === 'set') {
        const next = P.sanitize(e.data.prefs); delete next.disabledSites;   // sites are managed in the extension only
        chrome.storage.sync.set(next, pull);
      }
    });
    chrome.storage.onChanged.addListener((_, area) => { if (area === 'sync') pull(); });
    pull();
    return;   // never filter the CLEAR website itself
  }

  /* ───────────────────────── settings ───────────────────────── */
  const MAX_COVERS = 160;
  const BLEED = 4;                        // px of extra cover around every element
  let forced = false;                     // "Cover this page now" while mode is "off"
  const siteOff = () => prefs.disabledSites.includes(location.hostname);
  const isActive = () => prefs.enabled && !siteOff() && (prefs.mode !== 'off' || forced);
  const effMode = () => (prefs.mode === 'off' ? 'manual' : prefs.mode);

  /* ───────────────────────── detection ───────────────────────── */
  const AD_HOSTS = /(doubleclick|googlesyndication|googleadservices|adservice\.google|amazon-adsystem|adnxs|taboola|outbrain|criteo|rubiconproject|pubmatic|openx\.net|adsrvr|teads\.tv|revcontent|mgid|smartadserver|moatads|adform|casalemedia|media\.net|yieldmo|sharethrough|2mdn\.net)/i;
  const VIDEO_HOSTS = /(youtube(-nocookie)?\.com\/embed|youtu\.be|player\.vimeo|dailymotion\.com\/embed|twitch\.tv|tiktok\.com\/embed|facebook\.com\/plugins\/video|streamable\.com|wistia|jwplatform|brightcove|loom\.com\/embed)/i;
  const AD_ATTR = 'ins.adsbygoogle,[data-ad-slot],[data-ad-client],[data-ad-unit],[data-adunit],[data-google-query-id],[id^="div-gpt-ad"],[id^="google_ads"],[id^="aswift"],[aria-label="Advertisement" i],[data-ad-rendering-role],[data-adsbygoogle-status]';
  const SPONSORED_ATTR = '[data-testid="placementTracking"],[aria-label="Sponsored" i],[data-promoted="true"]';
  const AD_TOKEN = /(?:^|[\s_\-.:])(ad|ads|adv|advert|adverts|advertisement|advertising|adslot|adunit|adbox|adbanner|adwrap|adwrapper|adcontainer|dfp|adsbygoogle|taboola|outbrain|revcontent|mgid)(?:$|[\s_\-.:])/;
  const SPONSORED_TOKEN = /(?:^|[\s_\-.:])(sponsored|promoted|advertorial|paid-post|paid-content|partner-content)(?:$|[\s_\-.:])/;
  const POPUP_TOKEN = /(?:^|[\s_\-.:])(modal|popup|pop-up|lightbox|interstitial|newsletter|paywall|exit-intent|dialog)(?:$|[\s_\-.:])/;
  const POPUP_SKIP = /(cookie|consent|gdpr|cmp|onetrust|trustarc|didomi|usercentrics|privacy|nav|menu|drawer|sidebar|search|cart|tooltip|dropdown|toast|snackbar)/;
  const LABEL_RE = /^(sponsored|promoted|advertisement|ad|paid post|paid content|partner content|sponsored content|anzeige|reklama|реклама|publicité|publicidad)$/i;
  const MIN = { ads: [40, 24], sponsored: [140, 80], gifs: [40, 40], videos: [100, 56], popups: [140, 80], images: [90, 70] };

  const normTokens = el => {
    const cls = el.getAttribute('class') || '';
    const s = (el.id + ' ' + cls);
    return s.length > 1 ? s.replace(/([a-z0-9])([A-Z])/g, '$1 $2').toLowerCase() : '';
  };
  const vw = () => window.innerWidth || document.documentElement.clientWidth;
  const vh = () => window.innerHeight || document.documentElement.clientHeight;
  const area = r => r.width * r.height;

  let lastGesture = -1e9;                 // no gesture yet
  const markGesture = () => { lastGesture = performance.now(); };
  addEventListener('pointerdown', markGesture, true);
  addEventListener('keydown', markGesture, true);
  const userOpened = new WeakSet();       // pop-ups the person opened themselves
  const popupCandidates = new Set();      // modal-looking elements that are hidden for now

  function isGif(img) {
    const u = (img.currentSrc || img.src || img.getAttribute('data-src') || '');
    if (/\.gif([?#]|$)/i.test(u) || /^data:image\/gif/i.test(u) || /(giphy|tenor)\.com/i.test(u)) return true;
    const pic = img.parentElement && img.parentElement.tagName === 'PICTURE' ? img.parentElement : null;
    return !!(pic && pic.querySelector('source[type="image/gif"]'));
  }
  const hasMainContent = el => !!el.querySelector('main,article,h1,[role="main"]');

  function looksLikePopup(el) {
    const cs = getComputedStyle(el);
    if (cs.display === 'none' || cs.visibility === 'hidden' || parseFloat(cs.opacity) === 0) return 'hidden';
    if (cs.position !== 'fixed' && cs.position !== 'absolute') return false;
    const r = el.getBoundingClientRect();
    if (r.width < 0.2 * vw() * 0.9 || r.height < 0.12 * vh()) return false;
    const z = parseInt(cs.zIndex, 10);
    const modal = el.getAttribute('aria-modal') === 'true' || el.matches('[role="dialog"],[role="alertdialog"],dialog[open]');
    if (!modal && !(z >= 10)) return false;
    return true;
  }
  // A full-screen backdrop is not what we cover. Find the dialog box inside it.
  function dialogInside(el) {
    let best = null, bestA = 0;
    const kids = el.querySelectorAll('[role="dialog"],[aria-modal="true"],[class*="modal" i],[class*="popup" i],[class*="dialog" i],:scope > div > div, :scope > div');
    for (const k of kids) {
      const r = k.getBoundingClientRect(), a = area(r);
      if (a > 0.1 * vw() * vh() && a < 0.85 * vw() * vh() && r.width > 160 && a > bestA) { best = k; bestA = a; }
    }
    return best;
  }
  function popupTarget(el) {
    const v = looksLikePopup(el);
    if (v === 'hidden') { popupCandidates.add(el); return null; }
    if (!v) return null;
    popupCandidates.delete(el);
    if (userOpened.has(el)) return null;
    if (performance.now() - lastGesture < 1500) { userOpened.add(el); return null; }   // you just clicked something to open it
    const r = el.getBoundingClientRect();
    if (r.width >= 0.92 * vw() && r.height >= 0.92 * vh()) return dialogInside(el);
    return el;
  }

  /* Which kind of distraction (if any) is this element? */
  function classify(el) {
    const tag = el.tagName;
    if (tag === 'IMG') {
      if (prefs.gifs && isGif(el)) return 'gifs';
      return prefs.images ? 'images' : null;
    }
    if (tag === 'VIDEO') return prefs.videos ? 'videos' : null;
    if (tag === 'IFRAME' || tag === 'EMBED' || tag === 'OBJECT') {
      const u = el.src || el.getAttribute('data') || '';
      const t = (el.title || '') + ' ' + (el.getAttribute('aria-label') || '') + ' ' + el.id;
      if (prefs.ads && (AD_HOSTS.test(u) || /advertis|3rd party ad|google_ads/i.test(t))) return 'ads';
      if (prefs.videos && VIDEO_HOSTS.test(u)) return 'videos';
      return null;
    }
    if (tag === 'BODY' || tag === 'HTML' || tag === 'MAIN' || tag === 'ARTICLE' || tag === 'SCRIPT' || tag === 'STYLE' || tag === 'NAV') return null;

    if (prefs.ads && el.matches(AD_ATTR)) return 'ads';
    if (prefs.sponsored && el.matches(SPONSORED_ATTR)) return 'sponsored';
    if (el.hasAttribute('role') || el.hasAttribute('aria-modal') || tag === 'DIALOG') {
      if (prefs.popups && el.matches('[role="dialog"],[role="alertdialog"],[aria-modal="true"],dialog[open]') && !POPUP_SKIP.test(normTokens(el))) return 'popups';
    }
    const t = normTokens(el);
    if (t) {
      if (prefs.ads && AD_TOKEN.test(t)) return 'ads?';            // "?" = needs a sanity check
      if (prefs.sponsored && SPONSORED_TOKEN.test(t)) return 'sponsored?';
      if (prefs.popups && POPUP_TOKEN.test(t) && !POPUP_SKIP.test(t)) return 'popups';
    }
    return null;
  }

  function test(el) {
    if (!(el instanceof Element) || covers.size >= MAX_COVERS) return;
    let kind = classify(el);
    if (!kind) return;
    let target = el;
    if (kind.endsWith('?')) {                                      // token-matched ads need sanity checks
      kind = kind.slice(0, -1);
      const r = el.getBoundingClientRect();
      if (area(r) > 0.5 * vw() * vh() || hasMainContent(el)) return;
    }
    if (kind === 'popups') { target = popupTarget(el); if (!target) return; }
    addCover(target, kind);
  }

  /* "Sponsored" / "Promoted" labels: find the card the label belongs to. */
  function scanLabels(root) {
    if (!prefs.sponsored) return;
    const w = document.createTreeWalker(root, NodeFilter.SHOW_TEXT, {
      acceptNode: n => (n.nodeValue.length < 28 && LABEL_RE.test(n.nodeValue.trim())) ? NodeFilter.FILTER_ACCEPT : NodeFilter.FILTER_REJECT
    });
    let n, count = 0, seen = 0;
    while ((n = w.nextNode()) && count++ < 60 && seen++ < 4000) {
      let el = n.parentElement, first = null;
      for (let i = 0; i < 9 && el && el !== document.body; i++, el = el.parentElement) {
        const r = el.getBoundingClientRect();
        if (r.width >= 140 && r.height >= 90) {
          if (area(r) > 0.55 * vw() * vh()) { first = null; break; }
          if (!first) first = el;
          if (el.matches('article,li,[role="article"]')) { first = el; break; }
        }
      }
      if (first && !hasMainContent(first)) addCover(first, 'sponsored');
    }
  }

  /* ───────────────────────── cover layer ───────────────────────── */
  const covers = new Map();   // element -> record
  let host, shadow, layerAbs, layerFix, seedCounter = 1;

  function ensureLayer() {
    if (host && host.isConnected) return;
    host = document.createElement('div');
    host.setAttribute('data-clear-root', '1');
    host.style.cssText = 'all:initial;position:absolute;top:0;left:0;width:0;height:0;overflow:visible;z-index:2147483646;pointer-events:none;';
    shadow = host.attachShadow({ mode: 'closed' });
    shadow.innerHTML = `<style>
      *{box-sizing:border-box;font-family:'DM Sans',system-ui,-apple-system,'Segoe UI',Arial,sans-serif}
      .layer{position:absolute;top:0;left:0;width:0;height:0;overflow:visible}.layer.fix{position:fixed}
      .cover{position:absolute;left:0;top:0;pointer-events:auto;overflow:hidden;border-radius:4px;background:transparent;will-change:transform;contain:layout paint}
      .cover canvas{display:block;width:100%;height:100%}
      .cover:focus-visible{outline:3px solid #34493c;outline-offset:-3px}
      .bar{position:absolute;top:8px;right:8px;display:flex;gap:6px;opacity:0;transition:opacity .15s;pointer-events:auto}
      .cover:hover .bar,.cover:focus-within .bar,.bar.show{opacity:1}
      @media (hover:none){.bar{opacity:1}}
      .bar button{border:1px solid #fff;background:#34493c;color:#fff;border-radius:999px;padding:6px 11px;font-size:12px;font-weight:600;cursor:pointer;box-shadow:0 3px 10px rgba(35,55,43,.35)}
      .bar button:hover{background:#2a3d32}.bar button:focus-visible{outline:3px solid #f5f3e9;outline-offset:2px}
      .bar button.ghost{background:#f6f7f1;color:#233229;border-color:#b6c5b5}
    </style><div class="layer abs"></div><div class="layer fix"></div>`;
    layerAbs = shadow.querySelector('.abs'); layerFix = shadow.querySelector('.fix');
    document.documentElement.appendChild(host);
  }

  const scrollableAncestor = el => {
    for (let p = el.parentElement; p && p !== document.documentElement; p = p.parentElement) {
      const s = getComputedStyle(p);
      if (/(auto|scroll)/.test(s.overflowY) && p.scrollHeight > p.clientHeight + 1) return p;
    }
    return null;
  };
  function ancestorsInfo(el) {
    let fixed = false; const clippers = [];
    for (let p = el; p && p !== document.documentElement; p = p.parentElement) {
      const s = getComputedStyle(p);
      if (s.position === 'fixed' || s.position === 'sticky') fixed = true;
      if (p !== el && p !== document.body && (s.overflowX !== 'visible' || s.overflowY !== 'visible') && s.display !== 'contents') clippers.push(p);
    }
    return { fixed, clippers: clippers.slice(0, 6) };
  }

  function addCover(el, kind) {
    if (covers.has(el) || el.closest('[data-clear-root],[data-clear-ui]')) return;
    for (const k of covers.keys()) if (k !== el && k.contains(el)) return;          // already inside a covered block
    const r = el.getBoundingClientRect(), [mw, mh] = MIN[kind] || [40, 24];
    if (r.width < mw || r.height < mh) return;
    for (const k of Array.from(covers.keys())) if (el.contains(k)) removeCover(k);   // swallow covered children
    ensureLayer();

    const wrap = document.createElement('div');
    wrap.className = 'cover';
    const canvas = Fog.createFogCanvas(Math.round(r.width), Math.round(r.height), prefs.coverColor, seedCounter++ * 7919);
    wrap.appendChild(canvas);

    const mode = effMode();
    const rec = { el, kind, wrap, canvas, revealed: false, mode, info: ancestorsInfo(el), last: '', detach: null, animated: isAnimated(el) };
    const bar = document.createElement('div'); bar.className = 'bar';
    const addBtn = (label, cls, fn) => { const b = document.createElement('button'); b.type = 'button'; b.textContent = label; if (cls) b.className = cls; b.addEventListener('click', e => { e.stopPropagation(); fn(); }); bar.appendChild(b); return b; };

    if (mode === 'manual') {
      wrap.setAttribute('role', 'button'); wrap.tabIndex = 0;
      wrap.setAttribute('aria-label', `Covered ${kindName(kind)}. Drag to wipe the fog, or press Enter to reveal it.`);
      wrap.style.cursor = Fog.brushCursor(prefs.brushSize);
      rec.detach = Fog.attachWipe(canvas, { getBrush: () => prefs.brushSize });
      const restore = addBtn('Restore fog', 'ghost', () => { Fog.refog(canvas); rec.revealed = false; wrap.style.display = ''; });
      addBtn('Show all', '', () => reveal(rec));
      wrap.addEventListener('keydown', e => { if ((e.key === 'Enter' || e.key === ' ') && e.target === wrap) { e.preventDefault(); reveal(rec); } });
      void restore;
    } else {
      wrap.setAttribute('role', 'img'); wrap.setAttribute('aria-label', `${cap(kindName(kind))} hidden by CLEAR`);
      if (kind === 'popups') { bar.classList.add('show'); addBtn('Show pop-up', '', () => reveal(rec)); }   // a pop-up has to be reachable to be closed
    }
    if (bar.children.length) wrap.appendChild(bar);
    ['pointerdown', 'mousedown', 'click', 'dblclick', 'contextmenu', 'touchstart'].forEach(t => wrap.addEventListener(t, e => { if (!e.composedPath().includes(bar)) e.stopPropagation(); }));
    wrap.addEventListener('wheel', e => {
      const sc = scrollableAncestor(el); if (!sc) return;
      const k = e.deltaMode === 1 ? 16 : 1; sc.scrollBy(e.deltaX * k, e.deltaY * k); e.preventDefault();
    }, { passive: false });

    (rec.info.fixed ? layerFix : layerAbs).appendChild(wrap);
    covers.set(el, rec);
    if (el.tagName === 'VIDEO') quiet(el);
    place(rec);
    if (rec.animated) kickAnim();
  }
  const cap = s => s.charAt(0).toUpperCase() + s.slice(1);
  const kindName = k => ({ ads: 'advertisement', sponsored: 'sponsored content', gifs: 'animation', videos: 'video', popups: 'pop-up', images: 'image' }[k] || 'content');

  function quiet(v) {                      // covered videos should not keep playing behind the fog
    try { v.pause(); v.muted = true; v.autoplay = false; } catch (_) {}
    if (!v.__clearQuiet) {
      v.__clearQuiet = true;
      v.addEventListener('play', () => { const r = covers.get(v); if (r && !r.revealed) { try { v.pause(); } catch (_) {} } });
    }
  }
  function reveal(rec) { rec.revealed = true; rec.wrap.style.display = 'none'; }
  function removeCover(el) {
    const rec = covers.get(el); if (!rec) return;
    if (rec.detach) rec.detach();
    rec.wrap.remove(); covers.delete(el);
  }
  function removeAll() { Array.from(covers.keys()).forEach(removeCover); }

  /* ───────────────────────── positioning ───────────────────────── */
  function place(rec) {
    const el = rec.el;
    if (!el.isConnected) { removeCover(el); return; }
    if (rec.revealed) return;
    const r = el.getBoundingClientRect();
    const hide = () => { if (rec.last !== 'h') { rec.wrap.style.display = 'none'; rec.last = 'h'; } };
    if (r.width < 2 || r.height < 2 || (el.checkVisibility && !el.checkVisibility({ checkOpacity: true, checkVisibilityCSS: true }))) return hide();
    const W = vw(), H = vh();
    if (r.bottom < -300 || r.top > H + 300 || r.right < -300 || r.left > W + 300) return hide();
    // A few px of bleed: animated/transformed ads can grow past their reported box between frames.
    const B = rec.animated ? BLEED + 8 : BLEED;
    let l = r.left - B, t = r.top - B, rt = r.right + B, b = r.bottom + B;
    const el0 = l, et0 = t, er0 = rt, eb0 = b;
    for (const c of rec.info.clippers) {
      const q = c.getBoundingClientRect();
      l = Math.max(l, q.left); t = Math.max(t, q.top); rt = Math.min(rt, q.right); b = Math.min(b, q.bottom);
    }
    if (rt - l < 1 || b - t < 1) return hide();
    const ox = rec.info.fixed ? 0 : (window.scrollX || 0), oy = rec.info.fixed ? 0 : (window.scrollY || 0);
    const clip = `inset(${(t - et0).toFixed(1)}px ${(er0 - rt).toFixed(1)}px ${(eb0 - b).toFixed(1)}px ${(l - el0).toFixed(1)}px)`;
    const key = `${r.left.toFixed(1)}|${r.top.toFixed(1)}|${r.width.toFixed(1)}|${r.height.toFixed(1)}|${ox}|${oy}|${clip}`;
    if (rec.last === key) return;
    rec.last = key;
    const s = rec.wrap.style;
    s.display = '';
    s.width = (r.width + 2 * B) + 'px'; s.height = (r.height + 2 * B) + 'px';
    s.transform = `translate3d(${r.left - B + ox}px,${r.top - B + oy}px,0)`;
    s.clipPath = clip;
  }
  /* Elements with running CSS/Web animations (pulsing ad banners, etc.) change size every frame,
   * so they are tracked every frame instead of only on scroll / heartbeat. */
  const isAnimated = el => { try { return !!(el.getAnimations && el.getAnimations({ subtree: true }).some(a => a.playState === 'running')); } catch (_) { return false; } };
  let animRaf = 0;
  function kickAnim() {
    if (animRaf) return;
    const tick = () => {
      animRaf = 0; let any = false;
      covers.forEach(rec => { if (rec.animated) { any = true; place(rec); } });
      if (any && !document.hidden) animRaf = requestAnimationFrame(tick);
    };
    animRaf = requestAnimationFrame(tick);
  }
  let raf = 0;
  function positionAll() { raf = 0; covers.forEach(place); }
  const schedulePosition = () => { if (!raf) raf = requestAnimationFrame(positionAll); };
  addEventListener('scroll', schedulePosition, { passive: true, capture: true });
  addEventListener('resize', schedulePosition);

  /* ───────────────────────── scanning (incremental, time-boxed) ───────────────────────── */
  const queue = new Set();
  let work = [], wi = 0, labelRoots = [], pump = 0;
  const kick = delay => { if (!pump) pump = setTimeout(drain, delay); };
  function enqueue(node) {
    if (!isActive() || !(node instanceof Element) || node === host) return;
    queue.add(node);
    kick(120);
  }
  /* Resumable scan: works through the element list in ~10 ms slices so even a 30,000-node page never blocks. */
  function drain() {
    pump = 0;
    if (!isActive()) { queue.clear(); work = []; wi = 0; labelRoots = []; return; }
    const t0 = performance.now();
    if (wi >= work.length && queue.size) {
      work = []; wi = 0;
      for (const root of queue) {
        if (!root.isConnected) continue;
        work.push(root);
        const all = root.querySelectorAll('*');
        for (let k = 0; k < all.length; k++) work.push(all[k]);
        labelRoots.push(root);
      }
      queue.clear();
    }
    while (wi < work.length) {
      if (covers.size >= MAX_COVERS) { wi = work.length; break; }
      test(work[wi++]);
      if ((wi & 63) === 0 && performance.now() - t0 > 10) { kick(25); schedulePosition(); return; }
    }
    work = []; wi = 0;
    if (labelRoots.length) {                         // "Sponsored" labels: one root per slice
      const r = labelRoots.shift();
      if (r.isConnected) scanLabels(r);
      if (labelRoots.length || queue.size) kick(25);
    } else if (queue.size) kick(25);
    // top-level body children are where most pop-ups are injected
    if (document.body && prefs.popups) for (const c of document.body.children) { if (c !== host && !covers.has(c) && /^(DIV|SECTION|ASIDE|FORM|DIALOG)$/.test(c.tagName)) { const tgt = popupTarget(c); if (tgt) addCover(tgt, 'popups'); } }
    schedulePosition();
  }

  const mo = new MutationObserver(muts => {
    for (const m of muts) {
      if (m.type === 'childList') m.addedNodes.forEach(n => n.nodeType === 1 && enqueue(n));
      else if (m.target.nodeType === 1 && !covers.has(m.target)) enqueue(m.target);
    }
    schedulePosition();
  });
  addEventListener('load', e => { const t = e.target; if (t && (t.tagName === 'IMG' || t.tagName === 'VIDEO' || t.tagName === 'IFRAME')) enqueue(t); }, true);
  document.addEventListener('loadeddata', e => e.target && e.target.tagName === 'VIDEO' && enqueue(e.target), true);

  /* Slow heartbeat: layout shifts, modals that become visible later, elements that vanished. */
  setInterval(() => {
    if (document.hidden || !isActive()) return;
    covers.forEach(rec => { rec.animated = isAnimated(rec.el); if (!rec.revealed || !rec.el.isConnected) { rec.info = ancestorsInfo(rec.el); const wantFix = rec.info.fixed; const inFix = rec.wrap.parentNode === layerFix; if (wantFix !== inFix) { (wantFix ? layerFix : layerAbs).appendChild(rec.wrap); rec.last = ''; } } });
    popupCandidates.forEach(el => { if (!el.isConnected) popupCandidates.delete(el); else { const tgt = popupTarget(el); if (tgt) addCover(tgt, 'popups'); } });
    if ([...covers.values()].some(r => r.animated)) kickAnim();
    schedulePosition();
  }, 900);

  /* ───────────────────────── apply settings ───────────────────────── */
  function apply() {
    removeAll(); queue.clear();
    mo.disconnect();
    if (!isActive()) return;
    if (!document.body) return;
    ensureLayer();
    mo.observe(document.documentElement, { childList: true, subtree: true, attributes: true, attributeFilter: ['src', 'srcset', 'data-src', 'class', 'hidden', 'open', 'aria-hidden', 'aria-modal', 'role'] });
    enqueue(document.body);
  }

  /* ───────────────────────── "Explain with CLEAR" ───────────────────────── */
  let ui = null;
  function syncExplain() {
    const want = prefs.enabled && prefs.explain && !siteOff();
    if (want && !ui) {
      ui = self.ClearExplain.mount({
        scope: document,
        request: ({ text, level }) => new Promise((resolve, reject) => {
          const fail = code => reject(Object.assign(new Error(code), { code }));
          try {
            chrome.runtime.sendMessage({ type: 'explain', text, level, context: document.title }, r => {
              if (chrome.runtime.lastError || !r) return fail('offline');
              r.ok ? resolve(r.data) : fail(r.code || 'failed');
            });
          } catch (_) { fail('offline'); }
        })
      });
    } else if (!want && ui) { ui.destroy(); ui = null; }
  }

  /* ───────────────────────── messages from popup / shortcuts ───────────────────────── */
  chrome.runtime.onMessage.addListener((msg, _s, reply) => {
    switch (msg && msg.type) {
      case 'status': {
        let wiped = 0; covers.forEach(r => { if (r.canvas._clearWiped || r.revealed) wiped++; });
        reply({ active: isActive(), covers: covers.size, wiped, host: location.hostname, siteOff: siteOff(), mode: prefs.mode, forced }); break;
      }
      case 'refog': covers.forEach(r => { Fog.refog(r.canvas, prefs.coverColor); r.revealed = false; r.wrap.style.display = ''; r.last = ''; }); schedulePosition(); reply({ ok: true }); break;
      case 'activate': forced = true; apply(); reply({ ok: true }); break;
      case 'deactivate': forced = false; apply(); reply({ ok: true }); break;
      case 'explain-selection': if (ui) ui.explain(msg.text); reply({ ok: !!ui }); break;
      default: break;
    }
    return false;
  });

  chrome.storage.sync.get(P.DEFAULTS, v => { prefs = P.sanitize(v); apply(); syncExplain(); });
  chrome.storage.onChanged.addListener((ch, area) => {
    if (area !== 'sync') return;
    const next = Object.assign({}, prefs);
    for (const k in ch) next[k] = ch[k].newValue;
    prefs = P.sanitize(next);
    if (prefs.mode !== 'off') forced = false;
    apply(); syncExplain();
  });
})();
