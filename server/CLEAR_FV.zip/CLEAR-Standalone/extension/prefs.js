/* CLEAR — shared preference schema (website + extension). Keep copies identical. */
(function (g) {
  'use strict';
  const DEFAULTS = {
    enabled: true,
    explain: true,           // show the “Explain with CLEAR” text helper
    mode: 'always',          // 'always' | 'manual' | 'off'
    ads: true, sponsored: true, gifs: true, videos: true, popups: true, images: false,
    coverColor: '#b9c9b8',
    brushSize: 46,
    disabledSites: []         // extension only
  };
  const CATEGORIES = [
    { key: 'ads',       label: 'Advertisements',         hint: 'Banners, ad frames and ad slots' },
    { key: 'sponsored', label: 'Sponsored content',      hint: 'Posts and cards marked “Sponsored” or “Promoted”' },
    { key: 'gifs',      label: 'GIFs & animations',      hint: 'Animated images' },
    { key: 'videos',    label: 'Videos & autoplay',      hint: 'Video players, embeds and autoplay clips' },
    { key: 'popups',    label: 'Pop-ups & modals',       hint: 'Windows that interrupt what you are reading' },
    { key: 'images',    label: 'Other images',           hint: 'Every larger image, for a very quiet page' }
  ];
  const PRESETS = [
    { name: 'Sage',  color: '#b9c9b8' },
    { name: 'Mist',  color: '#c5d3d0' },
    { name: 'Cream', color: '#e6e1cd' },
    { name: 'Dusk',  color: '#b9c3d3' },
    { name: 'Rose',  color: '#d9c4c0' },
    { name: 'Slate', color: '#9fada6' }
  ];
  const MODES = [
    { value: 'always', label: 'Always covered',  hint: 'Content stays hidden automatically.' },
    { value: 'manual', label: 'Manual reveal',   hint: 'Content starts covered. Wipe the fog to reveal what you choose.' },
    { value: 'off',    label: 'Filtering off',   hint: 'Content stays visible until you switch filtering on.' }
  ];
  const BRUSH = { min: 16, max: 110 };

  function sanitize(p) {
    const o = Object.assign({}, DEFAULTS, p || {});
    const out = {};
    out.enabled = !!o.enabled;
    out.explain = !!o.explain;
    out.mode = ['always', 'manual', 'off'].includes(o.mode) ? o.mode : DEFAULTS.mode;
    CATEGORIES.forEach(c => { out[c.key] = !!o[c.key]; });
    out.coverColor = /^#[0-9a-f]{6}$/i.test(o.coverColor) ? o.coverColor.toLowerCase() : DEFAULTS.coverColor;
    const b = Number(o.brushSize);
    out.brushSize = Math.min(BRUSH.max, Math.max(BRUSH.min, Number.isFinite(b) ? Math.round(b) : DEFAULTS.brushSize));
    out.disabledSites = Array.isArray(o.disabledSites) ? o.disabledSites.filter(s => typeof s === 'string').slice(0, 500) : [];
    return out;
  }
  g.ClearPrefs = { DEFAULTS, CATEGORIES, PRESETS, MODES, BRUSH, sanitize };
})(typeof self !== 'undefined' ? self : this);
