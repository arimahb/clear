/* CLEAR — shared fog + wipe engine.
 * Used by BOTH the Chrome extension (content script) and the website tutorial,
 * so the brush behaves identically in both places.
 * Keep extension/fog.js and website/fog.js identical (see build.py). */
(function (g) {
  'use strict';

  const DEFAULT_COLOR = '#b9c9b8';
  const CREAM = '#f5f3e9';

  function hexToRgb(hex) {
    let h = String(hex || DEFAULT_COLOR).replace('#', '');
    if (h.length === 3) h = h.split('').map(c => c + c).join('');
    const n = parseInt(h, 16);
    if (!/^[0-9a-f]{6}$/i.test(h)) return hexToRgb(DEFAULT_COLOR);
    return [(n >> 16) & 255, (n >> 8) & 255, n & 255];
  }
  function mix(a, b, t) {
    const A = hexToRgb(a), B = hexToRgb(b);
    return A.map((v, i) => Math.round(v + (B[i] - v) * t));
  }
  const rgba = (c, a) => `rgba(${c[0]},${c[1]},${c[2]},${a})`;

  function rng(seed) { // mulberry32
    let t = seed >>> 0;
    return () => { t += 0x6D2B79F5; let r = Math.imul(t ^ (t >>> 15), 1 | t); r ^= r + Math.imul(r ^ (r >>> 7), 61 | r); return ((r ^ (r >>> 14)) >>> 0) / 4294967296; };
  }

  /* Paint soft, misty fog. The base is filled at alpha 1 and everything after is
   * drawn source-over, so every pixel stays 100% opaque: nothing underneath can
   * show through. The "translucent" look is painted, not real transparency. */
  function paintFog(ctx, w, h, color, seed) {
    const rand = rng(seed || 1);
    const base = hexToRgb(color);
    const light = mix(color, CREAM, 0.6);
    const lighter = mix(color, '#ffffff', 0.75);
    const dark = mix(color, '#4d6556', 0.28);
    ctx.save();
    ctx.globalCompositeOperation = 'source-over';
    ctx.globalAlpha = 1;
    ctx.fillStyle = rgba(base, 1);
    ctx.fillRect(0, 0, w, h);

    const sheen = ctx.createLinearGradient(0, 0, w, h);
    sheen.addColorStop(0, rgba(light, 0.7));
    sheen.addColorStop(0.45, rgba(base, 0));
    sheen.addColorStop(1, rgba(dark, 0.4));
    ctx.fillStyle = sheen; ctx.fillRect(0, 0, w, h);

    const m = Math.max(w, h);
    const clouds = Math.min(22, 7 + Math.round((w * h) / 60000));
    for (let i = 0; i < clouds; i++) {
      const x = rand() * w, y = rand() * h, r = m * (0.14 + rand() * 0.34);
      const c = rand() > 0.38 ? light : dark;
      const gr = ctx.createRadialGradient(x, y, 0, x, y, r);
      gr.addColorStop(0, rgba(c, c === light ? 0.42 : 0.2));
      gr.addColorStop(1, rgba(c, 0));
      ctx.fillStyle = gr; ctx.fillRect(0, 0, w, h);
    }
    const drops = Math.min(140, Math.round((w * h) / 2600));
    for (let i = 0; i < drops; i++) {
      const x = rand() * w, y = rand() * h, r = 0.7 + rand() * 2.3;
      ctx.fillStyle = rgba(lighter, 0.16 + rand() * 0.2);
      ctx.beginPath(); ctx.arc(x, y, r, 0, 6.2832); ctx.fill();
      ctx.fillStyle = rgba(dark, 0.1);
      ctx.beginPath(); ctx.arc(x + r * 0.35, y + r * 0.45, r * 0.7, 0, 6.2832); ctx.fill();
    }
    ctx.restore();
  }

  /* Backing-store resolution: crisp enough for the brush edge, small enough to be cheap. */
  function pixelRatioFor(w, h) {
    const dpr = Math.min(g.devicePixelRatio || 1, 1.5);
    const cap = Math.sqrt(2.2e6 / Math.max(1, w * h));
    return Math.max(0.35, Math.min(dpr, cap));
  }

  function createFogCanvas(cssW, cssH, color, seed) {
    const c = document.createElement('canvas');
    const k = pixelRatioFor(cssW, cssH);
    c.width = Math.max(2, Math.round(cssW * k));
    c.height = Math.max(2, Math.round(cssH * k));
    c._clearColor = color;
    c._clearSeed = seed || 1;
    paintFog(c.getContext('2d'), c.width, c.height, color, c._clearSeed);
    c._clearWiped = false;
    return c;
  }

  function refog(canvas, color) {
    if (color) canvas._clearColor = color;
    const ctx = canvas.getContext('2d');
    ctx.globalCompositeOperation = 'source-over';
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    paintFog(ctx, canvas.width, canvas.height, canvas._clearColor, canvas._clearSeed);
    canvas._clearWiped = false;
  }

  /* Soft-edged brush sprite, cached per size. */
  const sprites = new Map();
  function brushSprite(radiusPx) {
    const r = Math.max(2, Math.round(radiusPx));
    if (sprites.has(r)) return sprites.get(r);
    const s = document.createElement('canvas');
    s.width = s.height = r * 2;
    const x = s.getContext('2d');
    const gr = x.createRadialGradient(r, r, 0, r, r, r);
    gr.addColorStop(0, 'rgba(0,0,0,1)');
    gr.addColorStop(0.62, 'rgba(0,0,0,0.96)');
    gr.addColorStop(1, 'rgba(0,0,0,0)');
    x.fillStyle = gr; x.fillRect(0, 0, r * 2, r * 2);
    if (sprites.size > 40) sprites.clear();
    sprites.set(r, s);
    return s;
  }

  /* A round cursor that shows the brush size. */
  const cursors = new Map();
  function brushCursor(sizePx) {
    const d = Math.max(10, Math.min(120, Math.round(sizePx)));
    if (cursors.has(d)) return cursors.get(d);
    const r = d / 2;
    const svg = `<svg xmlns='http://www.w3.org/2000/svg' width='${d + 4}' height='${d + 4}'><circle cx='${r + 2}' cy='${r + 2}' r='${r}' fill='rgba(255,255,255,0.12)' stroke='white' stroke-width='1.5'/><circle cx='${r + 2}' cy='${r + 2}' r='${r}' fill='none' stroke='rgba(40,60,48,0.7)' stroke-width='0.75'/></svg>`;
    const v = `url("data:image/svg+xml;utf8,${encodeURIComponent(svg)}") ${r + 2} ${r + 2}, crosshair`;
    cursors.set(d, v);
    return v;
  }

  /* Make a fog canvas wipeable with mouse, touch or pen.
   * opts.getBrush() -> brush diameter in CSS px
   * opts.onWipe()   -> called after each wipe stroke begins (optional)
   * Returns a detach() function. */
  function attachWipe(canvas, opts) {
    opts = opts || {};
    const ctx = canvas.getContext('2d');
    let drawing = false, last = null;

    function toCanvas(e) {
      const b = canvas.getBoundingClientRect();
      const sx = canvas.width / Math.max(1, b.width), sy = canvas.height / Math.max(1, b.height);
      return { x: (e.clientX - b.left) * sx, y: (e.clientY - b.top) * sy, s: (sx + sy) / 2 };
    }
    function stamp(p, radius) {
      const sp = brushSprite(radius);
      ctx.drawImage(sp, p.x - sp.width / 2, p.y - sp.height / 2);
    }
    function stroke(from, to) {
      const radius = ((opts.getBrush ? opts.getBrush() : 42) / 2) * to.s;
      ctx.globalCompositeOperation = 'destination-out';
      if (!from) { stamp(to, radius); return; }
      const dx = to.x - from.x, dy = to.y - from.y, dist = Math.hypot(dx, dy);
      const step = Math.max(1, radius * 0.22);
      const n = Math.ceil(dist / step);
      for (let i = 1; i <= n; i++) stamp({ x: from.x + (dx * i) / n, y: from.y + (dy * i) / n }, radius);
    }
    function down(e) {
      if (e.button !== undefined && e.button !== 0) return;
      drawing = true;
      try { canvas.setPointerCapture(e.pointerId); } catch (_) {}
      e.preventDefault(); e.stopPropagation();
      last = toCanvas(e);
      stroke(null, last);
      canvas._clearWiped = true;
      if (opts.onWipe) opts.onWipe();
    }
    function move(e) {
      if (!drawing) return;
      e.preventDefault(); e.stopPropagation();
      const evs = e.getCoalescedEvents ? e.getCoalescedEvents() : [];
      const list = evs.length ? evs : [e];
      for (const ev of list) { const p = toCanvas(ev); stroke(last, p); last = p; }
    }
    function up(e) {
      if (!drawing) return;
      drawing = false; last = null;
      try { canvas.releasePointerCapture(e.pointerId); } catch (_) {}
    }
    canvas.style.touchAction = 'none';
    canvas.addEventListener('pointerdown', down);
    canvas.addEventListener('pointermove', move);
    canvas.addEventListener('pointerup', up);
    canvas.addEventListener('pointercancel', up);
    return function detach() {
      canvas.removeEventListener('pointerdown', down);
      canvas.removeEventListener('pointermove', move);
      canvas.removeEventListener('pointerup', up);
      canvas.removeEventListener('pointercancel', up);
    };
  }

  g.ClearFog = { DEFAULT_COLOR, paintFog, createFogCanvas, refog, attachWipe, brushCursor, mix, hexToRgb };
})(typeof self !== 'undefined' ? self : this);
