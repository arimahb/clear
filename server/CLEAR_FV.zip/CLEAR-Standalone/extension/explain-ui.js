/* CLEAR — "Explain with CLEAR" selection button + explanation panel.
 * Shared by the extension (content script) and the website tutorial.
 *
 *   const ui = ClearExplain.mount({ scope, request });
 *   scope:   Element or document — only selections inside it are offered.
 *   request: async ({ text, level, truncated }) => ({ summary, words:[{term,meaning}], note? })
 *            throw an Error with .code in 'offline' | 'rate' | 'not-configured' | 'failed'
 *   ui.explain(text, rect?)  — open the panel for given text (context menu / shortcut / paste box)
 *   ui.destroy()
 */
(function (g) {
  'use strict';
  const MAX_CHARS = 1200;

  const CSS = `
:host{all:initial}
*{box-sizing:border-box;font-family:'DM Sans',system-ui,-apple-system,'Segoe UI',Arial,sans-serif}
.pill{position:fixed;z-index:2;display:none;align-items:center;gap:8px;padding:7px 13px 7px 8px;border:1px solid #fff;border-radius:999px;
  background:#34493c;color:#fff;font-size:13px;font-weight:600;line-height:1;cursor:pointer;box-shadow:0 6px 22px rgba(35,55,43,.38);}
.pill:hover{background:#2a3d32}.pill:focus-visible,button:focus-visible,.x:focus-visible{outline:3px solid #f5f3e9;outline-offset:2px;box-shadow:0 0 0 5px #34493c}
.mark{width:22px;height:22px;border-radius:50%;background:#dfe8dd;color:#34493c;display:grid;place-items:center;font:600 14px Georgia,serif}
.panel{position:fixed;z-index:3;display:none;width:min(360px,calc(100vw - 24px));max-height:min(70vh,520px);overflow:auto;border-radius:20px;
  background:#f6f7f1;color:#233229;border:1px solid #fff;box-shadow:0 22px 60px rgba(35,55,43,.35),0 0 0 1px #c7d3c6;}
.hd{display:flex;align-items:center;gap:10px;padding:14px 14px 10px 16px;border-bottom:1px solid #d9e1d7}
.hd .mark{background:#34493c;color:#fff}
.hd h2{flex:1;margin:0;font-size:13px;letter-spacing:.06em;text-transform:uppercase;color:#3d5446}
.x{border:0;background:#e3eae1;color:#233229;width:30px;height:30px;border-radius:50%;font-size:18px;line-height:1;cursor:pointer}
.x:hover{background:#d3ddd1}
.src{margin:12px 16px 0;padding:9px 11px;border-left:3px solid #92a993;background:#e9eee7;color:#46594d;font-size:12px;line-height:1.5;border-radius:0 8px 8px 0;max-height:4.6em;overflow:hidden}
.bd{padding:12px 16px 4px;font-size:15px;line-height:1.65}
.bd p{margin:0 0 10px}
.lbl{font-size:11px;letter-spacing:.08em;text-transform:uppercase;color:#52665a;font-weight:700;margin:12px 0 6px}
.words{margin:0;padding:0;list-style:none;font-size:13.5px;line-height:1.55}
.words li{padding:6px 0;border-top:1px solid #dde5db}.words b{color:#2b4034}
.note,.err{font-size:12.5px;line-height:1.5;color:#52665a}.err{color:#7a2f2f;background:#f4e4e1;padding:10px 12px;border-radius:10px}
.ft{display:flex;gap:8px;flex-wrap:wrap;padding:10px 16px 16px}
button.b{border:1px solid #b6c5b5;background:#fff;color:#2b4034;border-radius:999px;padding:8px 14px;font-size:12.5px;font-weight:600;cursor:pointer}
button.b:hover{background:#e9eee7}button.b.primary{background:#34493c;border-color:#34493c;color:#fff}button.b.primary:hover{background:#2a3d32}
.load{display:grid;gap:8px;padding:6px 0 10px}.load i{display:block;height:11px;border-radius:6px;background:linear-gradient(90deg,#dfe6dd,#f1f4ee,#dfe6dd);background-size:200% 100%;animation:sh 1.3s linear infinite}
.load i:nth-child(2){width:86%}.load i:nth-child(3){width:62%}
@keyframes sh{to{background-position:-200% 0}}
@media (prefers-reduced-motion:reduce){.load i{animation:none}}
`;

  function mount(opts) {
    const scope = opts.scope || document;
    const request = opts.request;
    const host = document.createElement('div');
    host.setAttribute('data-clear-ui', '1');
    host.style.cssText = 'all:initial;position:fixed;top:0;left:0;width:0;height:0;z-index:2147483647;';
    const root = host.attachShadow({ mode: 'closed' });
    root.innerHTML = `<style>${CSS}</style>
      <button class="pill" type="button" aria-label="Explain selected text with CLEAR"><span class="mark" aria-hidden="true">C</span>Explain with CLEAR</button>
      <section class="panel" role="dialog" aria-modal="false" aria-labelledby="ttl" tabindex="-1">
        <div class="hd"><span class="mark" aria-hidden="true">C</span><h2 id="ttl">In plain language</h2><button class="x" type="button" aria-label="Close explanation">×</button></div>
        <div class="src" part="src"></div>
        <div class="bd" aria-live="polite"></div>
        <div class="ft"></div>
      </section>`;
    (opts.host || document.documentElement).appendChild(host);

    const pill = root.querySelector('.pill'), panel = root.querySelector('.panel'),
          src = root.querySelector('.src'), bd = root.querySelector('.bd'), ft = root.querySelector('.ft'),
          closeBtn = root.querySelector('.x');

    let currentText = '', currentRect = null, level = 'plain', token = 0, lastFocus = null, rafId = 0;
    const cache = new Map();

    const inScope = node => {
      if (!node) return false;
      const el = node.nodeType === 1 ? node : node.parentElement;
      if (!el) return false;
      if (el.closest && el.closest('[data-clear-ui]')) return false;
      return scope === document ? true : scope.contains(el);
    };

    function selectionInfo() {
      // Text selected inside a text box or text area is not part of the page selection.
      const a = document.activeElement;
      if (a && (a.tagName === 'TEXTAREA' || (a.tagName === 'INPUT' && /^(text|search|url|email|tel)$/i.test(a.type))) && inScope(a)) {
        try {
          const t = a.value.slice(a.selectionStart, a.selectionEnd).replace(/\s+/g, ' ').trim();
          if (t.length >= 3) { const r = a.getBoundingClientRect(); return { text: t, rect: { left: r.left, right: r.right, top: r.top, bottom: r.bottom } }; }
        } catch (_) {}
      }
      const sel = g.getSelection && g.getSelection();
      if (!sel || sel.isCollapsed || !sel.rangeCount) return null;
      const text = sel.toString().replace(/\s+/g, ' ').trim();
      if (text.length < 3) return null;
      const range = sel.getRangeAt(0);
      if (!inScope(range.startContainer)) return null;   // start, not common ancestor: a triple-click can spill into the next block
      // Triple-click selections end in an empty rect at the start of the next block, so take the last rect that has size.
      const rects = Array.from(range.getClientRects()).filter(q => q.width > 0 && q.height > 0);
      const r = rects.length ? rects[rects.length - 1] : range.getBoundingClientRect();
      if (!r || (!r.width && !r.height)) return null;
      return { text, rect: { left: r.left, right: r.right, top: r.top, bottom: r.bottom } };
    }

    function place(el, rect, w, h) {
      const vw = g.innerWidth, vh = g.innerHeight, m = 10;
      let left = Math.min(Math.max(m, rect.right - 20), vw - w - m);
      let top = rect.bottom + 10;
      if (top + h > vh - m) top = Math.max(m, rect.top - h - 10);
      el.style.left = left + 'px'; el.style.top = top + 'px';
    }
    function showPill() {
      const s = selectionInfo();
      if (!s) { hidePill(); return; }
      currentText = s.text; currentRect = s.rect;
      pill.style.display = 'flex';
      place(pill, s.rect, pill.offsetWidth || 170, pill.offsetHeight || 36);
    }
    function hidePill() { pill.style.display = 'none'; }

    const queueShow = () => { clearTimeout(queueShow.t); queueShow.t = setTimeout(showPill, 140); };

    function renderFooter(canSimpler) {
      ft.innerHTML = '';
      const mk = (label, cls, fn) => { const b = document.createElement('button'); b.type = 'button'; b.className = 'b ' + (cls || ''); b.textContent = label; b.addEventListener('click', fn); ft.appendChild(b); return b; };
      if (canSimpler) mk(level === 'simpler' ? 'Back to plain' : 'Even simpler', 'primary', () => { level = level === 'simpler' ? 'plain' : 'simpler'; run(); });
      mk('Copy', '', async e => { try { await navigator.clipboard.writeText(bd.innerText.trim()); e.target.textContent = 'Copied'; setTimeout(() => (e.target.textContent = 'Copy'), 1400); } catch (_) {} });
      mk('Close', '', close);
    }

    function esc(s) { const d = document.createElement('div'); d.textContent = String(s == null ? '' : s); return d.innerHTML; }

    function renderResult(res) {
      let h = `<p>${esc(res.summary)}</p>`;
      if (res.words && res.words.length) {
        h += `<div class="lbl">Words to know</div><ul class="words">` +
          res.words.slice(0, 4).map(w => `<li><b>${esc(w.term)}</b> — ${esc(w.meaning)}</li>`).join('') + `</ul>`;
      }
      if (res.note) h += `<p class="note">${esc(res.note)}</p>`;
      bd.innerHTML = h;
      renderFooter(true);
    }
    function renderError(err) {
      const map = {
        'offline': 'CLEAR could not reach its explanation service. Check your connection and try again.',
        'rate': 'You have asked for a lot of explanations in a short time. Please wait a moment and try again.',
        'not-configured': 'The explanation service is not set up yet. See the CLEAR setup guide to connect it.',
        'failed': 'Something went wrong while explaining that text. Please try again.'
      };
      bd.innerHTML = `<div class="err" role="alert">${esc(map[err && err.code] || map.failed)}</div>`;
      renderFooter(false);
      const retry = document.createElement('button'); retry.className = 'b primary'; retry.type = 'button'; retry.textContent = 'Try again';
      retry.addEventListener('click', run); ft.insertBefore(retry, ft.firstChild);
    }

    async function run() {
      const my = ++token;
      const raw = currentText;
      const truncated = raw.length > MAX_CHARS;
      const text = truncated ? raw.slice(0, MAX_CHARS) : raw;
      src.textContent = raw.length > 190 ? raw.slice(0, 190).trim() + '…' : raw;
      bd.innerHTML = '<div class="load" aria-label="Working on it"><i></i><i></i><i></i></div>';
      renderFooter(false);
      const key = level + '|' + text;
      try {
        let res = cache.get(key);
        if (!res) { res = await request({ text, level, truncated }); if (!res.local) cache.set(key, res); if (cache.size > 30) cache.delete(cache.keys().next().value); }
        if (my !== token) return;
        if (truncated) res = Object.assign({}, res, { note: (res.note ? res.note + ' ' : '') + 'This selection was long, so CLEAR explained the first part.' });
        renderResult(res);
      } catch (e) { if (my === token) renderError(e); }
    }

    function open(text, rect) {
      currentText = String(text || '').replace(/\s+/g, ' ').trim();
      if (!currentText) return;
      level = 'plain';
      lastFocus = document.activeElement;
      hidePill();
      panel.style.display = 'block';
      const r = rect || currentRect || { left: g.innerWidth / 2 - 180, right: g.innerWidth / 2 + 180, top: 80, bottom: 80 };
      place(panel, r, Math.min(360, g.innerWidth - 20), 260);
      run();
      panel.focus({ preventScroll: true });
    }
    function close() {
      token++;
      panel.style.display = 'none';
      if (lastFocus && lastFocus.focus && document.contains(lastFocus)) { try { lastFocus.focus({ preventScroll: true }); } catch (_) {} }
    }

    // Keep the selection alive when pressing the pill.
    pill.addEventListener('pointerdown', e => e.preventDefault());
    pill.addEventListener('mousedown', e => e.preventDefault());
    pill.addEventListener('click', () => open(currentText, currentRect));
    closeBtn.addEventListener('click', close);
    panel.addEventListener('keydown', e => { if (e.key === 'Escape') { e.stopPropagation(); close(); } });

    const onSel = () => queueShow();
    const onKey = e => { if (e.key === 'Escape') { hidePill(); if (panel.style.display === 'block') close(); } else if (e.shiftKey || e.key.startsWith('Arrow')) queueShow(); };
    const onDown = e => { if (!e.composedPath().includes(host)) { hidePill(); if (panel.style.display === 'block' && !e.composedPath().includes(host)) close(); } };
    const onScrollResize = () => { if (rafId) return; rafId = requestAnimationFrame(() => { rafId = 0; if (pill.style.display === 'flex') showPill(); }); };
    document.addEventListener('mouseup', onSel, true);
    document.addEventListener('keyup', onKey, true);
    document.addEventListener('mousedown', onDown, true);
    document.addEventListener('touchend', onSel, true);
    g.addEventListener('scroll', onScrollResize, { passive: true, capture: true });
    g.addEventListener('resize', onScrollResize);

    return {
      explain(text, rect) { const s = selectionInfo(); open(text || (s && s.text), rect || (s ? s.rect : null)); },
      destroy() {
        document.removeEventListener('mouseup', onSel, true); document.removeEventListener('keyup', onKey, true);
        document.removeEventListener('mousedown', onDown, true); document.removeEventListener('touchend', onSel, true);
        g.removeEventListener('scroll', onScrollResize, true); g.removeEventListener('resize', onScrollResize);
        host.remove();
      }
    };
  }
  g.ClearExplain = { mount, MAX_CHARS };
})(typeof self !== 'undefined' ? self : this);
