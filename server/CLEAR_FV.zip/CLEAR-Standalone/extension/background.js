/* CLEAR — service worker: context menu, keyboard shortcuts, and the secure call to the explanation service.
 * Text is only ever sent when the person asks for an explanation. */
importScripts('config.js', 'prefs.js', 'simplify-local.js');

const MENU_ID = 'clear-explain';

chrome.runtime.onInstalled.addListener(async () => {
  chrome.contextMenus.removeAll(() => {
    chrome.contextMenus.create({ id: MENU_ID, title: 'Explain with CLEAR', contexts: ['selection'] });
  });
  const have = await chrome.storage.sync.get(null);
  const missing = {};
  for (const [k, v] of Object.entries(self.ClearPrefs.DEFAULTS)) if (!(k in have)) missing[k] = v;
  if (Object.keys(missing).length) chrome.storage.sync.set(missing);
});

const tell = (tabId, msg) => chrome.tabs.sendMessage(tabId, msg).catch(() => {});

chrome.contextMenus.onClicked.addListener((info, tab) => {
  if (info.menuItemId === MENU_ID && tab && tab.id != null) tell(tab.id, { type: 'explain-selection', text: info.selectionText });
});

chrome.commands.onCommand.addListener(async (cmd, tab) => {
  if (cmd === 'toggle-covers') {
    const { enabled } = await chrome.storage.sync.get({ enabled: true });
    chrome.storage.sync.set({ enabled: !enabled });
  } else if (cmd === 'explain-selection' && tab && tab.id != null) {
    tell(tab.id, { type: 'explain-selection' });
  }
});

async function backendBase() {
  const { backendUrl } = await chrome.storage.local.get('backendUrl');
  return String(backendUrl || self.CLEAR_CONFIG.BACKEND_URL || '').replace(/\/+$/, '');
}

async function explain({ text, level, context }) {
  const base = await backendBase();
  if (!base) return { ok: false, code: 'not-configured' };
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), 25000);
  try {
    const res = await fetch(base + '/api/explain', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ text: String(text || '').slice(0, 1500), level: level === 'simpler' ? 'simpler' : 'plain', context: String(context || '').slice(0, 120) }),
      signal: ctrl.signal
    });
    if (res.status === 429) return { ok: false, code: 'rate' };
    const data = await res.json().catch(() => null);
    if (!res.ok || !data || typeof data.summary !== 'string') return { ok: false, code: (data && data.code) || 'failed' };
    return { ok: true, data: { summary: data.summary, words: Array.isArray(data.words) ? data.words.slice(0, 4) : [] } };
  } catch (_) {
    return { ok: false, code: 'offline' };
  } finally { clearTimeout(timer); }
}

// If the explanation service cannot be used, still give the person a simplified version, made on this device.
const LOCAL_NOTE = {
  'not-configured': 'The CLEAR explanation service is not set up, so this is a basic version made on your device: it swaps hard words and splits long sentences.',
  'offline': 'CLEAR could not reach its explanation service, so this is a basic version made on your device: it swaps hard words and splits long sentences.',
  'rate': 'You have asked for many explanations in a short time, so this is a basic version made on your device. Try again in a minute for the full explanation.',
  'failed': 'The explanation service had a problem, so this is a basic version made on your device: it swaps hard words and splits long sentences.'
};
async function explainOrLocal(msg) {
  const r = await explain(msg);
  if (r.ok) return r;
  try {
    const l = self.ClearLocal.simplify(String(msg.text || '').slice(0, 1500), msg.level === 'simpler' ? 'simpler' : 'plain');
    const note = LOCAL_NOTE[r.code] || LOCAL_NOTE.failed;
    return { ok: true, data: { summary: l.summary, words: l.words, local: true, note: l.changed ? note : note + ' This text already looks plain, so little changed.' } };
  } catch (_) {
    return r;
  }
}

chrome.runtime.onMessage.addListener((msg, _sender, reply) => {
  if (msg && msg.type === 'explain') { explainOrLocal(msg).then(reply); return true; }
  return false;
});
