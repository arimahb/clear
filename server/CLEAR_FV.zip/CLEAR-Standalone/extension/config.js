/* CLEAR — extension configuration. Edit these two values before you publish. */
self.CLEAR_CONFIG = {
  // Where the CLEAR explanation service (see /backend) is running.
  // Users can override this in the popup under “Advanced”.
  BACKEND_URL: 'http://localhost:8787',

  // Exact origins of the CLEAR website. On these pages the extension does not
  // filter anything; it only syncs preferences with the website dashboard.
  SITE_ORIGINS: [
    'http://localhost:8080',
    'http://127.0.0.1:8080'
    // 'https://clear.yourdomain.com'
  ]
};
