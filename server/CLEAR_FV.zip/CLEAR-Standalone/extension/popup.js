(() => {
  'use strict';
  const P = self.ClearPrefs, $ = id => document.getElementById(id);
  let prefs = P.sanitize(), tab = null, host = '', savedTimer;

  // ---- build the dynamic parts ----
  $('cats').innerHTML = P.CATEGORIES.map(c => `<label title="${c.hint}"><input type="checkbox" data-k="${c.key}"> ${c.label}</label>`).join('');
  $('modes').innerHTML = P.MODES.map(m => `<label><input type="radio" name="mode" value="${m.value}"><span><b>${m.label}</b><small>${m.hint}</small></span></label>`).join('');
  $('swatches').innerHTML = P.PRESETS.map(s => `<button class="swatch" type="button" role="radio" aria-checked="false" aria-label="${s.name}" title="${s.name}" data-c="${s.color}" style="background:${s.color}"></button>`).join('');
  $('brushSize').min = P.BRUSH.min; $('brushSize').max = P.BRUSH.max;

  function render() {
    $('enabled').checked = prefs.enabled;
    document.querySelectorAll('[data-k]').forEach(i => { i.checked = !!prefs[i.dataset.k]; i.disabled = !prefs.enabled; });
    document.querySelectorAll('input[name=mode]').forEach(i => { i.checked = i.value === prefs.mode; });
    $('coverColor').value = prefs.coverColor;
    document.querySelectorAll('.swatch').forEach(b => b.setAttribute('aria-checked', String(b.dataset.c === prefs.coverColor)));
    $('brushSize').value = prefs.brushSize; $('brushOut').textContent = prefs.brushSize + ' px';
    const d = Math.min(52, prefs.brushSize); $('brushDot').style.width = $('brushDot').style.height = d + 'px';
    $('explain').checked = prefs.explain;
    $('siteOff').checked = prefs.disabledSites.includes(host);
    $('activate').hidden = prefs.mode !== 'off';
  }
  function save(msg) {
    prefs = P.sanitize(prefs);
    chrome.storage.sync.set(prefs, () => { $('saved').textContent = msg || 'Saved'; clearTimeout(savedTimer); savedTimer = setTimeout(() => ($('saved').textContent = ''), 1500); });
    render();
  }

  // ---- events ----
  $('enabled').addEventListener('change', e => { prefs.enabled = e.target.checked; save(); });
  $('cats').addEventListener('change', e => { if (e.target.dataset.k) { prefs[e.target.dataset.k] = e.target.checked; save(); } });
  $('modes').addEventListener('change', e => { if (e.target.name === 'mode') { prefs.mode = e.target.value; save(); setTimeout(status, 400); } });
  $('swatches').addEventListener('click', e => { const b = e.target.closest('.swatch'); if (b) { prefs.coverColor = b.dataset.c; save(); } });
  $('coverColor').addEventListener('input', e => { prefs.coverColor = e.target.value; });
  $('coverColor').addEventListener('change', () => save());
  $('brushSize').addEventListener('input', e => { prefs.brushSize = Number(e.target.value); render(); });
  $('brushSize').addEventListener('change', () => save());
  $('explain').addEventListener('change', e => { prefs.explain = e.target.checked; save(); });
  $('siteOff').addEventListener('change', e => {
    const set = new Set(prefs.disabledSites); e.target.checked ? set.add(host) : set.delete(host);
    prefs.disabledSites = Array.from(set); save(); setTimeout(status, 400);
  });
  $('reset').addEventListener('click', () => { const keep = prefs.disabledSites; prefs = P.sanitize(Object.assign({}, P.DEFAULTS, { disabledSites: keep })); save('Defaults restored'); });
  $('refog').addEventListener('click', () => send({ type: 'refog' }, () => { $('saved').textContent = 'Fog restored'; setTimeout(() => ($('saved').textContent = ''), 1500); status(); }));
  $('activate').addEventListener('click', () => send({ type: 'activate' }, () => setTimeout(status, 500)));

  // backend address (stored locally, never synced)
  chrome.storage.local.get('backendUrl', v => { $('backendUrl').value = v.backendUrl || ''; $('backendUrl').placeholder = (self.CLEAR_CONFIG && self.CLEAR_CONFIG.BACKEND_URL) || ''; });
  $('backendUrl').addEventListener('change', e => {
    const v = e.target.value.trim().replace(/\/+$/, '');
    if (v && !/^(https:\/\/|http:\/\/(localhost|127\.0\.0\.1)(:\d+)?)/i.test(v)) { $('backendMsg').textContent = 'Please use an https:// address (http is only allowed for localhost).'; return; }
    chrome.storage.local.set({ backendUrl: v }, () => { $('backendMsg').textContent = v ? 'Saved. Explanations will use this service.' : 'Using the default service.'; });
  });

  // ---- talk to the page ----
  function send(msg, cb) {
    if (!tab || tab.id == null) return cb && cb(null);
    chrome.tabs.sendMessage(tab.id, msg, r => { void chrome.runtime.lastError; cb && cb(r || null); });
  }
  function status() {
    send({ type: 'status' }, r => {
      const el = $('pageStatus');
      if (!r) { el.textContent = 'CLEAR can’t run on this page. Try an ordinary website.'; $('refog').disabled = true; return; }
      $('refog').disabled = false;
      if (r.siteOff) el.textContent = 'Paused on ' + r.host + '.';
      else if (!prefs.enabled) el.textContent = 'CLEAR is off.';
      else if (!r.active) el.textContent = 'Filtering is off. Choose “Cover this page now” whenever you want calm.';
      else el.textContent = r.covers ? `${r.covers} item${r.covers === 1 ? '' : 's'} covered on this page.` : 'Nothing to cover on this page right now.';
    });
  }

  chrome.tabs.query({ active: true, currentWindow: true }, tabs => {
    tab = tabs && tabs[0];
    try { host = tab && tab.url ? new URL(tab.url).hostname : ''; } catch (_) { host = ''; }
    $('siteName').textContent = host || 'this site'; $('siteOff').disabled = !host;
    chrome.storage.sync.get(P.DEFAULTS, v => { prefs = P.sanitize(v); render(); status(); });
  });
})();
