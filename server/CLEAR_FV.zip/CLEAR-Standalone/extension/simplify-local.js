/* CLEAR — on-device fallback for "Explain with CLEAR".
 * Used by the service worker only when the explanation service cannot be reached or fails, so that
 * selecting text always gives a result. Plain-word swaps, shorter sentences and a small idiom and
 * abbreviation list. It never leaves the device. It is simpler than the AI service and says so. */
(function (g) {
  'use strict';

  // [hard, plain]. Phrases first is handled by sorting on length.
  const SWAPS = [
    ['at this point in time', 'now'], ['at the present time', 'now'], ['in the event that', 'if'], ['due to the fact that', 'because'],
    ['in spite of the fact that', 'although'], ['for the purpose of', 'to'], ['with regard to', 'about'], ['with respect to', 'about'],
    ['in relation to', 'about'], ['in order to', 'to'], ['in the near future', 'soon'], ['a large number of', 'many'], ['a number of', 'several'],
    ['the majority of', 'most'], ['on a regular basis', 'regularly'], ['in addition to', 'besides'], ['as a consequence of', 'because of'],
    ['in accordance with', 'following'], ['prior to', 'before'], ['subsequent to', 'after'], ['in lieu of', 'instead of'], ['by means of', 'by'],
    ['is able to', 'can'], ['are able to', 'can'], ['has the ability to', 'can'], ['take into consideration', 'consider'],
    ['until such time as', 'until'], ['in excess of', 'more than'], ['adjacent to', 'next to'], ['pursuant to', 'under'], ['per annum', 'a year'],
    ['aforementioned', 'earlier-mentioned'], ['notwithstanding', 'despite'], ['hereinafter', 'from here on'], ['forthwith', 'right away'],
    ['utilize', 'use'], ['utilise', 'use'], ['utilization', 'use'], ['commence', 'start'], ['commencement', 'start'], ['terminate', 'end'],
    ['termination', 'end'], ['approximately', 'about'], ['purchase', 'buy'], ['assistance', 'help'], ['sufficient', 'enough'],
    ['insufficient', 'not enough'], ['numerous', 'many'], ['endeavor', 'try'], ['endeavour', 'try'], ['regarding', 'about'], ['concerning', 'about'],
    ['additional', 'more'], ['obtain', 'get'], ['acquire', 'get'], ['require', 'need'], ['requirement', 'need'], ['demonstrate', 'show'],
    ['indicate', 'show'], ['subsequently', 'later'], ['consequently', 'so'], ['therefore', 'so'], ['furthermore', 'also'], ['moreover', 'also'],
    ['nevertheless', 'even so'], ['frequently', 'often'], ['initiate', 'start'], ['implement', 'carry out'], ['modify', 'change'],
    ['modification', 'change'], ['attempt', 'try'], ['inform', 'tell'], ['notify', 'tell'], ['provide', 'give'], ['retain', 'keep'],
    ['reside', 'live'], ['residence', 'home'], ['ascertain', 'find out'], ['determine', 'find out'], ['verify', 'check'], ['component', 'part'],
    ['remainder', 'rest'], ['expedite', 'speed up'], ['mandatory', 'required'], ['optimal', 'best'], ['optimum', 'best'], ['primarily', 'mainly'],
    ['immediately', 'right away'], ['currently', 'now'], ['previously', 'before'], ['eligible', 'allowed'], ['remuneration', 'pay'],
    ['discontinue', 'stop'], ['cease', 'stop'], ['whilst', 'while'], ['thus', 'so'], ['hence', 'so'], ['elucidate', 'explain'], ['liable', 'responsible']
  ];
  // Common inflected forms of the verbs above (a swap with a spelled-out form, so "required" becomes "needed", not "needd").
  const FORMS = [
    ['utilized', 'used'], ['utilised', 'used'], ['utilizes', 'uses'],
    ['utilizing', 'using'], ['commenced', 'started'], ['commences', 'starts'], ['terminated', 'ended'], ['terminates', 'ends'],
    ['purchased', 'bought'], ['purchases', 'buys'], ['purchasing', 'buying'], ['obtained', 'got'], ['obtaining', 'getting'], ['acquired', 'got'],
    ['demonstrates', 'shows'], ['indicates', 'shows'], ['initiated', 'started'],
    ['implemented', 'carried out'], ['implements', 'carries out'], ['modified', 'changed'], ['modifies', 'changes'], ['attempted', 'tried'],
    ['attempts', 'tries'], ['informed', 'told'], ['informs', 'tells'], ['notified', 'told'], ['notifies', 'tells'],
    ['provides', 'gives'], ['providing', 'giving'], ['retained', 'kept'], ['retains', 'keeps'], ['resides', 'lives'], ['resided', 'lived'],
    ['ascertained', 'found out'], ['determined', 'found out'], ['determines', 'finds out'], ['verified', 'checked'], ['verifies', 'checks'],
    ['expedited', 'sped up'], ['discontinued', 'stopped'], ['ceased', 'stopped'], ['assisted', 'helped'], ['assists', 'helps']
  ];
  const IDIOMS = [
    ['break a leg', 'good luck'], ['piece of cake', 'very easy'], ['under the weather', 'a bit ill'], ['touch base', 'make brief contact'],
    ['circle back', 'return to this later'], ['ballpark', 'a rough estimate'], ['on the same page', 'in agreement'],
    ['once in a blue moon', 'very rarely'], ['cost an arm and a leg', 'be very expensive'], ['bite the bullet', 'do something unpleasant that must be done'],
    ['beat around the bush', 'avoid saying something directly'], ['ball is in your court', 'it is your turn to act'], ['call it a day', 'stop for today'],
    ['cut corners', 'do something badly to save time or money'], ['in the loop', 'kept informed'], ['let the cat out of the bag', 'reveal a secret'],
    ['miss the boat', 'be too late'], ['on the fence', 'undecided'], ['up in the air', 'not decided yet'], ['back to square one', 'starting again'],
    ['burn the midnight oil', 'work late into the night'], ['get the ball rolling', 'start something'], ['go the extra mile', 'do more than expected'],
    ['in a nutshell', 'in short'], ['long story short', 'in short'], ['low-hanging fruit', 'the easiest tasks'], ['move the needle', 'make a real difference'],
    ['grain of salt', 'do not fully believe it'], ['think outside the box', 'think in a new way'], ['red tape', 'slow official rules'],
    ['rule of thumb', 'a rough guide'], ['heads up', 'an early warning'], ['at the end of the day', 'when everything is considered'],
    ['going forward', 'from now on'], ['per my last email', 'as I already said'], ['with all due respect', 'I am about to disagree'],
    ['deep dive', 'a detailed look'], ['pain point', 'a problem that bothers someone'], ['game changer', 'something that changes a lot']
  ];
  const ABBR = [
    ['ASAP', 'as soon as possible'], ['FYI', 'for your information'], ['EOD', 'end of the working day'], ['TBD', 'to be decided'],
    ['TBC', 'to be confirmed'], ['ETA', 'expected arrival time'], ['IMO', 'in my opinion'], ['AFAIK', 'as far as I know'], ['BTW', 'by the way'],
    ['IDK', 'I do not know'], ['RSVP', 'please reply'], ['N/A', 'does not apply'], ['PTO', 'paid time off'], ['LMK', 'let me know'], ['FAQ', 'common questions']
  ];

  const esc = s => s.replace(/[.*+?^${}()|[\]\\\/]/g, '\\$&');
  const swapList = FORMS.concat(SWAPS).sort((a, b) => b[0].length - a[0].length);
  const swapRes = swapList.map(([from, to]) => [new RegExp('\\b' + esc(from) + '(s)?\\b', 'gi'), from, to]);

  function matchCase(orig, rep) {
    if (orig.length > 1 && orig === orig.toUpperCase() && /[A-Z]/.test(orig)) return rep.toUpperCase();
    if (/^[A-Z]/.test(orig)) return rep.charAt(0).toUpperCase() + rep.slice(1);
    return rep;
  }

  function plainWords(text) {
    let out = text;
    const hard = [];
    for (const [re, from, to] of swapRes) {
      out = out.replace(re, (m, s) => {
        // A trailing "s" is only added to base-form swaps made of one word ("requirement" -> "needs").
        const base = s ? m.slice(0, -1) : m;
        const isForm = FORMS.some(f => f[0] === from);
        if (s && (isForm || /\s/.test(to))) return m;
        hard.push([base, to]);
        return matchCase(base, to) + (s ? 's' : '');
      });
    }
    return { text: out, hard };
  }

  function sentences(text) {
    return text.replace(/\s+/g, ' ').trim().split(/(?<=[.!?])\s+(?=["'“(\[]?[A-Z0-9])/).map(s => s.trim()).filter(Boolean);
  }

  function shorten(sentence, limit) {
    if (sentence.split(' ').length < limit) return [sentence];
    const parts = sentence.split(/;\s+|\s+[–—]\s+|,\s+(?=(?:and|but|so)\b)/i).map(p => p.trim()).filter(Boolean);
    if (parts.length < 2) return [sentence];
    return parts.map((p, i) => {
      let s = p.replace(/^and\s+/i, '');
      s = s.charAt(0).toUpperCase() + s.slice(1);
      if (i < parts.length - 1 && !/[.!?:]$/.test(s)) s += '.';
      return s;
    });
  }

  function tricky(text) {
    const found = [], lower = text.toLowerCase();
    for (const [p, m] of IDIOMS.slice().sort((a, b) => b[0].length - a[0].length)) {
      if (new RegExp('(^|[^a-z])' + esc(p) + '($|[^a-z])').test(lower) && !found.some(f => f.term.toLowerCase().includes(p))) found.push({ term: p, meaning: m });
    }
    for (const [a, m] of ABBR) {
      if (new RegExp('(^|[^A-Za-z])' + esc(a) + '($|[^A-Za-z])').test(text)) found.push({ term: a, meaning: m });
    }
    return found;
  }

  /* simplify(text, level) -> { summary, words, note } */
  function simplify(text, level) {
    const src = String(text || '').replace(/\s+/g, ' ').trim();
    const pw = plainWords(src);
    const limit = level === 'simpler' ? 13 : 22;
    const out = [];
    for (const s of sentences(pw.text)) out.push(...shorten(s, limit));
    const summary = out.join(' ');
    const words = tricky(src);
    const seen = new Set(words.map(w => w.term.toLowerCase()));
    for (const [from, to] of pw.hard) {
      const k = from.toLowerCase();
      if (words.length >= 4) break;
      if (!seen.has(k)) { seen.add(k); words.push({ term: from, meaning: 'a harder way to say “' + to + '”' }); }
    }
    const changed = summary.replace(/\s+/g, ' ') !== src;
    return { summary: summary || src, words: words.slice(0, 4), changed };
  }

  g.ClearLocal = { simplify };
})(typeof self !== 'undefined' ? self : this);
