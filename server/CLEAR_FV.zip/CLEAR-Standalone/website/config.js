/* CLEAR website configuration. Edit before you publish. */
window.CLEAR_CONFIG = {
  // Address of the CLEAR explanation service (see /backend). Leave '' to run the demo in sample-only mode.
  BACKEND_URL: 'http://localhost:8787',
  // Where the extension zip is hosted (relative paths work).
  EXTENSION_ZIP: 'downloads/clear-extension.zip'
};
