/* CLEAR website — dashboard, extension sync, guided tutorial, explanation demo. */
(function () {
  'use strict';
  const P = window.ClearPrefs, Fog = window.ClearFog, CFG = window.CLEAR_CONFIG || {};
  const $ = id => document.getElementById(id);
  const reduceMotion = matchMedia('(prefers-reduced-motion: reduce)').matches;

  /* ───────────── preferences (local + extension sync) ───────────── */
  const KEY = 'clearPrefs';
  const origin = location.origin === 'null' ? '*' : location.origin;
  let prefs = P.sanitize(); let extConnected = false; let savedTimer;
  try { prefs = P.sanitize(JSON.parse(localStorage.getItem(KEY) || '{}')); } catch (_) {}

  function persist(msg) {
    prefs = P.sanitize(prefs);
    try { localStorage.setItem(KEY, JSON.stringify(prefs)); } catch (_) {}
    window.postMessage({ clearSite: true, type: 'set', prefs }, origin);
    $('p_saved').textContent = msg || 'Saved'; clearTimeout(savedTimer); savedTimer = setTimeout(() => ($('p_saved').textContent = ''), 1600);
    renderDash();
  }
  window.addEventListener('message', e => {
    if (e.source !== window || !e.data || !e.data.clearExt || e.data.type !== 'prefs') return;
    extConnected = true; prefs = P.sanitize(Object.assign({}, e.data.prefs));
    try { localStorage.setItem(KEY, JSON.stringify(prefs)); } catch (_) {}
    renderDash();
  });
  window.postMessage({ clearSite: true, type: 'get' }, origin);

  /* ───────────── dashboard ───────────── */
  $('p_cats').innerHTML = P.CATEGORIES.map(c => `<label><input type="checkbox" data-k="${c.key}"><span>${c.label}<small>${c.hint}</small></span></label>`).join('');
  $('p_modes').innerHTML = P.MODES.map(m => `<label><input type="radio" name="p_mode" value="${m.value}"><span><b>${m.label}</b><small>${m.hint}</small></span></label>`).join('');
  $('p_swatches').innerHTML = P.PRESETS.map(s => `<button class="swatch" type="button" role="radio" aria-checked="false" aria-label="${s.name}" title="${s.name}" data-c="${s.color}" style="background:${s.color}"></button>`).join('');
  $('p_brush').min = P.BRUSH.min; $('p_brush').max = P.BRUSH.max;

  function renderDash() {
    $('p_enabled').checked = prefs.enabled;
    document.querySelectorAll('#p_cats [data-k]').forEach(i => { i.checked = !!prefs[i.dataset.k]; i.disabled = !prefs.enabled; });
    document.querySelectorAll('input[name=p_mode]').forEach(i => { i.checked = i.value === prefs.mode; i.disabled = !prefs.enabled; });
    document.querySelectorAll('#p_swatches .swatch').forEach(b => b.setAttribute('aria-checked', String(b.dataset.c === prefs.coverColor)));
    $('p_color').value = prefs.coverColor;
    $('p_brush').value = prefs.brushSize; $('p_brushOut').textContent = prefs.brushSize + ' px';
    const d = Math.min(64, prefs.brushSize); $('p_dot').style.width = $('p_dot').style.height = d + 'px';
    $('p_explain').checked = prefs.explain;
    const s = $('syncStatus');
    const installed = extConnected || document.documentElement.dataset.clearExtension === 'installed';
    s.classList.toggle('ok', installed);
    s.textContent = installed ? '✓ The CLEAR extension is installed. Changes here apply to your browsing straight away, and the other way round.'
                             : 'The CLEAR extension was not detected. Your choices are saved in this browser and will sync once you install the extension.';
  }
  $('p_enabled').addEventListener('change', e => { prefs.enabled = e.target.checked; persist(); });
  $('p_cats').addEventListener('change', e => { if (e.target.dataset.k) { prefs[e.target.dataset.k] = e.target.checked; persist(); } });
  $('p_modes').addEventListener('change', e => { if (e.target.name === 'p_mode') { prefs.mode = e.target.value; persist(); } });
  $('p_swatches').addEventListener('click', e => { const b = e.target.closest('.swatch'); if (b) { prefs.coverColor = b.dataset.c; persist(); } });
  $('p_color').addEventListener('input', e => { prefs.coverColor = e.target.value; });
  $('p_color').addEventListener('change', () => persist());
  $('p_brush').addEventListener('input', e => { prefs.brushSize = Number(e.target.value); renderDash(); });
  $('p_brush').addEventListener('change', () => persist());
  $('p_explain').addEventListener('change', e => { prefs.explain = e.target.checked; persist(); });
  $('p_reset').addEventListener('click', () => { const keep = prefs.disabledSites; prefs = P.sanitize(Object.assign({}, P.DEFAULTS, { disabledSites: keep })); persist('Defaults restored'); });
  renderDash();
  // the extension's content script marks the page a moment after load
  setTimeout(renderDash, 700);

  /* ───────────── tutorial ───────────── */
  const tabs = [1, 2, 3].map(n => ({ tab: $('tab' + n), panel: $('panel' + n) }));
  let step = 0;
  const demoState = { kinds: new Set(['ads', 'gifs', 'videos', 'popups']), brush: 46, color: P.DEFAULTS.coverColor };
  const built = {};   // step -> mock instance

  $('demoCats').insertAdjacentHTML('beforeend', P.CATEGORIES.map(c => `<label><input type="checkbox" data-k="${c.key}" ${demoState.kinds.has(c.key) ? 'checked' : ''}> ${c.label}</label>`).join(''));

  const MOCK = `<div class="mock"><div class="mock-bar"><i></i><i></i><i></i><span>calm-reader.example/rivers</span></div>
    <div class="mock-page">
      <div class="mock-col">
        <div class="mock-ad" data-kind="ads"><div><small>ADVERTISEMENT</small>MEGA SALE −70%</div></div>
        <div><h4>How rivers shape a valley</h4><p>Over thousands of years, flowing water carries soil and stone downhill, slowly carving the land into wide, gentle curves.</p><div class="ln"></div><div class="ln s"></div></div>
        <div class="mock-video" data-kind="videos" aria-hidden="true"></div>
        <div><p>Where the water slows, it leaves silt behind, which is why river valleys are some of the richest farmland on Earth.</p><div class="ln"></div></div>
        <div class="mock-img" data-kind="images" aria-hidden="true"></div>
      </div>
      <div class="mock-col">
        <div class="mock-gif" data-kind="gifs" aria-hidden="true">WOW!</div>
        <div class="mock-sponsor" data-kind="sponsored"><span class="label">Sponsored</span><div class="pic"></div><p>One weird trick doctors hate</p></div>
        <div class="ln"></div><div class="ln s"></div><div class="ln"></div>
      </div>
      <div class="mock-popup" data-kind="popups"><h5>Wait! Don’t go!</h5><p>Get 10% off when you subscribe.</p><span>Subscribe now</span></div>
    </div></div>`;

  function buildMock(host, mode, kinds) {
    host.innerHTML = MOCK;
    const page = host.querySelector('.mock-page'), pr = page.getBoundingClientRect();
    const list = [];
    page.querySelectorAll('[data-kind]').forEach((el, i) => {
      if (!kinds.has(el.dataset.kind)) return;
      const r = el.getBoundingClientRect();
      if (r.width < 4 || r.height < 4) return;
      const wrap = document.createElement('div');
      wrap.className = 'mock-cover ' + mode;
      wrap.style.cssText = `left:${r.left - pr.left - 6}px;top:${r.top - pr.top - 6}px;width:${r.width + 12}px;height:${r.height + 12}px`;   // bleed: animated items can grow past their box
      const c = Fog.createFogCanvas(r.width + 12, r.height + 12, demoState.color, i * 7919 + 3);
      wrap.appendChild(c);
      if (mode === 'manual') {
        wrap.style.cursor = Fog.brushCursor(demoState.brush);
        Fog.attachWipe(c, { getBrush: () => demoState.brush });
        wrap.setAttribute('role', 'img'); wrap.setAttribute('aria-label', 'Covered content. Drag to wipe the fog away.');
      } else { wrap.setAttribute('role', 'img'); wrap.setAttribute('aria-label', 'Content hidden by CLEAR'); }
      page.appendChild(wrap); list.push({ c, wrap });
    });
    return { list, refog() { list.forEach(x => Fog.refog(x.c)); }, cursor() { list.forEach(x => (x.wrap.style.cursor = Fog.brushCursor(demoState.brush))); } };
  }
  function renderStep() {
    tabs.forEach((t, i) => { const on = i === step; t.tab.setAttribute('aria-selected', String(on)); t.tab.tabIndex = on ? 0 : -1; t.panel.hidden = !on; });
    $('stepLabel').textContent = `Step ${step + 1} of 3`;
    $('prevStep').disabled = step === 0;
    $('nextStep').textContent = step === 2 ? 'Install CLEAR' : 'Next step';
    requestAnimationFrame(() => {
      if (step === 0) built[0] = buildMock($('mockHost1'), 'always', demoState.kinds);
      if (step === 1) built[1] = buildMock($('mockHost2'), 'manual', new Set(['ads', 'gifs', 'videos', 'popups', 'sponsored', 'images']));
    });
  }
  tabs.forEach((t, i) => {
    t.tab.addEventListener('click', () => { step = i; renderStep(); });
    t.tab.addEventListener('keydown', e => {
      if (e.key === 'ArrowRight' || e.key === 'ArrowLeft') { step = (step + (e.key === 'ArrowRight' ? 1 : 2)) % 3; renderStep(); tabs[step].tab.focus(); }
    });
  });
  $('prevStep').addEventListener('click', () => { if (step > 0) { step--; renderStep(); } });
  $('nextStep').addEventListener('click', () => { if (step < 2) { step++; renderStep(); } else location.hash = '#install'; });
  $('demoCats').addEventListener('change', e => { const k = e.target.dataset.k; if (!k) return; e.target.checked ? demoState.kinds.add(k) : demoState.kinds.delete(k); built[0] = buildMock($('mockHost1'), 'always', demoState.kinds); });
  $('demoBrush').addEventListener('input', e => { demoState.brush = Number(e.target.value); $('demoBrushOut').textContent = demoState.brush + ' px'; if (built[1]) built[1].cursor(); });
  $('demoRefog').addEventListener('click', () => built[1] && built[1].refog());
  let rt; addEventListener('resize', () => { clearTimeout(rt); rt = setTimeout(() => { if (step < 2) renderStep(); }, 300); });
  renderStep();

  /* ───────────── "Explain with CLEAR" demo ───────────── */
  const SAMPLES = [
    { re: /contingent upon subsequent review/i, plain: 'The changes will only happen after someone has looked at them and said yes.', simpler: 'The changes need to be checked and approved first.', words: [{ term: 'contingent upon', meaning: 'depends on something else happening first' }, { term: 'subsequent', meaning: 'coming later' }] },
    { re: /pursuant to section/i, plain: 'Following section 4 of the agreement, the tenant must pay the rent by the fifth working day of every month.', simpler: 'The rule in section 4 says: pay your rent by the fifth work day each month.', words: [{ term: 'pursuant to', meaning: 'according to; following' }, { term: 'remit payment', meaning: 'send money' }, { term: 'business day', meaning: 'a normal working day, not a weekend or holiday' }] },
    { re: /subject to discretionary revision/i, plain: 'The policy can be changed whenever the landlord decides to. They must give thirty days’ notice in writing.', simpler: 'The landlord can change the rules. They must tell you in writing 30 days before.', words: [{ term: 'discretionary', meaning: 'decided by one person’s choice' }, { term: 'revision', meaning: 'a change to the text' }, { term: 'amend', meaning: 'change' }] }
  ];
  const base = (CFG.BACKEND_URL || '').replace(/\/+$/, '');
  let live = false;
  const err = code => Object.assign(new Error(code), { code });

  async function demoRequest({ text, level }) {
    if (base) {
      const ctrl = new AbortController(), t = setTimeout(() => ctrl.abort(), 22000);
      let res = null, data = null;
      try {
        res = await fetch(base + '/api/explain', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ text, level, context: 'CLEAR website demo' }), signal: ctrl.signal });
        data = await res.json().catch(() => null);
      } catch (_) { res = null; } finally { clearTimeout(t); }
      if (res && res.status === 429) throw err('rate');
      if (res && res.ok && data && typeof data.summary === 'string') return { summary: data.summary, words: data.words || [] };
      if (res && data && data.code !== 'not-configured') throw err('failed');
    }
    const hit = SAMPLES.find(s => s.re.test(text));            // sample mode: only the demo sentences
    if (hit) return { summary: level === 'simpler' ? hit.simpler : hit.plain, words: hit.words, note: 'Sample explanation. Connect the CLEAR explanation service to explain any text.' };
    throw err(base ? 'offline' : 'not-configured');
  }
  const ui = ClearExplain.mount({ scope: $('sampleArticle'), request: demoRequest });
  $('explainPaste').addEventListener('click', () => {
    const v = $('pasteText').value.trim();
    if (!v) { $('pasteText').focus(); return; }
    ui.explain(v, $('explainPaste').getBoundingClientRect());
  });
  (async function probe() {
    const note = $('demoModeNote');
    if (!base) { note.textContent = 'Sample mode: only the sentences in the sample article can be explained.'; return; }
    try {
      const c = new AbortController(); setTimeout(() => c.abort(), 3000);
      const r = await fetch(base + '/health', { signal: c.signal }); const j = await r.json();
      live = !!(j && j.ok && j.configured);
    } catch (_) { live = false; }
    note.textContent = live ? 'Live mode: explanations are written by an AI service. Only the text you select is sent.' : 'Sample mode: the explanation service is not connected, so only the sentences in the sample article can be explained.';
  })();

  /* ───────────── install helpers ───────────── */
  if (CFG.EXTENSION_ZIP) $('dl').setAttribute('href', CFG.EXTENSION_ZIP);
  $('copyExt').addEventListener('click', async e => {
    try { await navigator.clipboard.writeText('chrome://extensions'); e.target.textContent = 'Copied'; } catch (_) { e.target.textContent = 'Select and copy it above'; }
    setTimeout(() => (e.target.textContent = 'Copy address'), 1800);
  });
})();
