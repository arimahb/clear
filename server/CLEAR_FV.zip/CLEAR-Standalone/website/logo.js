/* CLEAR — writes the logo onto the fogged glass, following the real lettering with a fingertip. */
(function () {
  'use strict';
  const stage = document.getElementById('logoStage');
  if (!stage || !window.CLEAR_PEN) return;
  const cvs = stage.querySelector('canvas'), finger = stage.querySelector('.finger'), full = stage.querySelector('.logo-full');
  const reduce = matchMedia('(prefers-reduced-motion: reduce)').matches;
  const PEN = window.CLEAR_PEN, S = PEN.size, R = PEN.radius, pts = PEN.pts;
  const img = new Image(); img.src = full.getAttribute('src');
  let raf = 0, token = 0;

  function finish() { stage.classList.add('done'); finger.style.opacity = '0'; }
  function play() {
    cancelAnimationFrame(raf);
    const my = ++token;
    stage.classList.remove('done'); stage.classList.add('writing');
    const ctx = cvs.getContext('2d'); ctx.clearRect(0, 0, S, S);
    let next = 0; const DURATION = 4200, t0 = performance.now() + 450;   // brief pause, then the finger starts
    finger.style.opacity = '0';
    (function frame(now) {
      if (my !== token) return;
      const p = Math.min(1, Math.max(0, (now - t0) / DURATION));
      const t = p;   // linear pen speed feels most like handwriting
      while (next < pts.length && pts[next][2] <= t) {
        const [x, y] = pts[next++];
        ctx.save(); ctx.beginPath(); ctx.arc(x, y, R, 0, 6.2832); ctx.clip(); ctx.drawImage(img, 0, 0, S, S); ctx.restore();
        finger.style.transform = `translate(${(x / S) * 100}%, ${(y / S) * 100}%)`; finger.style.opacity = '1';
      }
      if (p < 1) raf = requestAnimationFrame(frame); else setTimeout(finish, 120);
    })(performance.now());
  }
  function start() {
    stage.classList.add('js');
    if (reduce) { stage.classList.add('done'); return; }
    play();
  }
  if (img.complete) start(); else { img.onload = start; img.onerror = () => stage.classList.remove('js'); }
  const replay = () => { if (!reduce) { stage.classList.remove('done'); setTimeout(play, 30); } };
  stage.addEventListener('click', replay);
  stage.addEventListener('keydown', e => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); replay(); } });
})();
