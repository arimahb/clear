from playwright.sync_api import sync_playwright
CHROME='/opt/pw-browsers/chromium-1243/chrome-linux64/chrome'
with sync_playwright() as p:
    ctx=p.chromium.launch_persistent_context('/tmp/ud5',executable_path=CHROME,headless=False,args=['--headless=new','--no-sandbox','--disable-extensions-except=/tmp/ext_test','--load-extension=/tmp/ext_test'],viewport={'width':1200,'height':800})
    sw=ctx.service_workers[0] if ctx.service_workers else ctx.wait_for_event('serviceworker',timeout=8000)
    sw.evaluate("(async()=>{await chrome.storage.sync.clear();await chrome.storage.sync.set({images:true})})()")
    pg=ctx.new_page(); pg.goto('http://localhost:8090/heavy.html'); pg.wait_for_timeout(6000)
    print('DOM nodes:',pg.evaluate("document.querySelectorAll('*').length"))
    print('long tasks (ms) on a 24k-node page, images ON:',pg.evaluate("window.__lt"))
    print('covers (cap 160):',pg.evaluate("document.querySelector('[data-clear-root]').shadowRoot.querySelectorAll('.cover').length"))
    # scroll smoothness: time 30 scroll steps
    t=pg.evaluate("""async()=>{const t0=performance.now();for(let i=0;i<30;i++){window.scrollBy(0,200);await new Promise(r=>requestAnimationFrame(r))}return Math.round((performance.now()-t0)/30)}""")
    print('avg ms per scrolled frame with covers active:',t)
    # keyboard reveal in manual mode
    sw.evaluate("(async()=>{await chrome.storage.sync.clear();await chrome.storage.sync.set({mode:'manual'})})()")
    p2=ctx.new_page(); p2.goto('http://localhost:8090/page.html'); p2.wait_for_timeout(3500)
    p2.keyboard.press('Tab')
    n=p2.evaluate("document.querySelector('[data-clear-root]').shadowRoot.querySelectorAll('.cover[tabindex]').length"); print('keyboard-focusable covers:',n)
    p2.evaluate("document.querySelector('[data-clear-root]').shadowRoot.querySelector('.cover').focus()"); p2.keyboard.press('Enter'); p2.wait_for_timeout(200)
    print('first cover hidden after Enter:',p2.evaluate("document.querySelector('[data-clear-root]').shadowRoot.querySelector('.cover').style.display"))
    ctx.close()
