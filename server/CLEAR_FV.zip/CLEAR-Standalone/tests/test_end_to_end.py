from playwright.sync_api import sync_playwright
import json, subprocess, time
CHROME='/opt/pw-browsers/chromium-1243/chrome-linux64/chrome'
with sync_playwright() as p:
    ctx=p.chromium.launch_persistent_context('/tmp/ud4',executable_path=CHROME,headless=False,
        args=['--headless=new','--no-sandbox','--disable-extensions-except=/tmp/ext_test','--load-extension=/tmp/ext_test'],viewport={'width':1200,'height':800})
    sw=ctx.service_workers[0] if ctx.service_workers else ctx.wait_for_event('serviceworker',timeout=8000)
    sw.evaluate("(async()=>{await chrome.storage.sync.clear()})()")
    # ---- explain through extension ----
    pg=ctx.new_page(); pg.goto('http://localhost:8090/page.html'); pg.wait_for_timeout(2500)
    box=pg.locator('#para').bounding_box(); pg.mouse.click(box['x']+20,box['y']+8,click_count=3); pg.wait_for_timeout(500)
    pill=pg.get_by_role('button',name='Explain selected text with CLEAR'); print('pill on ordinary page:',pill.is_visible())
    pill.click(); pg.wait_for_timeout(1500)
    print('panel says:',pg.locator('.panel .bd').first.inner_text().replace('\n',' | ')[:140] if pg.locator('.panel .bd').count() else 'none')
    req=json.load(open('/tmp/last_req.json'))
    print('backend→API: key header sent:',req['headers'].get('x-api-key')=='test-key','| model:',req['body']['model'],'| text wrapped in <selected_text>:','<selected_text>' in req['body']['messages'][0]['content'])
    pg.keyboard.press('Escape'); pg.wait_for_timeout(200)
    # context-menu/shortcut path: message from SW to tab
    sw.evaluate("(async()=>{const [t]=await chrome.tabs.query({active:true});await chrome.tabs.sendMessage(t.id,{type:'explain-selection',text:'Pursuant to the aforementioned clause.'})})()")
    pg.wait_for_timeout(1500); print('shortcut/context-menu path shows panel:',pg.locator('.panel').first.is_visible())
    pg.screenshot(path='e_explain.png'); 
    # ---- website <-> extension sync ----
    ws=ctx.new_page(); ws.goto('http://localhost:8080/'); ws.wait_for_timeout(1500)
    print('website detects extension:', ws.evaluate("document.documentElement.dataset.clearExtension"), '|', ws.inner_text('#syncStatus')[:60])
    ws.click('#p_swatches [aria-label=Rose]'); ws.wait_for_timeout(600)
    print('extension storage after website change:', sw.evaluate("chrome.storage.sync.get(['coverColor']).then(v=>v.coverColor)"))
    sw.evaluate("chrome.storage.sync.set({brushSize:90})"); ws.wait_for_timeout(700)
    print('website slider after extension change:', ws.input_value('#p_brush'))
    ws.screenshot(path='e_site_with_ext.png',clip={'x':0,'y':0,'width':1200,'height':300})
    print('website itself not filtered (no covers):', ws.evaluate("!document.querySelector('[data-clear-root]')"))
    # ---- popup page ----
    ext_id=sw.url.split('/')[2]; pp=ctx.new_page(); pp.set_viewport_size({'width':350,'height':900}); pp.goto(f'chrome-extension://{ext_id}/popup.html'); pp.wait_for_timeout(800)
    pp.screenshot(path='e_popup.png',full_page=True)
    ctx.close()
