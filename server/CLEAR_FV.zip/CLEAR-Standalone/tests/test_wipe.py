from playwright.sync_api import sync_playwright
from PIL import Image
import io, numpy as np
CHROME='/opt/pw-browsers/chromium-1243/chrome-linux64/chrome'
def count(png,c,box):
    a=np.array(Image.open(io.BytesIO(png)).convert('RGB')).astype(int)
    x,y,w,h=[int(v) for v in box]; sub=a[y:y+h,x:x+w]
    return int((np.abs(sub-np.array(c)).sum(axis=2)<24).sum())
with sync_playwright() as p:
    ctx=p.chromium.launch_persistent_context('/tmp/ud3',executable_path=CHROME,headless=False,
        args=['--headless=new','--no-sandbox','--disable-extensions-except=/tmp/ext_test','--load-extension=/tmp/ext_test'],viewport={'width':1200,'height':800})
    sw=ctx.service_workers[0] if ctx.service_workers else ctx.wait_for_event('serviceworker',timeout=8000)
    sw.evaluate("(async()=>{await chrome.storage.sync.clear();await chrome.storage.sync.set({mode:'manual',brushSize:50})})()")
    pg=ctx.new_page(); pg.goto('http://localhost:8090/page.html'); pg.wait_for_timeout(3600)
    # stop pulse so box is stable for measuring
    pg.add_style_tag(content='.pulse{animation:none!important}'); pg.wait_for_timeout(600)
    bb=pg.locator('#ad1').bounding_box()
    box=(bb['x'],bb['y'],bb['width'],bb['height'])
    before=count(pg.screenshot(),(255,0,0),box)
    # wipe left half only
    y=bb['y']+bb['height']/2
    pg.mouse.move(bb['x']+10,y); pg.mouse.down()
    for i in range(30): pg.mouse.move(bb['x']+10+i*(bb['width']/2-10)/30,y+(i%3))
    pg.mouse.up(); pg.wait_for_timeout(300)
    shot=pg.screenshot()
    left=count(shot,(255,0,0),(bb['x'],bb['y'],bb['width']/2,bb['height'])); right=count(shot,(255,0,0),(bb['x']+bb['width']/2+60,bb['y'],bb['width']/2-60,bb['height']))
    print(f'red px before wipe: {before}  | after wiping left half: left={left}  right={right}')
    Image.open(io.BytesIO(shot)).crop((0,80,1000,420)).save('/home/claude/e_wipe2.png')
    # restore fog
    pg.evaluate("""()=>{const h=document.querySelector('[data-clear-root]');[...h.shadowRoot.querySelectorAll('button')].filter(b=>b.textContent==='Restore fog').forEach(b=>b.click())}""")
    pg.wait_for_timeout(300)
    print('red px after Restore fog:',count(pg.screenshot(),(255,0,0),box))
    ctx.close()
