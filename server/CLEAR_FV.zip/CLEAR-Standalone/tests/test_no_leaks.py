from playwright.sync_api import sync_playwright
from PIL import Image
import io, numpy as np
CHROME='/opt/pw-browsers/chromium-1243/chrome-linux64/chrome'
COL={'red':(255,0,0),'yellow':(255,238,0),'magenta':(255,0,255),'blue':(0,0,255),'green':(0,204,102)}
def leaks(png):
    a=np.array(Image.open(io.BytesIO(png)).convert('RGB')).astype(int); out={}
    for k,c in COL.items(): out[k]=int((np.abs(a-np.array(c)).sum(axis=2)<24).sum())
    return out
with sync_playwright() as p:
    ctx=p.chromium.launch_persistent_context('/tmp/ud2',executable_path=CHROME,headless=False,
        args=['--headless=new','--no-sandbox','--disable-extensions-except=/tmp/ext_test','--load-extension=/tmp/ext_test'],viewport={'width':1200,'height':800})
    sw=ctx.service_workers[0] if ctx.service_workers else ctx.wait_for_event('serviceworker',timeout=8000)
    sw.evaluate("chrome.storage.sync.clear()")
    pg=ctx.new_page(); pg.goto('http://localhost:8090/page.html'); pg.wait_for_timeout(3500)
    tot={k:0 for k in COL}; worst={k:0 for k in COL}
    for y in (0,250,500,900):
        pg.evaluate(f"window.scrollTo(0,{y})"); pg.wait_for_timeout(250)
        for i in range(6):
            l=leaks(pg.screenshot())
            for k in COL: tot[k]+=l[k]; worst[k]=max(worst[k],l[k])
            pg.wait_for_timeout(97)
    print('leaked pixels (sum over 24 frames):',tot); print('worst single frame:',worst)
    ctx.close()
