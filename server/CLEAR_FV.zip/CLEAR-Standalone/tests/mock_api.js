const http=require('http'),fs=require('fs');
http.createServer((req,res)=>{let b='';req.on('data',c=>b+=c);req.on('end',()=>{
  fs.writeFileSync('/tmp/last_req.json',JSON.stringify({headers:req.headers,body:JSON.parse(b||'{}')}));
  res.writeHead(200,{'content-type':'application/json'});
  res.end(JSON.stringify({content:[{type:'text',text:'```json\n{"summary":"Mock: the landlord can change the rules.","words":[{"term":"discretionary","meaning":"up to one person\'s choice"}]}\n```'}]}));
});}).listen(9999);
