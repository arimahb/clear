# CLEAR — standalone website, Chrome extension and explanation service

Three parts, no Base44 anywhere:

| Folder | What it is |
|---|---|
| `extension/` | The Chrome (Manifest V3) extension: covers distractions, fog-wipe brush, "Explain with CLEAR". |
| `website/` | The welcome page: animated circular logo, interactive tutorial, preferences dashboard, install guide. |
| `backend/` | A small Node service that keeps your AI key private and writes the plain-language explanations. |
| `shared/` | Source of the three files used by both the website and the extension. Edit here, then run `python3 build.py`. |

## 1. Try the extension (2 minutes)
1. Open `chrome://extensions`, switch on **Developer mode**.
2. **Load unpacked** → choose the `extension` folder.
3. Open any ordinary website and click the CLEAR icon. Covers appear automatically (default: *Always covered*).

Shortcuts: `Alt+Shift+C` turn CLEAR on/off · `Alt+Shift+E` explain selected text · right-click selected text → **Explain with CLEAR**.

## 2. Run the website
```
cd website
python3 -m http.server 8080      # then open http://localhost:8080
```
(Use a local server, not a double-clicked file: preference syncing with the extension needs a real origin.)
The extension already recognises `http://localhost:8080`. For your real domain, add it to `SITE_ORIGINS` in `extension/config.js`, and set `BACKEND_URL` / `EXTENSION_ZIP` in `website/config.js`.

## 3. Turn on real explanations (needed for "Explain with CLEAR")
Arbitrary text can only be explained by an AI model, and the API key must never sit in the extension or website. The backend holds it:
```
cd backend
ANTHROPIC_API_KEY=sk-ant-... node server.js      # Node 18+, no npm install needed
```
Then it runs on http://localhost:8787, which is already the default `BACKEND_URL` in both configs.
To go live, deploy `backend/` to any Node host (Render, Fly.io, Railway, a VPS), set the variables from `.env.example`, and put its https address in `extension/config.js` and `website/config.js`. Users can also override the address in the extension popup under **Advanced**.

What the backend does: key stays server-side · CORS allow-list (your site + the extension) · 15 requests/min and 200/day per visitor, plus a global daily cap · 1,500-character limit · text is never logged · the selected text is passed to the model as data with instructions to ignore any commands inside it · default model `claude-haiku-5-5` (change with `CLEAR_MODEL`).

## Before you publish
- `python3 build.py` after any change to `shared/` (also rebuilds `website/downloads/clear-extension.zip`).
- Put your real URLs in the two `config.js` files; lock `EXTENSION_IDS` in the backend once you have a Chrome Web Store ID.
- Chrome Web Store needs a privacy policy: text is sent only when the person asks for an explanation, and is not stored.

## How the spec maps to the code
- **Distraction filtering** — `extension/content.js`: ads (attribute, class-token, ad-network iframes), sponsored labels, GIFs, videos/autoplay (paused + muted underneath), pop-ups/modals (role/aria/class + fixed-position heuristics; skips pop-ups you just clicked open and cookie banners), optional other images. Re-scans as pages change; time-sliced so big pages don't stall.
- **Opaque fog covers** — `shared/fog.js`: every pixel is painted at alpha 1 in sage/cream; a few px of bleed hides animated ads that grow.
- **Wipe brush** — `shared/fog.js` + `content.js`: soft-edged brush interpolated along the drag, brush-sized cursor, mouse/touch/pen, "Restore fog" per cover and from the popup, "Show all" and keyboard `Enter` to reveal. Modes: Always covered / Manual reveal / Filtering off (+ "Cover this page now").
- **Text simplification** — `shared/explain-ui.js` + `background.js` + `backend/`.
- **Dashboard** — website `#preferences` and the popup: category toggles, modes, 6 colour presets + custom colour, brush size, reset to defaults, per-site pause. Settings persist and sync both ways between website and extension.
- **Website** — `website/`: circular logo that is "written" along the real lettering (pen path traced from your logo; click to replay), 3-step interactive tutorial, install guide.

## Known limits (please read)
- Detection is heuristic. It cannot see inside cross-origin iframes beyond covering the frame itself, CSS background-image media, canvas/WebGL content, or ads with no recognisable markup. Audio of a covered *iframe* video (e.g. YouTube) keeps playing; `<video>` elements are paused.
- Cookie-consent banners are deliberately not covered so you can always answer them.
- Only Chromium was tested. Firefox/Safari would need manifest changes.
- Live Chrome Web Store behaviour, and real-world sites such as news/social/shopping, have not been tested. Run the checklist below on the sites you care about.

## Tests included (`tests/`)
Playwright scripts that load the real extension in Chromium against `tests/page.html` (ads, ad iframe, GIF, video, sponsored card, delayed pop-up, late-injected ad, inner scroller) and a 30,000-node stress page. They need servers described at the top of each file's imports; results from the last run are in the summary you were given.
